﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessObject
{
    public class MoviesObject
    {
        public string _Id { get; set; }
        public string _Title { get; set; }
        public string _Actor { get; set; }
        public string _Actress { get; set; }
        public string _Director { get; set; }
        public string _Producer { get; set; }
        public string _Composer { get; set; }
        public string _Genre { get; set; }
        public string _realeaseYear { get; set; }
        public string _Subtitle { get; set; }
        public string _Format { get; set; }
        public string _catalogNo { get; set; }
        public string _Sku { get; set; }
        public string _barcodeNo { get; set; }
        public string _Label { get; set; }
        public int _no_of_disc { get; set; }
        public int _Stock { get; set; }
        public string _Studios { get; set; }
        public string _mainImage { get; set; }
        public string _thumbnailImage { get; set; }
        public decimal _Mrp { get; set; }
        public int _Discount { get; set; }
        public string _Synopsis { get; set; }
        public string _Type { get; set; }
        public char _newArrival { get; set; }
        public char _bestSeller { get; set; }
        public char _featuredProduct { get; set; }
        public char _Approved { get; set; }
        public char _Sale { get; set; }
        public string _Runtime { get; set; }
        public string _Rated { get; set; }
        public string _Region { get; set; }
        public DateTime _modifiedDate { get; set; }
        public string _fromDate { get; set; }
        public string _toDate { get; set; }
        public char _PreOrder { get; set; }
        public string language { get; set; }
    } 
}
