﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessObject
{
    public class ProductObject
    {
        public string _Id { get; set; }
        public string _Title { get; set; }
        public string _barcode { get; set; }
        public int _stock { get; set; }
        public string _shortDescp { get; set; }
        public string _longDescp { get; set; }        
        public decimal _Mrp { get; set; }
        public string _Category { get; set; }
        public int _Discount  { get; set; }
        public string _fromDate { get; set; }
        public string _toDate { get; set; }
        public decimal _Weight { get; set; }
        public string _mainImage { get; set; }
        public string _thumbnailImage { get; set; }
        public char _newArrival { get; set; }
        public char _bestSeller { get; set; }
        public char _featuredProduct { get; set; }
        public char _Sale { get; set; }
        public char _Approve { get; set; }
        public DateTime _modifiedDate { get; set; }
    }
}
