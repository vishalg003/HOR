﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessObject
{
    public class MusicObject
    {
        public string _Id { get; set; }
        public string _Tiltle { get; set; }
        public string _Artist { get; set; }
        public string _Composer { get; set; }
        public string _Lyricist { get; set; }
        public string _Genre { get; set; }
        public int _NoOfDisc { get; set; }
        public string _Label { get; set; }
        public string _CatlogNo { get; set; }
        public string _BarcodeNo { get; set; }
        public string _ReleaseDate { get; set; }
        public decimal _Mrp { get; set; }
        public int _Discount { get; set; }
        public int _Stock { get; set; }
        public string _ThumbnailImage { get; set; }
        public string _Tracks { get; set; }
        public string _Format { get; set; }
        public string _Sku { get; set; }
        public string _MainImage { get; set; }
        public string _Description { get; set; }
        public char _newArrival { get; set; }
        public char _bestSeller { get; set; }
        public char _featuredProd { get; set; }
        public char _Sale { get; set; }
        public char _Approve { get; set; }
        public decimal _Weight { get; set; }
        public DateTime _createDate{ get; set; }
        public string _fromDate { get; set; }
        public string _toDate { get; set; }
        public DateTime _modifiedDate { get; set; }
        public string _Origin { get; set; }
        public string _Media { get; set; }
        public char _PreOrder { get; set; }
    }
}
