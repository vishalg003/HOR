﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessObject
{
   public class BookObject
    {
       public string _book_id { get; set; }
       public string _book_title { get; set; }
       public string _author_name { get; set; }
       public string _publisher_name { get; set; }
       public string _isbn_no { get; set; }
       public string _sku { get; set; }
       public string _description { get; set; }
       public int _no_of_pages { get; set; }
       public string _size { get; set; }
       public string _publish_date { get; set; }
       public string _main_image { get; set; }
       public string _thumbnail_image { get; set; }
       public decimal _mrp { get; set; }
       public int _discount { get; set; }
       public int _Stock { get; set; }
       public string _cartegory { get; set; }
       public string _type { get; set; }
       public char _new_arrival { get; set; }
       public char _featured_product { get; set; }
       public char _best_seller { get; set; }
       public char _approved { get; set; }
       public char _Sale { get; set; }
       public DateTime _createDate { get; set; }
       public DateTime _modifyDate { get; set; }
       public string _fromDate { get; set; }
       public string _toDate { get; set; }
       public char _PreOrder { get; set; }
    }
}
