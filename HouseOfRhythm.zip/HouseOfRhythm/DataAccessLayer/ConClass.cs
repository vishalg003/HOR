﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace DataAccessLayer
{
    class ConClass
    {
        public static SqlConnection ConFun()
        {
            string conStr = ConfigurationManager.ConnectionStrings["houseofrhythmDB"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            return con;
        }
    }
}
