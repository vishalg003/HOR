﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer
{
    public class CommonClass
    {
        SqlConnection con;
        SqlCommand cmd;
        DataTable dt;
        DataSet ds;
        SqlDataAdapter da;

        //Method To Get Max Code/Id for Autoincrement
        /* ************************************************************************************************** */

        public static string getCode(string procedure)
        {
            try
            {
                using (SqlConnection con = ConClass.ConFun())
                {
                    using (SqlCommand cmd = new SqlCommand(procedure,con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        DataTable dt = new DataTable();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return (dt.Rows[0][0].ToString());
                    }
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        //Method To Insert Record in Database
        /* **************************************************************************************************** */

        public int InsertData(string procedure, List<SqlParameter> paramList)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddRange(paramList.ToArray());
                        con.Open();
                        int rows_affected = cmd.ExecuteNonQuery();
                        con.Close();
                        return rows_affected;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        //Method to delete Record from cart
        /* ******************************************************************************************** */
        public int DeleteProductFromCart(string procedure, List<SqlParameter> paramlist)
        {
            try
            {
                using (con = ConClass.ConFun())
                { 
                    using(cmd=new SqlCommand(procedure,con))
                    {
                        cmd.CommandType=CommandType.StoredProcedure;
                        cmd.Parameters.AddRange(paramlist.ToArray());
                        con.Open();
                        int rows_affected=cmd.ExecuteNonQuery();
                        con.Close();
                        return rows_affected;
                    }
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }


        //Method To Fetch Record With Multiple Tables For Reports and Dashboard
        /* **************************************************************************************************** */

        public DataSet fetchMultipleData(string procedure)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (da = new SqlDataAdapter(procedure, con))
                    {
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }


        //Method to get ProductList With Paging
        /************************************************************************************************* */
        public DataSet getProductListPaging(string procedure, List<SqlParameter> paramList)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (da = new SqlDataAdapter(procedure, con))
                    {
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddRange(paramList.ToArray());
                        ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        //Method To get Single Data Table without search
        /* ****************************************************************************************************** */

        public DataTable getDetails(string procedure)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        dt = new DataTable();
                        con.Open();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }


        //Method To get Single Data Table without search
        /* ****************************************************************************************************** */

        public DataTable SearchMainBannerDetails(string procedure,string title)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@title", title);
                        dt = new DataTable();
                        con.Open();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        public DataTable getCartID(string procedure,string email)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@email", email);
                        dt = new DataTable();
                        con.Open();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        public DataTable getAdvertisement(string procedure, string company_name)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@company_name", company_name);
                        dt = new DataTable();
                        con.Open();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        //Method to getCart Details For Update
        /* ********************************************************** */
        public DataTable getCartDetailsforUpdate(string procedure, string email)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@email", email);
                        dt = new DataTable();
                        con.Open();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        //Method to get Small Banner List
        /************************************************************************************ */
        public DataTable getSmallBannerList(string procedure,string pagename)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@page", pagename);
                        dt = new DataTable();
                        con.Open();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        //Method to get OrderDetials for Update
        /***************************************************************************************** */
        public DataTable getOrderDetailsforUpdate(string procedure, string order_id)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Order_id", order_id);
                        dt = new DataTable();
                        con.Open();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        //Method To get OrderDetails
        /************************************************************************************************ */
        public DataSet getSpecificOrderDetails(string procedure, string order_id)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (da = new SqlDataAdapter(procedure, con))
                    {
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@order_id", order_id);
                        ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        //Method to get User Details For Update
        /***************************************************************************************** */

        public DataSet getUserDetails(string procedure, string email)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (da = new SqlDataAdapter(procedure, con))
                    {
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@email", email);
                        ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        //Method To Check Product in Cart
        /* ****************************************************************************** */
        public DataTable CheckProductIn_Cart(string procedure, string email,string product_id)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@email", email);
                        cmd.Parameters.AddWithValue("@product_id", product_id);
                        dt = new DataTable();
                        con.Open();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        //Method to get State According to Country
        /* ************************************************************************************************* */
        public DataTable getState(string procedure,int id)
        {
            try
            {
                 using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@id",id);
                        dt = new DataTable();
                        con.Open();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        //Method To Fetch Multiple Data Table without search
        /* ****************************************************************************************************** */

        public DataSet getMultiple(string procedure)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (da = new SqlDataAdapter(procedure, con))
                    {
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        //Method To getCartDetails to Display
        /* ****************************************************************************** */
        public DataSet getCartDetails(string procedure,string email)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (da = new SqlDataAdapter(procedure, con))
                    {
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@email", email);
                        ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        //Method to getOrder Details For Display
        /* ************************************************************* */
        public DataSet getOrderDetails(string procedure, string order_id)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (da = new SqlDataAdapter(procedure, con))
                    {
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@order_id", order_id);
                        ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        //method to check Stock 
        /* ************************************************************************************************/
        public DataSet getStockDetails(string procedure, string product_id)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (da = new SqlDataAdapter(procedure, con))
                    {
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@product_id",product_id);
                        ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        //Method to SearchProducts
        /********************************************************************************************/
        public DataTable searchProducts(string procedure, string searchtext)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@SearchText", searchtext);
                        dt = new DataTable();
                        con.Open();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        //Method To Sort List 
        /* ****************************************************************************************************** */
        public DataTable sortDetails(string procedure, List<SqlParameter> paramList)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddRange(paramList.ToArray());
                        dt = new DataTable();
                        con.Open();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public DataSet getDetailsBySearchValue(string procedure, List<SqlParameter> paramList)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (da = new SqlDataAdapter(procedure, con))
                    {
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddRange(paramList.ToArray());
                        ds = new DataSet();
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        /*common method to get product details by id and type */
        public DataTable getProductDetailsbyProductType(string procedure, string id, string type)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@type", type);
                        con.Open();
                        DataTable dt = new DataTable();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public int UpdateData(string procedure, List<SqlParameter> paramList)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddRange(paramList.ToArray());
                        con.Open();
                        int rows_affected = cmd.ExecuteNonQuery();
                        con.Close();
                        return rows_affected;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        /* common method to get all product details for update products*/
        public DataTable getRecordsBySearchValue(string procedure, string id)
        {
            try
            {
                using (con = ConClass.ConFun())
                {
                    using (cmd = new SqlCommand(procedure, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Search_Value", id);
                        con.Open();
                        DataTable dt = new DataTable();
                        dt.Load(cmd.ExecuteReader());
                        con.Close();
                        return dt;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
