﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm
{
    public partial class cart : System.Web.UI.Page
    {
        ProductClass music;
        DataTable dt;
        DataTable table;
        DataSet ds;
        List<string> list_id, list_type;
        CartClass update_cart;
        protected void Page_Load(object sender, EventArgs e)
        {
           
            if (!IsPostBack)
            {
                getCountries();
                if (Session["UserId"] != null)
                {
                    if (Request.QueryString["Id"] != null)
                    { 
                        string id = Request.QueryString["Id"];
                    string type = Request.QueryString["type"];
                    getProductListtoSave(id,type);
                    }

                    DisplayCartDetails();
                }
                else
                {
                if (Request.QueryString["Id"] != null)
                {
                    if (Request.Cookies["Id"] == null)
                    {
                        Response.Cookies["Id"].Value = Request.QueryString["Id"];
                        Response.Cookies["type"].Value = Request.QueryString["type"];
                        Response.Cookies["Id"].Expires = DateTime.Now.AddDays(1);
                        Response.Cookies["type"].Expires = DateTime.Now.AddDays(1);
                        list_id = ((Response.Cookies["Id"].Value).Split(',')).ToList();
                        list_type = ((Response.Cookies["type"].Value).Split(',')).ToList();
                        getProductList(list_id, list_type);
                        msg_sec.Visible = false;
                    }
                    else
                    {
                        if (!(Request.Cookies["Id"].Value).Contains(Request.QueryString["Id"]))
                        {
                            Response.Cookies["Id"].Value = Request.Cookies["Id"].Value + "," + Request.QueryString["Id"];
                            Response.Cookies["Id"].Expires = DateTime.Now.AddDays(1);
                            Response.Cookies["type"].Value = Request.Cookies["type"].Value + "," + Request.QueryString["type"];
                            Response.Cookies["type"].Expires = DateTime.Now.AddDays(1);
                            list_id = ((Response.Cookies["Id"].Value).Split(',')).ToList();
                            list_type = ((Response.Cookies["type"].Value).Split(',')).ToList();
                            getProductList(list_id, list_type);
                            msg_sec.Visible = false;
                        }
                        else
                        {
                            list_id = ((Request.Cookies["Id"].Value).Split(',')).ToList();
                            list_type = ((Request.Cookies["type"].Value).Split(',')).ToList();
                            getProductList(list_id, list_type);
                            msg_sec.Visible = false;
                        }
                    }                    
                }
                else if (Request.Cookies["Id"] != null && Request.Cookies["Id"].Value!="")
                {
                    list_id = ((Request.Cookies["Id"].Value).Split(',')).ToList();
                    list_type = ((Request.Cookies["type"].Value).Split(',')).ToList();
                    getProductList(list_id, list_type);
                    msg_sec.Visible = false;

                }
                else
                {
                    lbl_subtotal.Text = lbl_grand_total.Text = "0.00";
                    msg_sec.Visible = true;
                }
                copyCartInSession();
            }
                if (dl_cart_list.Items.Count == 0)
                {
                    btn_checkout.Visible = false;
                }
                else
                {
                    btn_checkout.Visible = true;
                }
            }
        }

        private void getProductList(List<string> musicId, List<string> type)
        {
            int sum = 0, mrp;
            music = new ProductClass();
            table = new DataTable();
            table.Columns.Add("id");
            table.Columns.Add("main_image");
            table.Columns.Add("title");
            table.Columns.Add("mrp");
            table.Columns.Add("type");
            table.Columns.Add("subtotal");
            table.Columns.Add("orignal_amount");
            table.Columns.Add("quantity");
            table.Columns.Add("stock");
            for (int i = 0; i < list_id.Count; i++)
            {
                dt = music.fetchMusicDetailsById(musicId[i], type[i]);
                if (dt.Rows.Count > 0)
                {
                    DataRow row = table.NewRow();
                    row["id"] = dt.Rows[0][0].ToString();
                    row["main_image"] = dt.Rows[0][1].ToString();
                    row["title"] = dt.Rows[0][2].ToString();
                    row["mrp"] = dt.Rows[0][3].ToString();
                    mrp = Convert.ToInt32(dt.Rows[0][3]);
                    sum += Convert.ToInt32(dt.Rows[0][3]);
                    row["type"] = dt.Rows[0][5].ToString();
                    row["subtotal"] = dt.Rows[0][4].ToString();
                    row["orignal_amount"] = dt.Rows[0][6].ToString();
                    row["quantity"] = "1";
                    row["stock"] = dt.Rows[0][7].ToString();
                    table.Rows.Add(row);
                }
                
            }
            dl_cart_list.DataSource = table;
            dl_cart_list.DataBind();
            for (int i = 0; i < table.Rows.Count; i++)
            {
                if (Convert.ToDecimal(table.Rows[i][3]) == Convert.ToDecimal(table.Rows[i][6]))
                {
                    (dl_cart_list.Items[i].FindControl("Label2") as Label).Visible = false;
                    (dl_cart_list.Items[i].FindControl("rs") as Label).Visible = false;
                }
                //if (Convert.ToInt32(table.Rows[i][8]) == 0)
                //{
                //    (dl_cart_list.Items[i].FindControl("rs") as Label).Text = "Out Of Stock";
                //    (dl_cart_list.Items[i].FindControl("Label2") as Label).Visible = false;
                //    (dl_cart_list.Items[i].FindControl("lbl_mrp") as Label).Visible = false;
                //    (dl_cart_list.Items[i].FindControl("lbl_mrp") as Label).Text = "00";
                //    (dl_cart_list.Items[i].FindControl("lb_decrement_qty") as LinkButton).Visible = false;
                //    (dl_cart_list.Items[i].FindControl("lb_increment_qty") as LinkButton).Visible = false;
                //    (dl_cart_list.Items[i].FindControl("txt_quantity") as TextBox).Visible = false;
                //    (dl_cart_list.Items[i].FindControl("lbl_subtotal_mrp") as Label).Visible = false;
                //    (dl_cart_list.Items[i].FindControl("lbl_subtotal_mrp") as Label).Text = "00";
                //}
            }
            
            if (Session["Cart"] != null)
            {
                sum = 0;
                table = Session["Cart"] as DataTable;
                for (int i = 0; i < dl_cart_list.Items.Count - 1; i++)
                {
                    (dl_cart_list.Items[i].FindControl("txt_quantity") as TextBox).Text = table.Rows[i][0].ToString();
                    (dl_cart_list.Items[i].FindControl("lbl_subtotal_mrp") as Label).Text = table.Rows[i][1].ToString();
                    sum = sum + Convert.ToInt32(Convert.ToDecimal(table.Rows[i][1].ToString()));

                }
                sum = sum + Convert.ToInt32(Convert.ToDecimal(dt.Rows[0][3]));
                getUpdatedDatalist();
            }
            lbl_subtotal.Text = lbl_grand_total.Text = sum.ToString() + ".00";
            if (ddl_countries.SelectedValue == "India" && Convert.ToDecimal(lbl_shippingcharges.Text) != 60&&sum<1000)
            {
                lbl_grand_total.Text = (Convert.ToDecimal(lbl_grand_total.Text) + 60).ToString();
                lbl_shippingcharges.Text = "60.00";
            }
            else if (ddl_countries.SelectedItem.Text == "India" && Convert.ToDecimal(lbl_shippingcharges.Text) == 60 && lbl_grand_total.Text == lbl_subtotal.Text && sum < 1000)
            {
                lbl_grand_total.Text = (Convert.ToDecimal(lbl_grand_total.Text)+ Convert.ToDecimal(lbl_shippingcharges.Text)).ToString();
            }
            lbl_empty_cart_msg.Visible = false;
        }

        //Method to delete product from cart list
        /*********************************************************************************************/

        protected void dl_cart_list_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals("Delete"))
            {
                if (Session["UserId"] != null)
                {
                    string prodid = (e.Item.FindControl("lbl_id") as Label).Text;
                    update_cart = new CartClass();
                    update_cart._product_id = prodid;
                    update_cart._email = Session["UserId"].ToString();
                    int i = update_cart.DeleteProductFromCart(update_cart);
                    DisplayCartDetails();
                    
                }
                else
                {
                    list_id = new List<string>();
                    list_type = new List<string>();

                    for (int i = 0; i < dl_cart_list.Items.Count; i++)
                    {
                        if (e.Item.ItemIndex != i)
                        {
                            Label id = dl_cart_list.Items[i].FindControl("lbl_id") as Label;
                            Label type = dl_cart_list.Items[i].FindControl("lbl_type") as Label;
                            list_id.Add(id.Text);
                            list_type.Add(type.Text);
                            copyCartInSession();
                        }
                    }
                    if (list_id.Count != 0)
                    {
                        Response.Cookies["Id"].Value = String.Join(",", list_id);
                        Response.Cookies["type"].Value = String.Join(",", list_type);
                        getProductList(list_id, list_type);
                        getUpdatedDatalist();
                        copyCartInSession();
                    }
                    else
                    {
                        HttpCookie clear = new HttpCookie("Id");
                        clear.Expires = DateTime.Now.AddDays(-1);
                        Response.Cookies.Add(clear);
                        HttpCookie cleartype = new HttpCookie("type");
                        cleartype.Expires = DateTime.Now.AddDays(-1);
                        Response.Cookies.Add(cleartype);
                        dl_cart_list.DataSource = null;
                        dl_cart_list.DataBind();
                        lbl_subtotal.Text = lbl_grand_total.Text = "0.00";
                        msg_sec.Visible = true;
                        Session["Cart"] = null;
                    }
                }
                if (dl_cart_list.Items.Count == 0)
                {
                    btn_checkout.Visible = false;
                }
                else
                {
                    btn_checkout.Visible = true;
                }
            }

            else if (e.CommandName == "Minus")
            {
               
                    //Method To Calculate cart quantity
                    getUpdatedDatalist();
                    if (Convert.ToInt32((e.Item.FindControl("txt_quantity") as TextBox).Text) > 1)
                    {
                        cartCalculate
                        (
                            (e.Item.FindControl("txt_quantity") as TextBox).Text,
                            (e.Item.FindControl("lbl_mrp") as Label).Text, e.Item.ItemIndex,
                            "minus"
                        );
                        if (ddl_countries.SelectedValue == "India" && Convert.ToDecimal(lbl_subtotal.Text) < 1000)
                        {
                            lbl_shippingcharges.Text = "60.00";
                            decimal grandtotal = Convert.ToDecimal(lbl_shippingcharges.Text) + Convert.ToDecimal(lbl_subtotal.Text);
                            lbl_grand_total.Text = grandtotal.ToString();
                            copyCartInSession();
                        }
                        else
                        {
                            lbl_shippingcharges.Text = "00.00";
                            decimal grandtotal = Convert.ToDecimal(lbl_subtotal.Text) - Convert.ToDecimal(lbl_shippingcharges.Text);
                            lbl_grand_total.Text = grandtotal.ToString();
                            copyCartInSession();
                        }
                  
                    if (Session["UserId"] != null)
                    {
                        UpdateCart();
                        DataTable dt = new DataTable();
                        UpdateCart();
                        update_cart = new CartClass();
                        dt = update_cart.getCartId(Session["UserId"].ToString());
                        update_cart._product_id = (e.Item.FindControl("lbl_id") as Label).Text;
                        update_cart._quantity = (e.Item.FindControl("txt_quantity") as TextBox).Text;
                        update_cart._subtotal = Convert.ToDecimal((e.Item.FindControl("lbl_subtotal_mrp") as Label).Text);
                        update_cart._cart_id = dt.Rows[0][0].ToString();
                        update_cart.updateCartProductTable(update_cart);
                    }
                    
                }
            }
            else if (e.CommandName == "Plus")
            {
               
                //Method To Calculate cart quantity
                cartCalculate
                    (
                        (e.Item.FindControl("txt_quantity") as TextBox).Text,
                        (e.Item.FindControl("lbl_mrp") as Label).Text, e.Item.ItemIndex,
                        "plus"
                    );
                getUpdatedDatalist();
                if (ddl_countries.SelectedValue == "India" && Convert.ToDecimal(lbl_subtotal.Text) < 1000)
                {
                    lbl_shippingcharges.Text = "60.00";
                    decimal grandtotal = Convert.ToDecimal(lbl_shippingcharges.Text) + Convert.ToDecimal(lbl_subtotal.Text);
                    lbl_grand_total.Text = grandtotal.ToString();
                    copyCartInSession();
                }
                else
                {
                    lbl_shippingcharges.Text = "00.00";
                    decimal grandtotal = Convert.ToDecimal(lbl_subtotal.Text) - Convert.ToDecimal(lbl_shippingcharges.Text);
                    lbl_grand_total.Text = grandtotal.ToString();
                    copyCartInSession();
                }
                table = new DataTable();
                table = (DataTable)dl_cart_list.DataSource;
               
                if (Session["UserId"] != null)
                {
                    DataTable dt = new DataTable();
                    UpdateCart();
                    update_cart = new CartClass();
                    dt = update_cart.getCartId(Session["UserId"].ToString());
                    update_cart._product_id=(e.Item.FindControl("lbl_id")as Label).Text;
                    update_cart._quantity = (e.Item.FindControl("txt_quantity") as TextBox).Text;
                    update_cart._subtotal = Convert.ToDecimal((e.Item.FindControl("lbl_subtotal_mrp") as Label).Text);
                    update_cart._cart_id = dt.Rows[0][0].ToString();
                    update_cart.updateCartProductTable(update_cart);
                }
                
            }

            else if (e.CommandName == "Details")
            {
               string type=(e.Item.FindControl("lbl_type") as Label).Text;
               if (type == "Movie")
               {
                   Response.Redirect("MovieDetails.aspx?Id=" + e.CommandArgument + "&type=" + type);
               }
               else if (type == "Music")
               {
                   Response.Redirect("MusicDetails.aspx?Id=" + e.CommandArgument + "&type=" + type);
               }
               else if (type == "Book")
               {
                   Response.Redirect("BookDetails.aspx?Id=" + e.CommandArgument + "&type=" + type);
               }
               else if (type == "Product")
               {
                   Response.Redirect("ProductDetails.aspx?Id=" + e.CommandArgument + "&type=" + type);
               }
                
            }
        }
            //Method to getProductDetails to save in cartTable
            /* ************************************************************ */
        decimal sum = 0, mrp;
        private void getProductListtoSave(string musicId, string type)
        {
            update_cart = new CartClass();
            music = new ProductClass();
                dt = music.fetchMusicDetailsById(musicId, type);
                mrp = Convert.ToDecimal(dt.Rows[0][3]);
                DataTable checkproduct = new DataTable();
                checkproduct = update_cart.CheckProductInCart(Session["UserId"].ToString(),musicId);
                if (checkproduct.Rows.Count <= 0)
                {
                    getCartDetails();
                    DataTable dt1 = new DataTable();
                    dt1 = update_cart.getCartId(Session["UserId"].ToString());
                    if (dt1.Rows.Count > 0)
                    {
                        update_cart._product_id = dt.Rows[0][0].ToString();
                        update_cart._product_image = dt.Rows[0][1].ToString();
                        update_cart._product_title = dt.Rows[0][2].ToString();
                        update_cart._product_mrp = Convert.ToDecimal(dt.Rows[0][3].ToString());
                        update_cart._subtotal = Convert.ToDecimal(dt.Rows[0][4].ToString());
                        update_cart._quantity = "1";
                        update_cart._original_price = Convert.ToDecimal(dt.Rows[0][6].ToString());
                        update_cart._cart_id = dt1.Rows[0][0].ToString();
                        update_cart._email = Session["UserId"].ToString();
                        update_cart.insertCartProductDetails(update_cart);
                    }
                }
        }

        //Method to GetCartDetails For Update and insertCart Details
        // * ********************************************** */
        private void getCartDetails()
        {
            string email = Session["UserId"].ToString();
            DataTable dt = new DataTable();
            update_cart = new CartClass();
            dt = update_cart.getCartDetailForUpdate(email);
            if (dt.Rows.Count > 0)
            {
                update_cart._email = Session["UserId"].ToString();
                update_cart._cart_id = dt.Rows[0][0].ToString();
                update_cart._total_amount = Convert.ToDecimal(dt.Rows[0][2])+mrp;
                update_cart._cart_subtotal = Convert.ToDecimal(dt.Rows[0][4].ToString())+mrp;
                update_cart._country = ddl_countries.SelectedItem.Text;
                update_cart.insertCartDetails(update_cart);
            }
            else
            {
                update_cart._cart_id = AutoIncrementCode.get_CartId("spAutoIncrementCartCode");
                update_cart._email=email;
                update_cart._delivery_charges =Convert.ToDecimal(lbl_shippingcharges.Text);
                update_cart._total_amount = mrp;
                update_cart._cart_subtotal = mrp;
                update_cart._country = ddl_countries.SelectedItem.Text;
                //update_cart._tax = Convert.ToDecimal("50");
                update_cart.insertCartDetails(update_cart);
            }
        }

        //Method to bind countries to dropdown
        /*************************************************************  */
        private void getCountries()
        {
            update_cart = new CartClass();
            dt = update_cart.getCountries();
            ddl_countries.DataTextField = "name";
            ddl_countries.DataSource = dt;
            ddl_countries.DataBind();
            ddl_countries.SelectedItem.Text = "--Select Country--";
           
        }

        //Method to update cart table on update quantity
        /* ********************************************************** */
        private void UpdateCart()
        {
            try
            {
                update_cart = new CartClass();
                update_cart._email = Session["UserId"].ToString();
                update_cart._delivery_charges = Convert.ToDecimal(lbl_shippingcharges.Text);
                update_cart._cart_subtotal = Convert.ToDecimal(lbl_subtotal.Text);
                update_cart._total_amount = Convert.ToDecimal(lbl_grand_total.Text);
                update_cart.updateCartProductDetails(update_cart);
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        //Method to get Cart Details from Database
        /* ************************************************************************* */
        private void DisplayCartDetails()
        {
            try
            {
                DataSet ds;
                update_cart = new CartClass();
                ds =update_cart.GetCartDetailsForDisplay(Session["UserId"].ToString());
                if (ds.Tables[0].Rows.Count > 0 && ds.Tables[1].Rows.Count>0)
                {
                    dl_cart_list.DataSource = ds.Tables[1];
                    dl_cart_list.DataBind();
                    for (int i = 0; i <ds.Tables[1].Rows.Count; i++)
                    {
                        if (Convert.ToDecimal(ds.Tables[1].Rows[i][6]) == Convert.ToDecimal(ds.Tables[1].Rows[i][8]))
                        {
                            (dl_cart_list.Items[i].FindControl("Label2") as Label).Visible = false;
                            (dl_cart_list.Items[i].FindControl("rs") as Label).Visible = false;
                        }
                    }
            
                    lbl_subtotal.Text = ds.Tables[0].Rows[0][5].ToString();
                    lbl_shippingcharges.Text = ds.Tables[0].Rows[0][2].ToString();
                    lbl_grand_total.Text = ds.Tables[0].Rows[0][3].ToString();
                    ddl_countries.Text = ds.Tables[0].Rows[0][6].ToString();
                    //lbl_tax.Text = ds.Tables[0].Rows[0][4].ToString();
                    msg_sec.Visible = false;
                }
                else
                {
                    dl_cart_list.DataSource = null;
                    dl_cart_list.DataBind();
                    lbl_subtotal.Text = "00";
                    lbl_shippingcharges.Text = "00";
                    lbl_grand_total.Text = "00";
                    //lbl_tax.Text = "00";
                    msg_sec.Visible = true;
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        //Method to store datalist in Session
        /* ************************************************************************************** */

        private void getUpdatedDatalist()
        {
            table = new DataTable();

            table.Columns.Add("quantity");
            table.Columns.Add("subTotal");
            foreach (DataListItem item in dl_cart_list.Items)
            {
                DataRow row = table.NewRow();
                row["quantity"] = (item.FindControl("txt_quantity") as TextBox).Text;
                row["subTotal"] = (item.FindControl("lbl_subtotal_mrp") as Label).Text;
                table.Rows.Add(row);
            }
            Session["Cart"] = table;
        }

        // Method To Calculate Cart Total on updating Quantity
        /* ************************************************************************************** */
        protected void btn_update_cart_Click(object sender, EventArgs e)
        {
            //cartCalculate();
        }

        // Method To Calculate Cart Total on updating Quantity
        /* ************************************************************************************** */
        private void cartCalculate(string quantity, string price, int index, string operation)
        {

            if (operation.Equals("minus"))
            {
                (dl_cart_list.Items[index].FindControl("txt_quantity") as TextBox).Text =
                    (Convert.ToInt32((dl_cart_list.Items[index].FindControl("txt_quantity") as TextBox).Text) - 1).ToString();
                lbl_subtotal.Text = (Convert.ToDecimal(lbl_subtotal.Text) - Convert.ToDecimal(price)).ToString();
                
            }

            if (operation.Equals("plus"))
            {
                CartClass cart = new CartClass();
                ds=cart.getstockDetails((dl_cart_list.Items[index].FindControl("lbl_id") as Label).Text);
                if (Convert.ToInt32(ds.Tables[0].Rows[0][0]) <= Convert.ToInt32((dl_cart_list.Items[index].FindControl("txt_quantity") as TextBox).Text))
                {
                    ClientMessageBox.Show("Avilable Stock is", this);
                }
                else
                {
                    (dl_cart_list.Items[index].FindControl("txt_quantity") as TextBox).Text =
                   (Convert.ToInt32((dl_cart_list.Items[index].FindControl("txt_quantity") as TextBox).Text) + 1).ToString();
                    lbl_subtotal.Text = (Convert.ToDecimal(lbl_subtotal.Text) + Convert.ToDecimal(price)).ToString();
                }
            }

            (dl_cart_list.Items[index].FindControl("lbl_subtotal_mrp") as Label).Text =
            (Convert.ToDecimal(price) * Convert.ToInt32((dl_cart_list.Items[index].FindControl("txt_quantity") as TextBox).Text)).ToString();
            lbl_grand_total.Text = lbl_subtotal.Text;
        }

        protected void btn_continue_shoopping_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }

        public void copyCartInSession()
        {
            table = new DataTable();
            table.Columns.Add("ProductID");
            table.Columns.Add("Quantity");
            table.Columns.Add("SubTotal");
            table.Columns.Add("ProductTitle");
            table.Columns.Add("ProductImage");
            table.Columns.Add("ProductMrp");
            table.Columns.Add("original_amount");
           
                foreach (DataListItem item in dl_cart_list.Items)
                {
                    DataRow row = table.NewRow();
                    row["ProductID"] = (item.FindControl("lbl_id") as Label).Text;
                    row["Quantity"] = (item.FindControl("txt_quantity") as TextBox).Text;
                    row["SubTotal"] = (item.FindControl("lbl_subtotal_mrp") as Label).Text;
                    row["ProductTitle"] = (item.FindControl("lb_music_title") as LinkButton).Text;
                    row["ProductImage"] = (item.FindControl("music_image") as ImageButton).ImageUrl;
                    row["ProductMrp"] = (item.FindControl("lbl_mrp") as Label).Text;
                    row["original_amount"] = (item.FindControl("Label2") as Label).Text;
                    table.Rows.Add(row);
                    Session["Checkout"] = table;
                }
            
            DataTable CartTotal = new DataTable();
            CartTotal.Columns.Add("SubTotal");
            CartTotal.Columns.Add("Tax");
            CartTotal.Columns.Add("ShippingCharges");
            CartTotal.Columns.Add("GrandTotal");
            CartTotal.Columns.Add("Country");

            DataRow row1 = CartTotal.NewRow();
            row1["SubTotal"] = lbl_subtotal.Text;
            //row1["Tax"] = lbl_tax.Text;
            row1["ShippingCharges"] = lbl_shippingcharges.Text;
            row1["GrandTotal"] = lbl_grand_total.Text;
            row1["Country"] = ddl_countries.SelectedItem.Text;
            CartTotal.Rows.Add(row1);
            Session["TotalAmount"] = CartTotal;
        }
        protected void btn_checkout_Click(object sender, EventArgs e)
        {
            if (ddl_countries.SelectedItem.Text == "--Select Country--")
            {
                ClientMessageBox.Show("Please Select Your Country", this);
            }
            else 
            {
                Response.Redirect("CheckOut.aspx");
            }
        }

        protected void ddl_countries_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl_countries.SelectedValue == "India"&&Convert.ToDecimal(lbl_subtotal.Text)<=1000)
            {
                lbl_shippingcharges.Text = "60.00";
                decimal grandtotal=Convert.ToDecimal(lbl_shippingcharges.Text) +Convert.ToDecimal(lbl_subtotal.Text);
                lbl_grand_total.Text = grandtotal.ToString();
                if (Session["UserId"] != null)
                {
                    update_cart = new CartClass();
                    dt = update_cart.getCartDetailForUpdate(Session["UserId"].ToString());
                    update_cart._email = Session["UserId"].ToString();
                    update_cart._cart_id = dt.Rows[0][0].ToString();
                    update_cart._delivery_charges = Convert.ToDecimal(lbl_shippingcharges.Text);
                    update_cart._cart_subtotal = Convert.ToDecimal(lbl_subtotal.Text);
                    update_cart._total_amount = Convert.ToDecimal(lbl_grand_total.Text);
                    update_cart._country = ddl_countries.SelectedItem.Text;
                    update_cart.insertCartDetails(update_cart);
                }
                else
                {
                    copyCartInSession();
                }
            }
            else
            {
                lbl_shippingcharges.Text = "00.00";
                decimal grandtotal = Convert.ToDecimal(lbl_subtotal.Text) - Convert.ToDecimal(lbl_shippingcharges.Text);
                lbl_grand_total.Text = grandtotal.ToString();
                if (Session["UserId"] != null&&dl_cart_list.Items.Count>0)
                {
                    update_cart = new CartClass();
                    dt = update_cart.getCartDetailForUpdate(Session["UserId"].ToString());
                    update_cart._email = Session["UserId"].ToString();
                    update_cart._cart_id = dt.Rows[0][0].ToString();
                    update_cart._delivery_charges = Convert.ToDecimal(lbl_shippingcharges.Text);
                    update_cart._cart_subtotal = Convert.ToDecimal(lbl_subtotal.Text);
                    update_cart._total_amount = Convert.ToDecimal(lbl_grand_total.Text);
                    update_cart._country = ddl_countries.SelectedItem.Text;
                    update_cart.insertCartDetails(update_cart);
                }
                else
                {
                    copyCartInSession();
                }
            }
        }
    }
}