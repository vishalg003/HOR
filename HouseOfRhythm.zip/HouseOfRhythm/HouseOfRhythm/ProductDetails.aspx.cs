﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayerHor;

namespace HouseOfRhythm
{
    public partial class ProductDetails1 : System.Web.UI.Page
    {
        BusinessLayerHor.ProductDetails productdetails;
        DataTable dt;
        ProductClass productClass;
        protected void Page_Load(object sender, EventArgs e)
        {
            getSingleBannerDetails();
            if (!IsPostBack)
            {
                if (Request.QueryString["Id"] != null)
                {
                    DisplayProductDetails(Request.QueryString["Id"], Request.QueryString["type"]);
                }
            }
        }

        public void DisplayProductDetails(string id, string type)
        {
            try
            {
                productdetails = new BusinessLayerHor.ProductDetails();
                dt = productdetails.getProductDetailsByType(id, type);
                lblprodtitle.Text = dt.Rows[0][0].ToString();
                lbl_pro_description.Text = dt.Rows[0][2].ToString();
                lblbarcode.Text = dt.Rows[0][7].ToString();
                Productimage.ImageUrl = dt.Rows[0][6].ToString();
                if ((int)dt.Rows[0][5] > 0)
                {
                    lblprice.Text = ((Convert.ToInt32(Convert.ToDecimal(dt.Rows[0][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(dt.Rows[0][4].ToString())) * ((int)dt.Rows[0][5]))/100).ToString();
                    lbl_discount.Text = "Rs. " + dt.Rows[0][4].ToString();
                    lbl_discount.Visible = true;
                }
                else
                {
                    lbl_discount.Visible = false;
                    lblprice.Text = dt.Rows[0][4].ToString();
                }
                if (Convert.ToInt32(Convert.ToDecimal(dt.Rows[0][3].ToString())) > 0)
                {
                    lbl_stock_count.Text = "Only : " + dt.Rows[0][3].ToString() + " Left";
                    lbl_stock_msg.Text = "In Stock";
                   // add_to_Cart.Enabled = true;
                }
                else
                {
                    lbl_stock_msg.Text = "Out of Stock";
                    lbl_stock_msg.ForeColor = System.Drawing.Color.Red;
                    //add_to_Cart.Enabled = false;
                }


                lblshortdescription.Text = dt.Rows[0][1].ToString().Replace("\n", "<br />");
                
                //getRelatedMusicDetails(lblartist.Text, lblgenre.Text, lblcomposer.Text);
            }
            catch (Exception)
            {

                throw;
            }
        }

        //Method to add displayed product to cart
        /**************************************************************************************************/
        protected void add_to_cart_click(object sender, EventArgs e)
        {
            Response.Redirect("cart.aspx?Id=" + Request.QueryString["Id"] + "&type=" + Request.QueryString["type"]);
        }


        private void getSingleBannerDetails()
        {
            InsertBannerDetails insertBannerDetails = new InsertBannerDetails();
            DataTable table = insertBannerDetails.getSinlgeBannerDetails("ProductList");
            //string path = table.Rows[0][0].ToString();
            if (table.Rows.Count > 0)
            {
                lbl_banner_title.Text = table.Rows[0][1].ToString();
                lbl_content.Text = table.Rows[0][2].ToString();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "setImage('" + table.Rows[0][0].ToString() + "')", true);
            }
        }
        //Method to add displayed product to wishlist
        /**************************************************************************************************/
        protected void lb_add_wishlist_Click(object sender, EventArgs e)
        {
            if (Session["UserID"] == null)
            {
                lbl_wishlist_msg.Text = "Please Login First";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
            }
            else
            {
                productClass = new ProductClass();
                productClass.title = lblprodtitle.Text;
                productClass.mrp = Convert.ToDecimal(lblprice.Text);
                productClass.user_id = Session["UserId"].ToString();
                productClass.product_id = Request.QueryString["Id"];
                productClass.prod_image = Productimage.ImageUrl;
                int i = productClass.addMusicDetailsToWishlist(productClass);

                if (i >= 1)
                {
                    lbl_wishlist_msg.Text = "Product Addes To Wishlist";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                }
            }
        }
    }
}