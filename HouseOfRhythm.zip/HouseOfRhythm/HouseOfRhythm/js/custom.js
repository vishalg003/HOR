// JavaScript Document
$(function () {
    "use strict";

    function responsive_dropdown() {
        /* ---- For Mobile Menu Dropdown JS Start ---- */
        $('#menu span.opener').on("click", function () {
            var menuopener = $(this);
            if (menuopener.hasClass("plus")) {
                menuopener.parent().find('.mobile-sub-menu').slideDown();
                menuopener.removeClass('plus');
                menuopener.addClass('minus');
            }
            else {
                menuopener.parent().find('.mobile-sub-menu').slideUp();
                menuopener.removeClass('minus');
                menuopener.addClass('plus');
            }
            return false;
        });
        /* ---- For Mobile Menu Dropdown JS End ---- */
        /* ---- For Sidebar JS Start ---- */
        $('.sidebar-box span.opener').on("click", function () {
            var sidebaropener = $(this);
            if (sidebaropener.hasClass("plus")) {
                sidebaropener.parent().find('.sidebar-contant').slideDown();
                sidebaropener.removeClass('plus');
                sidebaropener.addClass('minus');
            }
            else {
                sidebaropener.parent().find('.sidebar-contant').slideUp();
                sidebaropener.removeClass('minus');
                sidebaropener.addClass('plus');
            }
            return false;
        });
        /* ---- For Sidebar JS End ---- */
        /* ---- For Footer JS Start ---- */
        $('.footer-static-block span.opener').on("click", function () {
            var footeropener = $(this);
            if (footeropener.hasClass("plus")) {
                footeropener.parent().find('.footer-block-contant').slideDown();
                footeropener.removeClass('plus');
                footeropener.addClass('minus');
            }
            else {
                footeropener.parent().find('.footer-block-contant').slideUp();
                footeropener.removeClass('minus');
                footeropener.addClass('plus');
            }
            return false;
        });
        /* ---- For Footer JS End ---- */

        /*---Mobile menu icon Start---*/
        $('.navbar-toggle').on("click", function () {
            var menu_id = $('#menu');
            var nav_icon = $('.navbar-toggle i');
            if (menu_id.hasClass('menu-open')) {
                menu_id.removeClass('menu-open');
                nav_icon.removeClass('fa-close');
                nav_icon.addClass('fa-bars');
            } else {
                menu_id.addClass('menu-open');
                nav_icon.addClass('fa-close');
                nav_icon.removeClass('fa-bars');
            }
        });
        /*---Mobile menu icon End---*/
    }


    function search_open() {
        /* ----- Search open close Start  ------ */
        $('.search-opener').on("click", function () {
            var topsearch = $('.top-search-bar');
            if (topsearch.hasClass('open')) {
                topsearch.removeClass('open');
            } else {
                topsearch.addClass('open');
            }
        });
        /* ----- Search open close Start  ------ */
    }

    function owlcarousel_slider() {
        /* ------------ OWL Slider Start  ------------- */
        /* ----- pro_cat_slider Start  ------ */
        $('.pro_cat_slider').owlCarousel({
            items: 4,
            navigation: true,
            pagination: false,
            itemsDesktop: [1199, 4],
            itemsDesktopSmall: [991, 3],
            itemsTablet: [768, 2],
            itemsTabletSmall: false,
            itemsMobile: [419, 1]
        });
        /* ----- pro_cat_slider End  ------ */

        /* ----- best-seller-pro Start  ------ */
        $('.best-seller-pro').owlCarousel({
            items: 2,
            navigation: true,
            pagination: false,
            itemsDesktop: [1199, 2],
            itemsDesktopSmall: [991, 1],
            itemsTablet: [767, 2],
            itemsTabletSmall: false,
            itemsMobile: [450, 1]
        });
        /* ----- best-seller-pro End  ------ */

        /* ----- blog_slider Start  ------ */
        $('.blog_slider').owlCarousel({
            items: 3,
            navigation: true,
            pagination: false,
            itemsDesktop: [1199, 3],
            itemsDesktopSmall: [991, 2],
            itemsTablet: [768, 2],
            itemsTabletSmall: false,
            itemsMobile: [419, 1]
        });
        /* ----- blog_slider End  ------ */

        /* ----- brand-logo Start  ------ */
        $('#brand-logo').owlCarousel({
            items: 5,
            navigation: true,
            pagination: false,
            itemsDesktop: [1199, 3],
            itemsDesktopSmall: [991, 3],
            itemsTablet: [768, 2],
            itemsTabletSmall: false,
            itemsMobile: [479, 1]
        });
        /* ----- brand-logo End  ------ */

        /* ---- Testimonial Start ---- */
        $("#client, .main-banner").owlCarousel({

            //navigation : true,  Show next and prev buttons
            slideSpeed: 300,
            paginationSpeed: 400,
            autoPlay: true,
            pagination: false,
            singleItem: true,
            navigation: true
        });
        /* ----- Testimonial End  ------ */

        /* ------------ OWL Slider End  ------------- */
    }

    function scrolltop_arrow() {
        /* ---- Page Scrollup JS Start ---- */
        //When distance from top = 250px fade button in/out
        $(window).scroll(function () {
            var scrollup = $('#scrollup');
            if ($(this).scrollTop() > 250) {
                scrollup.fadeIn(300);
            } else {
                scrollup.fadeOut(300);
            }
        });
        //On click scroll to top of page t = 1000ms
        $('#scrollup').on("click", function () {
            $("html, body").animate({ scrollTop: 0 }, 1000);
            return false;
        });
        /* ---- Page Scrollup JS End ---- */
    }


    function custom_tab() {
        /* ----------- product category Tab Start  ------------ */


        $('.tab-stap').on('click', 'li', function () {
            $('.tab-stap li').removeClass('active');
            $(this).addClass('active');

            $(".product-slider-main").fadeOut();
            var currentLiID = $(this).attr('id');
            $("#data-" + currentLiID).fadeIn();
            return false;
        });
        /* ------------ product category Tab End  ------------ */
//        /* ------------ Account Tab JS Start ------------ */
//        $('.account-tab-stap').on('click', 'li', function () {
//            $('.account-tab-stap li').removeClass('active');
//            $(this).addClass('active');

//            $(".account-content").fadeOut();
//            var currentLiID = $(this).attr('class');
//            $(".data_" + currentLiID).fadeIn();
//            return false;
//        });
        /* ------------ Account Tab JS End ------------ */

        /* ------------ Account Tab JS Start ------------ */
        $(".step1").click(function () {
            $(".data_step1").fadeIn();
            $(".step1").addClass("active");
            $(".step2, .step3, .step4, .step5").removeClass("active");
            $(".data_step3, .data_step3, .data_step4, .data_step5").fadeOut();
        });

        $(".step2").click(function () {
            $(".data_step2").fadeIn();
            $(".step2").addClass("active");
            $(".step1, .step3, .step4, .step5").removeClass("active");
            $(".data_step1, .data_step3, .data_step4, .data_step5").fadeOut();
        });

        $(".step3").click(function () {
            $(".data_step3").fadeIn();
            $(".step3").addClass("active");
            $(".step1, .step2, .step4, .step5").removeClass("active");
            $(".data_step1, .data_step2, .data_step4, .data_step5").fadeOut();
        });

        $(".step4").click(function () {
            $(".data_step4").fadeIn();
            $(".step4").addClass("active");
            $(".step1, .step2, .step3, .step5").removeClass("active");
            $(".data_step1, .data_step2, .data_step3, .data_step5").fadeOut();
        });

        $(".step5").click(function () {
            $(".data_step5").fadeIn();
            $(".step5").addClass("active");
            $(".step1, .step3, .step4, .step2").removeClass("active");
            $(".data_step1, .data_step2, .data_step3, .data_step4").fadeOut();
        });

        $(document).ready(function () {
            $(".btn-tracks").click(function () {
                $(".track-list").slideToggle();
            });
        });

        $(document).ready(function () {
            $(".img-sec").hover(function () {
                $(this).children(".expand-icon").css({
                    'bottom': '0px',
                    'transition': 'bottom ease .6s',
                    '-moz-transition' : 'bottom ease .6s',
                    '-webkit-transition' : 'bottom ease .6s',
                    '-o-transition' : 'bottom ease .6s', });
            });
            $(".img-sec").mouseleave(function () {
                $(this).children(".expand-icon").css({
                    'bottom': '-70px',
                    'transition': 'bottom ease .6s',
                    '-moz-transition' : 'bottom ease .6s',
                    '-webkit-transition' : 'bottom ease .6s',
                    '-o-transition' : 'bottom ease .6s', });
            });
        });

        /* ------------ Account Tab JS End ------------ */

        /* ------------ checkout-step Tab JS Start ------------ */
        $('.checkout-tab-stap').on('click', 'li', function () {
            $('.checkout-tab-stap li').removeClass('active');
            $(this).addClass('active');

            $(".checkout-content").fadeOut();
            var currentLiID = $(this).attr('id');
            $("#data-" + currentLiID).fadeIn();
        });
        /* ------------ checkout-step Tab JS End ------------ */
    }

    function setminheight() {
        $(".pro_cat").css("min-height", $(".product-slider-main").height());
        $(".pro-detail-main").css("min-height", $(".special-products-block").height());
    }

    /* Vertical menu slider STRAT */
    $(document).ready(function (e) {
        $(".main-ul > li:has(ul)").click(function () {
            if ($(this).hasClass("active1")) {

                $(this).removeClass("active1");
                $(this).find(".second-main").slideUp();
            }
            else {
                $(".second-main").slideUp();
                $(".main-ul > .main-li").removeClass("active1");
                $(this).addClass("active1");
                $(this).find(".second-main").slideDown();
            }

        });

        $(".second-main > li:has(ul)").click(function (e) {

            if ($(this).hasClass("active2")) {
                e.stopPropagation();
                $(this).removeClass("active2");
                $(this).children(".third-main").slideUp();
            }
            else {

                e.stopPropagation();
                $(".third-main").slideUp();
                $(".second-main > li").removeClass("active2");
                $(this).addClass("active2");
                $(this).children(".third-main").slideDown();
            }

        });

        $(".third-main > li:has(ul)").click(function (e) {

            if ($(this).hasClass("active3")) {
                e.stopPropagation();
                $(this).removeClass("active3");
                $(this).children(".forth-main").slideUp();
            }
            else {

                e.stopPropagation();
                $(".forth-main").slideUp();
                $(".third-main > .third-li").removeClass("active3");
                $(this).addClass("active3");
                $(this).children(".forth-main").slideDown();
            }

        });

        $("li").click(function (e) {
            e.stopPropagation();
        });


        $(".sidebar-contant ul li > a").click(function (e) {
            e.preventDefault();
        });
    });
    /* Vertical menu slider END */

    /* Enable, Disable Add To Cart Button */

//        $(document).ready(function(){
//            
//        });

    /* End Enable, Disable Add To Cart Button */

    /* Price-range Js Start 
    function price_range() {
        var amount = $(".price-txt");
        var sliderrange = $("#slider-range");
        var val1;
        var val2;
        sliderrange.slider({
            range: true,
            min: 100,
            max: 800,
            values: [200, 400],
            slide: function (event, ui) {
                val1 = ui.values[0];
                val2 = ui.values[1];
                amount.val("Rs." + ui.values[0] + " - Rs." + ui.values[1]);
                
            },
            stop: function(event, ui)
            {
                slideText();
            }
        });
        amount.val("Rs." + sliderrange.slider("values", 0) +
      " - Rs." + sliderrange.slider("values", 1));
    }

    function slideText()
    {
        alert("hello");
    }
     Price-range Js End */


    /* Product Detail Page Tab JS Start */
    function description_tab() {
        $("#tabs li a").on("click", function (e) {
            var title = $(e.currentTarget).attr("title");
            $("#tabs li a").removeClass("selected")
            $(".tab_content li div").removeClass("selected")
            $(".tab-" + title).addClass("selected")
            $(".items-" + title).addClass("selected")
            $("#items").attr("class", "tab-" + title);

            return false;
        });
    }
    /* Product Detail Page Tab JS End */

    $(document).on("ready", function () {
        owlcarousel_slider(); responsive_dropdown(); description_tab(); scrolltop_arrow(); setminheight(); custom_tab(); search_open();
    });

    $(window).on("resize", function () {
        setminheight();
    });
});

  $( window ).on( "load", function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");
});