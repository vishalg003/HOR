﻿
/* JQuery Date Picker js Start */
$(function () {
    $(".input-Resease").datepicker({
        changeMonth: true,
        changeYear: true

    });
    $(".input-Resease").datepicker("option", "dateFormat", "d MM, yy");
});
/* JQuery Date Picker js End */

/* JQuery Category Page Tabs js Start */
$(document).ready(function () {

    $('ul.tabs li').click(function () {
        var tab_id = $(this).attr('data-tab');

        $('ul.tabs li').removeClass('current');
        $('.tab-content').removeClass('current');

        $(this).addClass('current');
        $("#" + tab_id).addClass('current');
    });

});

$(document).ready(function () {

    $('ul.tabs2 li').click(function () {
        var tab_id = $(this).attr('data-tab');

        $('ul.tabs2 li').removeClass('current');
        $('.tab-content').removeClass('current');

        $(this).addClass('current');
        $("#" + tab_id).addClass('current');
    });

});

/* JQuery Category Page Tabs js Ends */

/* Jquery range Date picker starts */
$(function () {
    var dateFormat = "mm/dd/yy",
      from = $(".from")
        .datepicker({
            defaultDate: "+1w",
            changeMonth: true,
            changeYear: true
        })
        .on("change", function () {
            to.datepicker("option", "minDate", getDate(this));
        }),
      to = $(".to").datepicker({
          defaultDate: "+1w",
          changeMonth: true,
          changeYear: true
      })
      .on("change", function () {
          from.datepicker("option", "maxDate", getDate(this));
      });

    function getDate(element) {
        var date;
        try {
            date = $.datepicker.parseDate(dateFormat, element.value);
        } catch (error) {
            date = null;
        }

        return date;
    }
});
/* Jquery range Date picker ends */

/* Jquery for entering only number in textbox starts */

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

/* Jquery for entering only number in textbox Ends */

/* Jquery for entering only TEXT in textbox starts */

function isAlphabetKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    //alert(charCode)
    if ((charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 122) && (charCode < 32 || charCode > 32))
        return false;

    return true;
}

/* Jquery for entering only TEXT in textbox Ends */

/* Jquery for entering only Single in textbox starts */
function fun_AllowOnlyAmountAndDot(txt) {
    if (event.keyCode > 47 && event.keyCode < 58 || event.keyCode == 46) {
        var txtbx = document.getElementById(txt);
        var amount = document.getElementById(txt).value;
        var present = 0;
        var count = 0;

        if (amount.indexOf(".", present) || amount.indexOf(".", present + 1));
        {
            // alert('0');
        }

        /*if(amount.length==2)
        {
        if(event.keyCode != 46)
        return false;
        }*/
        do {
            present = amount.indexOf(".", present);
            if (present != -1) {
                count++;
                present++;
            }
        }
        while (present != -1);
        if (present == -1 && amount.length == 0 && event.keyCode == 46) {
            event.keyCode = 0;
            //alert("Wrong position of decimal point not  allowed !!");
            return false;
        }

        if (count >= 1 && event.keyCode == 46) {

            event.keyCode = 0;
            //alert("Only one decimal point is allowed !!");
            return false;
        }
        if (count == 1) {
            var lastdigits = amount.substring(amount.indexOf(".") + 1, amount.length);
            if (lastdigits.length >= 15) {
                //alert("Two decimal places only allowed");
                event.keyCode = 0;
                return false;
            }
        }
        return true;
    }
    else {
        event.keyCode = 0;
        //alert("Only Numbers with dot allowed !!");
        return false;
    }

}

