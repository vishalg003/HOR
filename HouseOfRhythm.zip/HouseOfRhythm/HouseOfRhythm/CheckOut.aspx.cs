﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm
{
    public partial class CheckOut : System.Web.UI.Page
    {
        CartClass checkout;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] == null)
                {
                    Session["url"] = HttpContext.Current.Request.Url.AbsoluteUri;
                    Response.Redirect("login.aspx");
                }
                else
                {
                    displayUserDetails();
                    shippingaddres.Visible = false;
                    
                }
            }
        }

        private void displayUserDetails()
        {
            try
            {
                string name="";
                checkout = new CartClass();
                dt = new DataTable();
                dt=checkout.getUserDetailsForCheckout(Session["UserId"].ToString());
                name = dt.Rows[0][0].ToString()+" " + dt.Rows[0][1].ToString();
                lblname.Text = name;
                lbladdress.Text = dt.Rows[0][2].ToString();
                lbllocality.Text = dt.Rows[0][3].ToString()+", " + dt.Rows[0][4].ToString()+", " + dt.Rows[0][5].ToString();
                lblstate.Text = dt.Rows[0][6].ToString() + " (" + dt.Rows[0][7].ToString() + ")";
                lblmobileno.Text = dt.Rows[0][8].ToString();
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable Checkout = new DataTable();
                Checkout.Columns.Add("Name");
                Checkout.Columns.Add("Address");
                Checkout.Columns.Add("Locality");
                Checkout.Columns.Add("City");
                Checkout.Columns.Add("Pincode");
                Checkout.Columns.Add("Country");
                Checkout.Columns.Add("State");
                Checkout.Columns.Add("MobileNo");

                DataRow row = Checkout.NewRow();
                row["Name"] = ShipppingFirstName.Text + " " + ShippingLastName.Text;
                row["Address"] = ShippingAddressAddress.Text;
                row["Country"] = ddl_country.SelectedValue;
                row["State"] = ddlstate.SelectedValue;
                row["City"] = ddlcity.SelectedValue;
                row["Locality"] = txtlocality.Text;
                row["Pincode"] = ShippingPostalCode.Text;
                row["MobileNo"] = ShippingContactName.Text;
                Checkout.Rows.Add(row);
                Session["ShippingDetails"] = Checkout;
                Response.Redirect("Order-overview.aspx");
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        private void getCountries()
        {
            CartClass cart = new CartClass();
            dt = cart.getCountries();
            ddl_country.DataTextField = "name";
            ddl_country.DataValueField = "id";
            ddl_country.DataSource = dt;
            ddl_country.DataBind();
            ddl_country.SelectedItem.Text = "--Select Country--";
        }

        private void getState()
        {
            CartClass cart = new CartClass();
            dt = cart.getStates(Convert.ToInt32(ddl_country.SelectedValue));
            if (dt.Rows.Count > 0)
            {
                ddlstate.DataTextField = "name";
                ddlstate.DataValueField = "id";
                ddlstate.DataSource = dt;
                ddlstate.DataBind();
            }
        }

        private void getCity()
        {
            CartClass cart = new CartClass();
            dt = cart.getCities(Convert.ToInt32(ddlstate.SelectedValue));
            if (dt.Rows.Count > 0)
            {
                ddlcity.DataTextField = "name";
                ddlcity.DataSource = dt;
                ddlcity.DataBind();
            }
        }
        protected void chk_billing_address_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_billing_address.Checked)
            {
                shippingaddres.Visible = true;
                getCountries();
            }
            else
            {
                shippingaddres.Visible = false;
            }
        }

        protected void btnsubmit1_Click(object sender, EventArgs e)
        {
            if (!chk_billing_address.Checked)
            {
                Response.Redirect("Order-overview.aspx");
            }
        }

        protected void ddl_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                getState();
                //lbl_country_error.Visible = false;
            }
            catch (Exception)
            {

                throw;
            }
        }

        protected void ddlstate_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                getCity();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}