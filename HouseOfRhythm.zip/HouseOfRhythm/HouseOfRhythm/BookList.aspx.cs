﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayerHor;

namespace HouseOfRhythm
{
    public partial class BookList : System.Web.UI.Page
    {

        ProductClass productClass;
        DataTable table;
        DataSet ds;
        List<string> list_id, list_type;
        int totalRows = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            string category = Request.QueryString["category"];
            if (!IsPostBack)
            {
                getSingleBannerDetails();
                getAllProductCategory();
                productClass = new ProductClass();
                if (category != null)
                {
                    ds = productClass.fetchProductListWithFilter("book", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), category);
                    dl_book_list.DataSource = ds.Tables[0];
                    dl_book_list.DataBind();
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                        {
                            (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                            (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                    totalRows = (int)ds.Tables[1].Rows[0][0];
                    DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                }
                else
                {
                    getAllBookList();
                    ds = productClass.fetchProductList("book", 0, 1);
                    totalRows = (int)ds.Tables[1].Rows[0][0];
                    DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                }
            }
        }

        private void getAllBookList()
        {
            productClass = new ProductClass();
            ds = productClass.fetchProductList("book", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
            dl_book_list.DataSource = ds.Tables[0];
            dl_book_list.DataBind();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                {
                    (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                    (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                    (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                }
                if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                {
                    (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                    (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                }
                else
                {
                    (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                }
            }
        }

        private void getAllProductCategory()
        {
            productClass = new ProductClass();
            ds = productClass.fetchAllCategoryDetails();
            dl_audio_indian.DataSource = ds.Tables[0];
            dl_audio_indian.DataBind();
            dl_international_cat.DataSource = ds.Tables[1];
            dl_international_cat.DataBind();
            dl_video_indian.DataSource = ds.Tables[2];
            dl_video_indian.DataBind();
            dl_video_international.DataSource = ds.Tables[3];
            dl_video_international.DataBind();
            dl_movie_cat.DataSource = ds.Tables[4];
            dl_movie_cat.DataBind();
            dl_book_cat.DataSource = ds.Tables[5];
            dl_book_cat.DataBind();
            dl_product_cat.DataSource = ds.Tables[6];
            dl_product_cat.DataBind();

        }

        //Method to get data to display in Grid view
        /*********************************************************************************************/
        protected void btn_grid_view_Click(object sender, EventArgs e)
        {
            if (dl_book_list.Items.Count == 0)
            {
                dl_list_view.Visible = false;
                getAllBookList();
                dl_book_list.DataSource = table;
                dl_book_list.DataBind();
                dl_book_list.Visible = true;
            }
            else
            {
                dl_book_list.Visible = true;
                dl_list_view.Visible = false;
            }
        }
        private void getSingleBannerDetails()
        {
            InsertBannerDetails insertBannerDetails = new InsertBannerDetails();
            DataTable table = insertBannerDetails.getSinlgeBannerDetails("BookList");
            //string path = table.Rows[0][0].ToString();
            lbl_banner_title.Text = table.Rows[0][1].ToString();
            lbl_content.Text = table.Rows[0][2].ToString();
            Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "setImage('" + table.Rows[0][0].ToString() + "')", true);
        }

        private void DatabindRepeater(int pageIndex, int pageSize, int totalRows)
        {
            //int totalPages = totalRows / pageSize;
            int totalPages = 9;
            if ((totalRows % pageSize) != 0)
            {
                totalPages += 1;
            }

            List<ListItem> pages = new List<ListItem>();

            for (int i = 1; i <= totalPages; i++)
            {
                pages.Add(new ListItem(i.ToString(), i.ToString(), i != (pageIndex + 1)));
            }

            repeaterPaging.DataSource = pages;
            repeaterPaging.DataBind();
        }

        protected void linkButton_Click(object sender, EventArgs e)
        {
            string category = Request.QueryString["category"];
            int pageIndex = int.Parse((sender as LinkButton).CommandArgument);
            pageIndex -= 1;
            productClass = new ProductClass();
            if (category != null)
            {
                ds = productClass.fetchProductListWithFilter("book", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), category);
                dl_book_list.DataSource = ds.Tables[0];
                dl_book_list.DataBind();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                    {
                        (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                        (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                        (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                    }
                    if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                    {
                        (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                        (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                    }
                    else
                    {
                        (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                    }
                }
                totalRows = (int)ds.Tables[1].Rows[0][0];
                DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
            }
            else
            {
                ds = productClass.fetchProductList("book", pageIndex, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                dl_book_list.DataSource = ds.Tables[0];
                dl_book_list.DataBind();

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                    {
                        (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                        (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                        (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                    }
                    if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                    {
                        (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                        (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                    }
                    else
                    {
                        (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                    }

                }
                totalRows = (int)ds.Tables[1].Rows[0][0];
            }
            ViewState["PageIndex"] = pageIndex;
        }

        protected void btn_prev_Click(object sender, EventArgs e)
        {
            int pageIndex = 0;
            string category = Request.QueryString["category"];
            if (ViewState["PageIndex"] != null)
            {
                 pageIndex = (int)ViewState["PageIndex"];
            }
               
                pageIndex -= 1;
                productClass = new ProductClass();
                if (category != null)
                {
                    ds = productClass.fetchProductListWithFilter("book", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), category);
                    dl_book_list.DataSource = ds.Tables[0];
                    dl_book_list.DataBind();
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                        {
                            (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                            (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                    totalRows = (int)ds.Tables[1].Rows[0][0];
                    DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                }
                else
                {
                    ds = productClass.fetchProductList("book", pageIndex, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    dl_book_list.DataSource = ds.Tables[0];
                    dl_book_list.DataBind();

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                        {
                            (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                            (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                    totalRows = (int)ds.Tables[1].Rows[0][0];
                    DatabindRepeater(pageIndex, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                }

                ViewState["PageIndex"] = pageIndex;
        }

        protected void btn_next_Click(object sender, EventArgs e)
        {
            int pageIndex = 0;
            string category = Request.QueryString["category"];
            if (ViewState["PageIndex"] != null)
            {
                 pageIndex = (int)ViewState["PageIndex"];
            }
                pageIndex += 1;
                productClass = new ProductClass();
                if (category != null)
                {
                    ds = productClass.fetchProductListWithFilter("book", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), category);
                    dl_book_list.DataSource = ds.Tables[0];
                    dl_book_list.DataBind();
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                        {
                            (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                            (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                    totalRows = (int)ds.Tables[1].Rows[0][0];
                    DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                }
                else
                {
                    ds = productClass.fetchProductList("book", pageIndex, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    dl_book_list.DataSource = ds.Tables[0];
                    dl_book_list.DataBind();

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                        {
                            (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                            (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                    totalRows = (int)ds.Tables[1].Rows[0][0];
                    DatabindRepeater(pageIndex, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                }

                ViewState["PageIndex"] = pageIndex;
            
        }
        //Method to get data to display in List view
        /*********************************************************************************************/
        protected void btn_list_view_Click(object sender, EventArgs e)
        {
            if (dl_list_view.Items.Count == 0)
            {
                dl_book_list.Visible = false;
                dl_book_list.Dispose();
                getAllBookList();
                dl_list_view.DataSource = table;
                dl_list_view.DataBind();
                dl_list_view.Visible = true;
            }
            else
            {
                dl_book_list.Visible = false;
                dl_list_view.Visible = true;
            }
        }

        //Method to sort book list by name and price
        /***********************************************************************************************/
        protected void ddl_sort_list_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl_sort_list.SelectedValue == "Ascending")
            {
                if (Request.QueryString["category"] != null)
                {
                    display_bookWithFilter();
                }
                else
                {
                    productClass = new ProductClass();
                    table = productClass.sortProductDetails("spSortBookList", ddl_sort_list.SelectedValue, 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    dl_book_list.DataSource = table;
                    dl_book_list.DataBind();
                    for (int i = 0; i < table.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(table.Rows[i][5]) <= 0)
                        {
                            (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(table.Rows[i][6]) > 0)
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + table.Rows[i][4].ToString();
                            (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(table.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(table.Rows[i][4].ToString())) * ((int)table.Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                }
               
            }

            if (ddl_sort_list.SelectedValue == "Descending")
            {
                if (Request.QueryString["category"] != null)
                {
                    display_bookWithFilter();
                }
                else
                {
                    productClass = new ProductClass();
                    table = productClass.sortProductDetails("spSortBookList", ddl_sort_list.SelectedValue, 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    dl_book_list.DataSource = table;
                    dl_book_list.DataBind();
                    for (int i = 0; i < table.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(table.Rows[i][5]) <= 0)
                        {
                            (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(table.Rows[i][6]) > 0)
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + table.Rows[i][4].ToString();
                            (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(table.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(table.Rows[i][4].ToString())) * ((int)table.Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                }
                
            }

            if (ddl_sort_list.SelectedValue == "LowToHigh")
            {
                if (Request.QueryString["category"] != null)
                {
                    display_bookWithFilter();
                }
                else
                {
                    productClass = new ProductClass();
                    table = productClass.sortProductDetails("spSortBookList", ddl_sort_list.SelectedValue, 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    dl_book_list.DataSource = table;
                    dl_book_list.DataBind();
                    for (int i = 0; i < table.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(table.Rows[i][5]) <= 0)
                        {
                            (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(table.Rows[i][6]) > 0)
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + table.Rows[i][4].ToString();
                            (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(table.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(table.Rows[i][4].ToString())) * ((int)table.Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                }
                
            }

            if (ddl_sort_list.SelectedValue == "HighToLow")
            {
                if (Request.QueryString["category"] != null)
                {
                    display_bookWithFilter();
                }
                else
                {
                    productClass = new ProductClass();
                    table = productClass.sortProductDetails("spSortBookList", ddl_sort_list.SelectedValue, 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    dl_book_list.DataSource = table;
                    dl_book_list.DataBind();
                    for (int i = 0; i < table.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(table.Rows[i][5]) <= 0)
                        {
                            (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(table.Rows[i][6]) > 0)
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + table.Rows[i][4].ToString();
                            (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(table.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(table.Rows[i][4].ToString())) * ((int)table.Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                }
                
            }
        }

        //Method to display BookList with Filter and Sorting
        /*********************************************************************************************/
        protected void display_bookWithFilter()
        {
            string category = Request.QueryString["category"];
            productClass = new ProductClass();
            table = productClass.sortProductDetailsWithFilter("spSortBookListWithFilter", ddl_sort_list.SelectedValue, category, 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
            dl_book_list.DataSource = table;
            dl_book_list.DataBind();
            for (int i = 0; i < table.Rows.Count; i++)
            {
                if (Convert.ToInt32(table.Rows[i][5]) <= 0)
                {
                    (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                    (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                    (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                }
                if (Convert.ToInt32(table.Rows[i][6]) > 0)
                {
                    (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + table.Rows[i][4].ToString();
                    (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(table.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(table.Rows[i][4].ToString())) * ((int)table.Rows[i][6])) / 100).ToString();
                }
                else
                {
                    (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                }
            }
        }
        //Method to display movie list display count
        /***********************************************************************************************/
        protected void ddl_total_products_SelectedIndexChanged(object sender, EventArgs e)
        {
            string category = Request.QueryString["category"];
            productClass = new ProductClass();
            if (category != null)
            {
                ds = productClass.fetchProductListWithFilter("book", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), category);
                dl_book_list.DataSource = ds.Tables[0];
                dl_book_list.DataBind();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                    {
                        (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                        (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                        (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                    }
                    if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                    {
                        (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                        (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                    }
                    else
                    {
                        (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                    }
                }
                totalRows = (int)ds.Tables[1].Rows[0][0];
                DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
            }
            else
            {
                ds = productClass.fetchProductList("book", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                dl_book_list.DataSource = ds.Tables[0];
                dl_book_list.DataBind();
                totalRows = (int)ds.Tables[1].Rows[0][0];
                DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                    {
                        (dl_book_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                        (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                        (dl_book_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                    }
                    if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                    {
                        (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                        (dl_book_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                    }
                    else
                    {
                        (dl_book_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                    }
                }
            }
            //table = productClass.sortMusicDetails("spChangeBookListCountToDisplay", ddl_total_products.SelectedValue);
            //dl_book_list.DataSource = table;
            //dl_book_list.DataBind();
        }

        //Method to display movie,music,book,product list by category/genre
        /***********************************************************************************************/

        protected void dl_audio_indian_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Audio Indian")
            {
                Response.Redirect("MusicList.aspx?category=" +Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }
        protected void dl_international_cat_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Audio International")
            {
                Response.Redirect("MusicList.aspx?category=" +Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        protected void dl_video_indian_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "International Indian")
            {
                Response.Redirect("MusicList.aspx?category=" +Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        protected void dl_video_international_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "International International")
            {
                Response.Redirect("MusicList.aspx?category=" +Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        protected void dl_movie_cat_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Movie")
            {
                Response.Redirect("MovieList.aspx?category=" +Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }
        protected void dl_book_cat_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Book")
            {
                productClass = new ProductClass();
                ds = productClass.GetProductDetailsByCategory(e.CommandArgument.ToString(), "Book");
                dl_book_list.DataSource = ds.Tables[0];
                dl_book_list.DataBind();
            }
        }

        protected void dl_product_cat_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Product")
            {
                Response.Redirect("ProductList.aspx?category=" +Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        //Method to handle Item Command on Datalist Grid View Book
        /***********************************************************************************************/
        protected void dl_book_list_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "AddCart")
            {
                Response.Redirect("cart.aspx?Id=" + e.CommandArgument + "&type=Book");
            }
            else if (e.CommandName == "Details")
            {
                Response.Redirect("BookDetails.aspx?Id=" + e.CommandArgument + "&type=Book");
            }

            else if (e.CommandName == "Compare")
            {
                if (Request.Cookies["ProdId"] != null)
                {
                    list_id = ((Request.Cookies["ProdId"].Value).Split(',')).ToList();
                    list_type = ((Request.Cookies["ProdType"].Value).Split(',')).ToList();
                }
                if (Request.Cookies["ProdId"] == null)
                {
                    Response.Cookies["ProdId"].Value = e.CommandArgument.ToString();
                    Response.Cookies["ProdType"].Value = "Book";
                }
                else if (list_id.Count >= 2)
                {
                    ClientMessageBox.Show("You have Already select 2 Items", this);
                }
                else if ((Request.Cookies["ProdType"].Value).Contains("Book"))
                {
                    Response.Cookies["ProdId"].Value = Request.Cookies["ProdId"].Value + "," +e.CommandArgument;
                    Response.Cookies["ProdId"].Expires = DateTime.Now.AddDays(1);
                    Response.Cookies["ProdType"].Value = Request.Cookies["ProdType"].Value + "," + "Book";
                    Response.Cookies["ProdType"].Expires = DateTime.Now.AddDays(1);
                }
                else
                {
                    ClientMessageBox.Show("Please Select Similar Type", this);
                }
            }
            else if (e.CommandName == "Wishlist")
            {
                if (Session["UserID"] == null)
                {
                    lbl_wishlist_msg.Text = "Please Login First";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                }
                else
                {
                    productClass = new ProductClass();
                    productClass.title = (e.Item.FindControl("lbl_title") as Label).Text;
                    productClass.user_id = Session["UserId"].ToString();
                    productClass.mrp = Convert.ToDecimal((e.Item.FindControl("lbl_mrp") as Label).Text);
                    productClass.product_id = e.CommandArgument.ToString();
                    productClass.prod_image = (e.Item.FindControl("music_img") as Image).ImageUrl;
                    int i = productClass.addMusicDetailsToWishlist(productClass);

                    if (i >= 1)
                    {
                        lbl_wishlist_msg.Text = "Product Addes To Wishlist";
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                    }
                }
            }
        }

        //Method to handle Item Command on Datalist of List View Book
        /***********************************************************************************************/
        protected void dl_list_view_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "AddCart")
            {
                Response.Redirect("cart.aspx?Id=" + e.CommandArgument + "&type=Movie");
            }
            else if (e.CommandName == "Details")
            {
                Response.Redirect("MovieDetails.aspx?Id=" + e.CommandArgument + "&type=Movie");
            }
            else if (e.CommandName == "Compare")
            {
                if (Request.Cookies["ProdId"] != null)
                {
                    list_id = ((Request.Cookies["ProdId"].Value).Split(',')).ToList();
                    list_type = ((Request.Cookies["ProdType"].Value).Split(',')).ToList();
                }
                if (Request.Cookies["ProdId"] == null)
                {
                    Response.Cookies["ProdId"].Value = e.CommandArgument.ToString();
                    Response.Cookies["ProdType"].Value = "Book";
                }
                else if (list_id.Count >= 2)
                {
                    ClientMessageBox.Show("You have Already select 2 Items", this);
                }
                else if ((Request.Cookies["ProdType"].Value).Contains("Book"))
                {
                    Response.Cookies["ProdId"].Value = Request.Cookies["ProdId"].Value + "," + e.CommandArgument;
                    Response.Cookies["ProdId"].Expires = DateTime.Now.AddDays(1);
                    Response.Cookies["ProdType"].Value = Request.Cookies["ProdType"].Value + "," + "Book";
                    Response.Cookies["ProdType"].Expires = DateTime.Now.AddDays(1);
                }
                else
                {
                    ClientMessageBox.Show("Please Select Similar Type", this);
                }
            }
            else if (e.CommandName == "Wishlist")
            {
                if (Session["UserID"] == null)
                {
                    lbl_wishlist_msg.Text = "Please Login First";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                }
                else
                {
                    productClass = new ProductClass();
                    int i = 0;
                    //productClass.addMusicDetailsToWishlist(Session["UserID"].ToString(), e.CommandArgument.ToString());

                    if (i >= 1)
                    {
                        lbl_wishlist_msg.Text = "Product Addes To Wishlist";
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                    }
                }
            }
        }
        
       
      

        protected void btncompare_Click(object sender, EventArgs e)
        {
            list_id = ((Request.Cookies["ProdId"].Value).Split(',')).ToList();
            if (Request.Cookies["ProdId"] == null)
            {
                ClientMessageBox.Show("Please Add Product to Compare", this);
            }
            //else if (list_id.Count <= 1)
            //{
            //    ClientMessageBox.Show("Please Add one more Product to Compare", this);
            //}
            else
            {
                Response.Redirect("Compare.aspx");
            }
        }

        
    }
}