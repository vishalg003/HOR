﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayerHor;

namespace HouseOfRhythm
{
    public partial class ProductDetails : System.Web.UI.Page
    {
        BusinessLayerHor.ProductDetails productdetails;
        DataTable dt;
        ProductClass productClass;
        protected void Page_Load(object sender, EventArgs e)
        {
            getSingleBannerDetails();
            if (!IsPostBack)
            {
                if (Request.QueryString["Id"] != null)
                {
                    DisplayMusicDetails(Request.QueryString["Id"], Request.QueryString["type"]);
                }
            }
        }

        //Method to add product details
        /**************************************************************************************************/
        public void DisplayMusicDetails(string id, string type)
        {
            try
            {
                productdetails = new BusinessLayerHor.ProductDetails();
                dt = productdetails.getProductDetailsByType(id, type);
                lblprodtitle.Text = dt.Rows[0][0].ToString();
                lblsku.Text = dt.Rows[0][16].ToString();                
                lblformat.Text = dt.Rows[0][15].ToString();
                lbllanguage.Text = dt.Rows[0][4].ToString();
                lblno_of_disc.Text = dt.Rows[0][6].ToString();
                lbllabelname.Text = dt.Rows[0][7].ToString();
                lblreleasedate.Text = (dt.Rows[0][10]).ToString();
                lblartist.Text = dt.Rows[0][1].ToString();
                lblcomposer.Text = dt.Rows[0][2].ToString();
                lbllyricist.Text = dt.Rows[0][3].ToString();
                lblcatlogno.Text = dt.Rows[0][8].ToString();
                lblbarcode.Text = dt.Rows[0][9].ToString();
                lblgenre.Text = dt.Rows[0][5].ToString();
                Productimage.ImageUrl = dt.Rows[0][17].ToString();

                if ((int)dt.Rows[0][12] > 0)
                {
                    lblprice.Text = ((Convert.ToInt32(Convert.ToDecimal(dt.Rows[0][11].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(dt.Rows[0][11].ToString())) * ((int)dt.Rows[0][12]))/100).ToString();
                    lbl_discount.Text = "Rs. " + dt.Rows[0][11].ToString();
                    lbl_discount.Visible = true;
                }
                else
                {
                    lbl_discount.Visible = false; 
                    lblprice.Text = dt.Rows[0][11].ToString();
                }
                if (Convert.ToInt32(Convert.ToDecimal(dt.Rows[0][13])) > 0)
                {
                    lbl_stock_count.Text ="Only : " + dt.Rows[0][13].ToString() + " Left";
                    lbl_stock_msg.Text = "In Stock";
                    add_to_Cart.Enabled = true;
                }
                else if (Convert.ToInt32(Convert.ToDecimal(dt.Rows[0][13])) <= 0 && Convert.ToChar(dt.Rows[0][21]) == 'Y')
                {
                    lbl_stock_msg.Text = "In Stock";
                    add_to_Cart.Enabled = true;
                }
                else
                {
                    lbl_stock_msg.Text = "Out of Stock";
                    lbl_stock_msg.ForeColor = System.Drawing.Color.Red;
                    add_to_Cart.Enabled = false;
                }

                lbltracks.Text = dt.Rows[0][14].ToString().Replace("\n", "<br />");
                getRelatedMusicDetails(lblartist.Text, lblgenre.Text, lblcomposer.Text);
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        //Method to get ralted items of displayed products 
        /**************************************************************************************************/
        private void getRelatedMusicDetails(string artist, string genre, string director)
        {
            productdetails = new BusinessLayerHor.ProductDetails();
            dt = productdetails.getRelatedProducts(artist, genre, director,"Music");
            dl_related_products.DataSource = dt;
            dl_related_products.DataBind();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (Convert.ToInt32(dt.Rows[i][3]) == 0)
                {
                    (dl_related_products.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                    (dl_related_products.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                    (dl_related_products.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                }
            }
        }

        private void getSingleBannerDetails()
        {
            InsertBannerDetails insertBannerDetails = new InsertBannerDetails();
            DataTable table = insertBannerDetails.getSinlgeBannerDetails("MusicList");
            //string path = table.Rows[0][0].ToString();
            if (table.Rows.Count > 0)
            {
                lbl_banner_title.Text = table.Rows[0][1].ToString();
                lbl_content.Text = table.Rows[0][2].ToString();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "setImage('" + table.Rows[0][0].ToString() + "')", true);
            }
        }
        //Method to add displayed product to cart
        /**************************************************************************************************/
        protected void add_to_cart_click(object sender, EventArgs e)
        {
            Response.Redirect("cart.aspx?Id=" + Request.QueryString["Id"] + "&type=" + Request.QueryString["type"]);
        }

        //Method to add displayed product to wishlist
        /**************************************************************************************************/
        protected void lb_add_wishlist_Click(object sender, EventArgs e)
        {
            if (Session["UserID"] == null)
            {
                lbl_wishlist_msg.Text = "Please Login First";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
            }
            else
            {
                productClass = new ProductClass();
                productClass.title = lblprodtitle.Text;
                productClass.mrp = Convert.ToDecimal(lblprice.Text);
                productClass.user_id = Session["UserId"].ToString();
                productClass.product_id = Request.QueryString["Id"];
                productClass.prod_image = Productimage.ImageUrl;
                int i = productClass.addMusicDetailsToWishlist(productClass);

                if (i >= 1)
                {
                    lbl_wishlist_msg.Text = "Product Addes To Wishlist";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                }
            }
        }

        //Method to add product to cart, wishlist, compare
        /**************************************************************************************************/
        //Method to add product to cart, wishlist, compare
        /**************************************************************************************************/
        protected void dl_related_products_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "AddCart")
            {
                Response.Redirect("Cart.aspx?Id=" + e.CommandArgument.ToString() + "&type=Music");
            }
            else if (e.CommandName == "Details")
            {
                Response.Redirect("MusicDetails.aspx?Id=" + e.CommandArgument + "&type=Music");
            }
            else if (e.CommandName == "Wishlist")
            {
                if (Session["UserID"] == null)
                {
                    //ClientMessageBox.Show("Please Login First", this);
                    lbl_wishlist_msg.Text = "Please Login First";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                }
                else
                {
                    productClass = new ProductClass();
                    productClass.title = lblprodtitle.Text;
                    productClass.mrp = Convert.ToDecimal(lblprice.Text);
                    productClass.user_id = Session["UserId"].ToString();
                    productClass.product_id = Request.QueryString["Id"];
                    productClass.prod_image = (e.Item.FindControl("music_img") as Image).ImageUrl;
                    int i = productClass.addMusicDetailsToWishlist(productClass);

                    if (i >= 1)
                    {
                        lbl_wishlist_msg.Text = "Product Addes To Wishlist";
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                    }
                }
            }
            else
            {
                //Response.Redirect("Compare.aspx?Id=" + e.CommandArgument.ToString() + "&type=Music");
            }
        }
        
    }
}