﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayerHor;

namespace HouseOfRhythm
{
    public partial class Order_Details : System.Web.UI.Page
    {
        CartClass order;
        DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["orderId"] != null)
                {
                    getOrderDetails();
                }
            }
            
        }
        private void getOrderDetails()
        {
            try
            {
                order = new CartClass();
                ds = order.getOrderDetails(Request.QueryString["orderId"]);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dl_order_list.DataSource = ds.Tables[0];
                    dl_order_list.DataBind();
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        if (Convert.ToDecimal(ds.Tables[0].Rows[i][5]) == Convert.ToDecimal(ds.Tables[0].Rows[i][6]))
                        {
                            (dl_order_list.Items[i].FindControl("Label2") as Label).Visible = false;
                            (dl_order_list.Items[i].FindControl("rs") as Label).Visible = false;
                        }
                    }
                    lbl_order_id.Text = Request.QueryString["orderId"];
                    lbl_order_date.Text = ds.Tables[1].Rows[0][8].ToString();
                    lbl_amount.Text = ds.Tables[1].Rows[0][0].ToString() + " through " + ds.Tables[1].Rows[0][9].ToString();
                    lbl_name.Text = ds.Tables[1].Rows[0][5].ToString();
                    lbl_shipping_address.Text = ds.Tables[1].Rows[0][1].ToString() + ", " + ds.Tables[1].Rows[0][6].ToString() + ", " + ds.Tables[1].Rows[0][4].ToString() + ", " + ds.Tables[1].Rows[0][7];
                    lbl_shipping_address1.Text = ds.Tables[1].Rows[0][3] + ", " + ds.Tables[1].Rows[0][2].ToString();
                    lbl_mobile.Text = "<b>Phone: </b>" + ds.Tables[1].Rows[0][10].ToString();
                    lbl_shipping_charges.Text = ds.Tables[1].Rows[0][11].ToString();
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }
    }
}