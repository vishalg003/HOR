﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm
{
    public partial class compaire : System.Web.UI.Page
    {
        ProductClass music;
        BusinessLayerHor.ProductDetails productDetail;
        DataTable table, dt;
        List<string> list_id, list_type;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["ProdId"] != null)
            {
                list_id = ((Request.Cookies["ProdId"].Value).Split(',')).ToList();
                list_type = ((Request.Cookies["ProdType"].Value).Split(',')).ToList();
                if (list_type.Contains("Music"))
                {
                    getProductList(list_id, list_type);
                }
                else if (list_type.Contains("Movie"))
                {
                    getMovieList(list_id, list_type);
                }
                else if (list_type.Contains("Book"))
                {
                    getBookList(list_id, list_type);
                }
               
            }

        }

        private void getProductList(List<string> musicId, List<string> type)
        {
            table = new DataTable();
            table.Columns.Add("title");
            table.Columns.Add("image");
            table.Columns.Add("Description");
            table.Columns.Add("Artist");
            table.Columns.Add("Composer");
            table.Columns.Add("lyricist");
            table.Columns.Add("Catalogno");
            table.Columns.Add("Barcodeno");
            table.Columns.Add("Format");
            table.Columns.Add("Language");
            table.Columns.Add("Genre");
            table.Columns.Add("NoOfDisc");
            table.Columns.Add("Lable");
            table.Columns.Add("RealeaseDate");
            table.Columns.Add("TrackList");
            table.Columns.Add("Price");
            table.Columns.Add("Music_id");
            table.Columns.Add("Music_type");
            for (int i = 0; i < list_id.Count; i++)
            {
                productDetail = new BusinessLayerHor.ProductDetails();
                dt = productDetail.getProductDetailsByType(musicId[i], type[i]);
                DataRow row = table.NewRow();
                row["title"] = dt.Rows[0][0].ToString();
                row["Artist"] = dt.Rows[0][1].ToString();
                row["Composer"] = dt.Rows[0][2].ToString();
                row["lyricist"] = dt.Rows[0][3].ToString();
                row["Genre"] = dt.Rows[0][5].ToString();
                row["Language"] = dt.Rows[0][4].ToString();
                row["NoOfDisc"] = dt.Rows[0][6].ToString();
                row["Lable"] = dt.Rows[0][7].ToString();
                row["Catalogno"] = dt.Rows[0][8].ToString();
                row["Barcodeno"] = dt.Rows[0][9].ToString();
                row["RealeaseDate"] = dt.Rows[0][10].ToString();
                row["Price"] = dt.Rows[0][11].ToString();
                row["TrackList"] = dt.Rows[0][14].ToString();
                row["Format"] = dt.Rows[0][15].ToString();
                row["image"] = dt.Rows[0][17].ToString();
                row["Description"] = dt.Rows[0][18].ToString();
                row["Music_id"] = dt.Rows[0][19].ToString();
                row["Music_type"] = dt.Rows[0][20].ToString();
                table.Rows.Add(row);
            }
            dl_Compare.DataSource = table;
            dl_Compare.DataBind();
        }

        private void getBookList(List<string> musicId, List<string> type)
        {
            table = new DataTable();
            table.Columns.Add("book_title");
            table.Columns.Add("book_image");
            table.Columns.Add("Book_Description");
            table.Columns.Add("Author_name");
            table.Columns.Add("Publisher_name");
            table.Columns.Add("Isbn_no");
            table.Columns.Add("Pages");
            table.Columns.Add("Publish_date");
            table.Columns.Add("book_Category");
            table.Columns.Add("book_Language");
            table.Columns.Add("book_Price");
            table.Columns.Add("Size");
            table.Columns.Add("Book_id");
            table.Columns.Add("Book_type");
            for (int i = 0; i < list_id.Count; i++)
            {
                productDetail = new BusinessLayerHor.ProductDetails();
                dt = productDetail.getProductDetailsByType(musicId[i], type[i]);
                DataRow row = table.NewRow();
                row["book_title"] = dt.Rows[0][0].ToString();
                row["Author_name"] = dt.Rows[0][1].ToString();
                row["Publisher_name"] = dt.Rows[0][2].ToString();
                row["Isbn_no"] = dt.Rows[0][3].ToString();
                row["Pages"] = dt.Rows[0][5].ToString();
                row["Size"] = dt.Rows[0][4].ToString();
                row["Publish_date"] = dt.Rows[0][6].ToString();
                row["book_Price"] = dt.Rows[0][7].ToString();
                row["Book_Description"] = dt.Rows[0][9].ToString();
                row["book_image"] = dt.Rows[0][12].ToString();
                row["book_Category"] = dt.Rows[0][13].ToString();
                row["book_Language"] = dt.Rows[0][14].ToString();
                row["Book_id"] = dt.Rows[0][15].ToString();
                row["Book_type"] = dt.Rows[0][16].ToString();
                table.Rows.Add(row);
            }
            dl_compare_book.DataSource = table;
            dl_compare_book.DataBind();
        }

        private void getMovieList(List<string> musicId, List<string> type)
        {
            table = new DataTable();
            table.Columns.Add("movie_title");
            table.Columns.Add("movie_image");
            table.Columns.Add("movie_Description");
            table.Columns.Add("movie_actor");
            table.Columns.Add("movie_actress");
            table.Columns.Add("Director");
            table.Columns.Add("Producer");
            table.Columns.Add("movie_Composer");
            table.Columns.Add("movie_Catalogno");
            table.Columns.Add("movie_Barcodeno");
            table.Columns.Add("movie_Format");
            table.Columns.Add("movie_Language");
            table.Columns.Add("movie_Genre");
            table.Columns.Add("movie_NoOfDisc");
            table.Columns.Add("movie_Lable");
            table.Columns.Add("movie_Studio");
            table.Columns.Add("movie_Price");
            table.Columns.Add("movie_runtime");
            table.Columns.Add("movie_RealeaseDate");
            table.Columns.Add("Movie_id");
            table.Columns.Add("Movie_type");
            for (int i = 0; i < list_id.Count; i++)
            {
                productDetail = new BusinessLayerHor.ProductDetails();
                dt = productDetail.getProductDetailsByType(musicId[i], type[i]);
                DataRow row = table.NewRow();
                row["movie_title"] = dt.Rows[0][0].ToString();
                row["movie_actor"] = dt.Rows[0][1].ToString();
                row["movie_actress"] = dt.Rows[0][2].ToString();
                row["Director"] = dt.Rows[0][3].ToString();
                row["Producer"] = dt.Rows[0][5].ToString();
                row["movie_Composer"] = dt.Rows[0][4].ToString();
                row["movie_Language"] = dt.Rows[0][6].ToString();
                row["movie_Genre"] = dt.Rows[0][7].ToString();
                row["movie_RealeaseDate"] = dt.Rows[0][8].ToString();
                row["movie_Format"] = dt.Rows[0][11].ToString();
                row["movie_Catalogno"] = dt.Rows[0][12].ToString();
                row["movie_Barcodeno"] = dt.Rows[0][13].ToString();
                row["movie_NoOfDisc"] = dt.Rows[0][14].ToString();
                row["movie_Lable"] = dt.Rows[0][15].ToString();
                row["movie_runtime"] = dt.Rows[0][17].ToString();
                row["movie_Studio"] = dt.Rows[0][18].ToString();
                row["movie_Price"] = dt.Rows[0][19].ToString();
                row["movie_Description"] = dt.Rows[0][22].ToString();
                row["movie_image"] = dt.Rows[0][23].ToString();
                row["Movie_id"] = dt.Rows[0][24].ToString();
                row["Movie_type"] = dt.Rows[0][25].ToString();
                table.Rows.Add(row);
            }
            dl_compare_movie.DataSource = table;
            dl_compare_movie.DataBind();
        }

        protected void dl_compare_movie_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals ("Remove"))
            {
                list_id = new List<string>();
                list_type = new List<string>();

                for (int i = 0; i < dl_compare_movie.Items.Count; i++)
                {
                    if (e.Item.ItemIndex != i)
                    {
                        Label id = dl_compare_movie.Items[i].FindControl("lbl_id") as Label;
                        Label type = dl_compare_movie.Items[i].FindControl("lbl_type") as Label;
                        list_id.Add(id.Text);
                        list_type.Add(type.Text);
                    }
                }
                if (list_id.Count != 0)
                {
                    Response.Cookies["ProdId"].Value = String.Join(",", list_id);
                    Response.Cookies["ProdType"].Value = String.Join(",", list_type);
                    getMovieList(list_id, list_type);
                }
                else
                {
                    HttpCookie clear = new HttpCookie("ProdId");
                    clear.Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies.Add(clear);
                    dl_compare_movie.DataSource = null;
                    dl_compare_movie.DataBind();
                }
                
            }
        }

        protected void dl_Compare_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals("Remove"))
            {
                list_id = new List<string>();
                list_type = new List<string>();

                for (int i = 0; i < dl_Compare.Items.Count; i++)
                {
                    if (e.Item.ItemIndex != i)
                    {
                        Label id = dl_Compare.Items[i].FindControl("lblid") as Label;
                        Label type = dl_Compare.Items[i].FindControl("lbltype") as Label;
                        list_id.Add(id.Text);
                        list_type.Add(type.Text);
                    }
                }
                if (list_id.Count != 0)
                {
                    Response.Cookies["ProdId"].Value = String.Join(",", list_id);
                    Response.Cookies["ProdType"].Value = String.Join(",", list_type);
                    getProductList(list_id, list_type);
                }
                else
                {
                    HttpCookie clear = new HttpCookie("ProdId");
                    clear.Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies.Add(clear);
                    dl_Compare.DataSource = null;
                    dl_Compare.DataBind();
                }

            }
        }

        protected void dl_compare_book_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals("Remove"))
            {
                list_id = new List<string>();
                list_type = new List<string>();

                for (int i = 0; i < dl_compare_book.Items.Count; i++)
                {
                    if (e.Item.ItemIndex != i)
                    {
                        Label id = dl_compare_book.Items[i].FindControl("lblbid") as Label;
                        Label type = dl_compare_book.Items[i].FindControl("lblbtype") as Label;
                        list_id.Add(id.Text);
                        list_type.Add(type.Text);
                    }
                }
                if (list_id.Count != 0)
                {
                    Response.Cookies["ProdId"].Value = String.Join(",", list_id);
                    Response.Cookies["ProdType"].Value = String.Join(",", list_type);
                    getBookList(list_id, list_type);
                }
                else
                {
                    HttpCookie clear = new HttpCookie("ProdId");
                    clear.Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies.Add(clear);
                    dl_compare_book.DataSource = null;
                    dl_compare_book.DataBind();
                }

            }
        }

    }
}