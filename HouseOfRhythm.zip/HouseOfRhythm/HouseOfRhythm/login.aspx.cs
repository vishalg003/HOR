﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm
{
    public partial class login : System.Web.UI.Page
    {
        DataTable table;
        CartClass cart;
        DataTable dt1 = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            DataTable dt = CustomerClass.getUserLoginDetails(txtEmail.Text, txtPassword.Text);
            if (dt.Rows.Count != 0)
            {
                if (dt.Rows[0][0].ToString().Equals(txtEmail.Text) && dt.Rows[0][1].ToString().Equals(txtPassword.Text))
                {
                    Session["UserID"] = dt.Rows[0][0].ToString();
                    if (Request.Cookies["Id"] != null && Session["TotalAmount"] != null && Session["Checkout"] != null)
                    {
                        insert_Cart();
                        insert_CartProduct();
                        Response.Cookies["Id"].Expires = DateTime.Now.AddDays(-1);
                        Response.Cookies["type"].Expires = DateTime.Now.AddDays(-1);
                    }
                    if (Session["url"] != null)
                        Response.Redirect(Session["url"].ToString());
                    else
                        Response.Redirect("Default.aspx");
                }
                else
                    ClientMessageBox.Show("Incorrect Email or Password", this);
            }
            else
            {
                ClientMessageBox.Show("Incorrect Email or Password", this);
            }
        }
        
        private void insert_Cart()
        {
            try
            {
                ProductClass product = new ProductClass();
                cart = new CartClass();
                DataTable dt = new DataTable();
                dt1 = cart.getCartId(Session["UserId"].ToString());
                decimal prev_total_amount=0;
                decimal prev_subtotal = 0;
                if (dt1.Rows.Count > 0)
                {
                    if (Convert.ToDecimal(dt1.Rows[0][3]) == 60)
                    {
                        prev_total_amount = Convert.ToDecimal(dt1.Rows[0][1].ToString()) - 60;
                        prev_subtotal = Convert.ToDecimal(dt1.Rows[0][2].ToString());
                    }
                    else
                    {
                        prev_total_amount = Convert.ToDecimal(dt1.Rows[0][1].ToString());
                        prev_subtotal = Convert.ToDecimal(dt1.Rows[0][2].ToString());
                    }
                }

                    dt = Session["TotalAmount"] as DataTable;
                    cart._cart_id = AutoIncrementCode.get_CartId("spAutoIncrementCartCode");
                    cart._email = Session["UserId"].ToString();
                    cart._delivery_charges = Convert.ToDecimal(dt.Rows[0][2]);
                    cart._total_amount = Convert.ToDecimal(dt.Rows[0][3]) + prev_total_amount;
                    cart._cart_subtotal = Convert.ToDecimal(dt.Rows[0][0]) + prev_subtotal;
                    cart._country = dt.Rows[0][4].ToString();
                    //cart._tax = Convert.ToDecimal(dt.Rows[0][1]);
                    cart.insertCartDetails(cart);
                    dt1 = cart.getCartId(Session["UserId"].ToString());
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void insert_CartProduct()
        {
            try
            {
                table = Session["Checkout"] as DataTable;
                DataTable checkprocuct;
                cart = new CartClass();
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    if (dt1.Rows.Count > 0)
                    {
                        cart._cart_id = dt1.Rows[0][0].ToString();
                        cart._product_id = table.Rows[i][0].ToString();
                        cart._quantity = table.Rows[i][1].ToString();
                        cart._subtotal = Convert.ToDecimal(table.Rows[i][2]);
                        cart._product_title = table.Rows[i][3].ToString();
                        cart._product_image = table.Rows[i][4].ToString();
                        cart._product_mrp = Convert.ToDecimal(table.Rows[i][5]);
                        cart._original_price=Convert.ToDecimal(table.Rows[i][6].ToString());
                        cart._email = Session["UserId"].ToString();
                        cart.insertCartProductDetails(cart);
                    }
                    else
                    {
                        //cart._cart_id = lblcartid.Text;
                        cart._product_id = table.Rows[i][0].ToString();
                        cart._quantity = table.Rows[i][1].ToString();
                        cart._subtotal = Convert.ToDecimal(table.Rows[i][2]);
                        cart._product_title = table.Rows[i][3].ToString();
                        cart._product_image = table.Rows[i][4].ToString();
                        cart._product_mrp = Convert.ToDecimal(table.Rows[i][5]);
                         cart._original_price=Convert.ToDecimal(table.Rows[i][6].ToString());
                        cart._email = Session["UserId"].ToString();
                        cart.insertCartProductDetails(cart);
                    }
                }

            }
            catch (Exception)
            {

                throw;
            }


        }
    }
}