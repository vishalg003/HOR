﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm
{
    public partial class UserMaster : System.Web.UI.MasterPage
    {
        List<string> list_id, list_type;
        ProductClass music;
        DataSet ds;
        DataTable table, dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            getAllProductCategory();
            
            if (Session["UserID"] != null)
            {
                btn_login.Visible = false;
                btn_logout.Visible = true;
                displayCart();
            }
            else
            {
                if (Request.Cookies["Id"] != null&&Request.Cookies["Id"].Value!="")
                {
                    list_id = ((Request.Cookies["Id"].Value).Split(',')).ToList();
                    list_type = ((Request.Cookies["type"].Value).Split(',')).ToList();
                    getProductList(list_id, list_type);
                    //msg_sec.Visible = false;

                }
                else
                {
                    //lbl_subtotal.Text = lbl_grand_total.Text = "0.00";
                    //msg_sec.Visible = true;
                }
            }
        }

        
        private void getAllProductCategory()
        {
            music = new ProductClass();
            ds = music.fetchAllCategoryDetails();
            dl_audio_national.DataSource = ds.Tables[0];
            dl_audio_national.DataBind();
            dl_audio_international.DataSource = ds.Tables[1];
            dl_audio_international.DataBind();
            dl_video_national.DataSource = ds.Tables[2];
            dl_video_national.DataBind();
            dl_video_international.DataSource = ds.Tables[3];
            dl_video_international.DataBind();
            dl_movie_cat.DataSource = ds.Tables[4];
            dl_movie_cat.DataBind();
            dl_book_cat.DataSource = ds.Tables[5];
            dl_book_cat.DataBind();
            dl_product_cat.DataSource = ds.Tables[6];
            dl_product_cat.DataBind();

        }
        private void getProductList(List<string> musicId, List<string> type)
        {
            int sum = 0, mrp;
            music = new ProductClass();
            table = new DataTable();
            table.Columns.Add("id");
            table.Columns.Add("main_image");
            table.Columns.Add("title");
            table.Columns.Add("mrp");
            table.Columns.Add("type");
            table.Columns.Add("subtotal");
            table.Columns.Add("quantity");
            for (int i = 0; i < list_id.Count; i++)
            {
                dt = music.fetchMusicDetailsById(musicId[i], type[i]);
                if (dt.Rows.Count > 0)
                {
                    DataRow row = table.NewRow();
                    row["id"] = dt.Rows[0][0].ToString();
                    row["main_image"] = dt.Rows[0][1].ToString();
                    row["title"] = dt.Rows[0][2].ToString();
                    row["mrp"] = dt.Rows[0][3].ToString();
                    mrp = Convert.ToInt32(dt.Rows[0][3]);
                    sum += Convert.ToInt32(dt.Rows[0][3]);
                    row["type"] = dt.Rows[0][5].ToString();
                    row["subtotal"] = dt.Rows[0][4].ToString();
                    row["quantity"] = "1";
                    table.Rows.Add(row);
                }
            }
            dl_cart.DataSource = table;
            dl_cart.DataBind();
            if (Session["Cart"] != null)
            {
                sum = 0;
                table = Session["Cart"] as DataTable;
                for (int i = 0; i < dl_cart.Items.Count - 1; i++)
                {
                    (dl_cart.Items[i].FindControl("lblquanti") as Label).Text = table.Rows[i][0].ToString();
                    (dl_cart.Items[i].FindControl("lblprice") as Label).Text = table.Rows[i][1].ToString();
                    sum = sum + Convert.ToInt32(Convert.ToDecimal(table.Rows[i][1].ToString()));

                }
                sum = sum + Convert.ToInt32(Convert.ToDecimal(dt.Rows[0][3]));
                //getUpdatedDatalist();
            }
            //lbl_subtotal.Text = 
           lbl_grand_total.Text = sum.ToString() + ".00";
            //lbl_empty_cart_msg.Visible = false;

            //NoOfProduct.Text = dl_cart.Items.Count.ToString();
        }

        private void copyCartInSession()
        {
            table = new DataTable();
            table.Columns.Add("ProductID");
            table.Columns.Add("Quantity");
            table.Columns.Add("SubTotal");
            table.Columns.Add("ProductTitle");
            table.Columns.Add("ProductImage");
            table.Columns.Add("ProductMrp");
            foreach (DataListItem item in dl_cart.Items)
            {
                DataRow row = table.NewRow();
                row["ProductID"] = (item.FindControl("lbl_id") as Label).Text;
                row["Quantity"] = (item.FindControl("txt_quantity") as TextBox).Text;
                row["SubTotal"] = (item.FindControl("lbl_subtotal_mrp") as Label).Text;
                row["ProductTitle"] = (item.FindControl("lb_music_title") as LinkButton).Text;
                row["ProductImage"] = (item.FindControl("music_image") as ImageButton).ImageUrl;
                row["ProductMrp"] = (item.FindControl("lbl_mrp") as Label).Text;
                table.Rows.Add(row);
                Session["Checkout"] = table;
            }
            DataTable CartTotal = new DataTable();
            CartTotal.Columns.Add("SubTotal");
            CartTotal.Columns.Add("Tax");
            CartTotal.Columns.Add("ShippingCharges");
            CartTotal.Columns.Add("GrandTotal");
            CartTotal.Columns.Add("Country");

            //DataRow row1 = CartTotal.NewRow();
            //row1["SubTotal"] = lbl_subtotal.Text;
            //row1["Tax"] = lbl_tax.Text;
            //row1["ShippingCharges"] = lbl_shippingcharges.Text;
            //row1["GrandTotal"] = lbl_grand_total.Text;
            //CartTotal.Rows.Add(row1);
            //Session["TotalAmount"] = CartTotal;
        }
        //Method to store datalist in Session
        /* ************************************************************************************** */

        protected void btn_login_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void btn_logout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            btn_login.Visible = true;
            btn_logout.Visible = false;
            Response.Redirect("Default.aspx");
        }

        private void displayCart()
        {
            try
            {
                DataSet ds;
                CartClass update_cart;
                update_cart = new CartClass();
                ds =update_cart.GetCartDetailsForDisplay(Session["UserId"].ToString());
                if (ds.Tables[0].Rows.Count > 0 && ds.Tables[1].Rows.Count>0)
                {
                    dl_cart.DataSource = ds.Tables[1];
                    dl_cart.DataBind();
                    lbl_grand_total.Text = ds.Tables[0].Rows[0][3].ToString();
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        protected void btnsearch2_Click(object sender, EventArgs e)
        {
            try
            {
                ProductClass search = new ProductClass();
                DataTable dt = new DataTable();
                dt = search.SearchProduct(txtsearch2.Text);
                Response.Redirect("SearchResult.aspx?text=" + txtsearch2.Text);
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        protected void dl_audio_national_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if(e.CommandName.Equals("Audio Indian"))
            {
                Response.Redirect("MusicList.aspx?category="+Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        protected void dl_audio_international_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals("Audio International"))
            {
                Response.Redirect("MusicList.aspx?category=" +Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        protected void dl_video_national_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals("Video Indian"))
            {
                Response.Redirect("MusicList.aspx?category=" + Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        protected void dl_video_international_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals("Video International"))
            {
                Response.Redirect("MusicList.aspx?category=" + Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        protected void dl_movie_cat_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals("Movie"))
            {
                Response.Redirect("MovieList.aspx?category=" + Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        protected void dl_book_cat_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals("Book"))
            {
                Response.Redirect("BookList.aspx?category=" + Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        protected void dl_product_cat_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals("Product"))
            {
                string category = e.CommandArgument.ToString();
                Response.Redirect("ProductList.aspx?category="+Server.UrlEncode(category));
            }
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                ProductClass search = new ProductClass();
                DataTable dt = new DataTable();
                dt = search.SearchProduct(txtsearch.Text);
                Response.Redirect("SearchResult.aspx?text=" + txtsearch.Text);
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}