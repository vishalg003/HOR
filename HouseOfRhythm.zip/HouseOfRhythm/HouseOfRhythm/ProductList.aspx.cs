﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm
{
    public partial class ProductList1 : System.Web.UI.Page
    {
        DataTable dt;
        ProductClass productClass;
        DataSet ds;
        int totalRows = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            string category = Request.QueryString["category"];
            if (!IsPostBack)
            {
                getSingleBannerDetails();
                getAllProductCategory();
                productClass = new ProductClass();
                if (category != null)
                {
                    ds = productClass.fetchProductListWithFilter("product", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), category);
                    dl_product_list.DataSource = ds.Tables[0];
                    dl_product_list.DataBind();
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                        {
                            (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                        {
                            (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                            (dl_product_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                    totalRows = (int)ds.Tables[1].Rows[0][0];
                    DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                }
                else
                {
                    getAllMusicList();
                    ds = productClass.fetchProductList("product", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    totalRows = (int)ds.Tables[1].Rows[0][0];
                    DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                }

            }
        }


        private void getSingleBannerDetails()
        {
            InsertBannerDetails insertBannerDetails = new InsertBannerDetails();
            DataTable table = insertBannerDetails.getSinlgeBannerDetails("ProductList");
            //string path = table.Rows[0][0].ToString();
            if (table.Rows.Count > 0)
            {
                lbl_banner_title.Text = table.Rows[0][1].ToString();
                lbl_content.Text = table.Rows[0][2].ToString();
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "setImage('" + table.Rows[0][0].ToString() + "')", true);
            }
        }

        private void getAllMusicList()
        {
            productClass = new ProductClass();
            ds = productClass.fetchProductList("product", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
            dl_product_list.DataSource = ds.Tables[0];
            dl_product_list.DataBind();

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                {
                    (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                    (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                    (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                }
                if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                {
                    (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                    (dl_product_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                }
                else
                {
                    (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                }
            }
        }
        private void DatabindRepeater(int pageIndex, int pageSize, int totalRows)
        {
            //int totalPages = totalRows / pageSize;
            int totalPages = 9;
            if ((totalRows % pageSize) != 0)
            {
                totalPages += 1;
            }

            List<ListItem> pages = new List<ListItem>();

            for (int i = 1; i <= totalPages; i++)
            {
                pages.Add(new ListItem(i.ToString(), i.ToString(), i != (pageIndex + 1)));
            }

            repeaterPaging.DataSource = pages;
            repeaterPaging.DataBind();
        }

        protected void linkButton_Click(object sender, EventArgs e)
        {
            int pageIndex = int.Parse((sender as LinkButton).CommandArgument);
            pageIndex -= 1;
            productClass = new ProductClass();
            ds = productClass.fetchProductList("product", pageIndex, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
            dl_product_list.DataSource = ds.Tables[0];
            dl_product_list.DataBind();

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                {
                    (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                    (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                    (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                }
                if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                {
                    (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                    (dl_product_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                }
                else
                {
                    (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                }
            }
            totalRows = (int)ds.Tables[1].Rows[0][0];
            DatabindRepeater(pageIndex, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
            ViewState["PageIndex"] = pageIndex;
        }

        protected void btn_prev_Click(object sender, EventArgs e)
        {
            int pageIndex = 0;
            string category = Request.QueryString["category"];
            if (ViewState["PageIndex"] != null)
            {
                pageIndex = (int)ViewState["PageIndex"];
            }
                pageIndex -= 1;
                productClass = new ProductClass();
                if (category != null)
                {
                    ds = productClass.fetchProductListWithFilter("product", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), category);
                    dl_product_list.DataSource = ds.Tables[0];
                    dl_product_list.DataBind();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                            {
                                (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                                (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                                (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                            }
                            if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                            {
                                (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                                (dl_product_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                            }
                            else
                            {
                                (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                            }
                        }
                        totalRows = (int)ds.Tables[1].Rows[0][0];
                        DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                    }
                    else 
                    {
                        repeaterPaging.Visible = false;    
                    }
                    
                }
                else
                {
                    ds = productClass.fetchProductList("product", pageIndex, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    dl_product_list.DataSource = ds.Tables[0];
                    dl_product_list.DataBind();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                            {
                                (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                                (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                                (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                            }
                            if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                            {
                                (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                                (dl_product_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                            }
                            else
                            {
                                (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                            }
                        }
                        totalRows = (int)ds.Tables[1].Rows[0][0];
                        DatabindRepeater(pageIndex, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                    }
                    else
                    {
                        repeaterPaging.Visible = false;
                    }
                    ViewState["PageIndex"] = pageIndex;
                }
        }

        protected void btn_next_Click(object sender, EventArgs e)
        {
            int pageIndex = 0;
            string category = Request.QueryString["category"];
            if (ViewState["PageIndex"] != null)
            {
                pageIndex = (int)ViewState["PageIndex"];
            }
                pageIndex += 1;
                productClass = new ProductClass();
                if (category != null)
                {
                    ds = productClass.fetchProductListWithFilter("product", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), category);
                    dl_product_list.DataSource = ds.Tables[0];
                    dl_product_list.DataBind();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                            {
                                (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                                (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                                (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                            }
                            if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                            {
                                (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                                (dl_product_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                            }
                            else
                            {
                                (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                            }
                        }
                        totalRows = (int)ds.Tables[1].Rows[0][0];
                        DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                    }
                    else
                    {
                        repeaterPaging.Visible = false;
                    }
                   
                }
                else
                {
                    ds = productClass.fetchProductList("product", pageIndex, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    dl_product_list.DataSource = ds.Tables[0];
                    dl_product_list.DataBind();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                            {
                                (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                                (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                                (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                            }
                            if (Convert.ToInt32(ds.Tables[0].Rows[i][6]) > 0)
                            {
                                (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + ds.Tables[0].Rows[i][4].ToString();
                                (dl_product_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(ds.Tables[0].Rows[i][4].ToString())) * ((int)ds.Tables[0].Rows[i][6])) / 100).ToString();
                            }
                            else
                            {
                                (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                            }
                        }
                        totalRows = (int)ds.Tables[1].Rows[0][0];
                        DatabindRepeater(pageIndex, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                    }
                    else
                    {
                        repeaterPaging.Visible = false;
                    }
                   
                    ViewState["PageIndex"] = pageIndex;
                }
        }
        
        private void getAllProductCategory()
        {
            productClass = new ProductClass();
            ds = productClass.fetchAllCategoryDetails();
            dl_audio_indian.DataSource = ds.Tables[0];
            dl_audio_indian.DataBind();
            dl_international_cat.DataSource = ds.Tables[1];
            dl_international_cat.DataBind();
            dl_video_indian.DataSource = ds.Tables[2];
            dl_video_indian.DataBind();
            dl_video_international.DataSource = ds.Tables[3];
            dl_video_international.DataBind();
            dl_movie_cat.DataSource = ds.Tables[4];
            dl_movie_cat.DataBind();
            dl_book_cat.DataSource = ds.Tables[5];
            dl_book_cat.DataBind();
            dl_product_cat.DataSource = ds.Tables[6];
            dl_product_cat.DataBind();

        }

        //Method to get data to display in Grid view
        /*********************************************************************************************/
        protected void btn_grid_view_Click(object sender, EventArgs e)
        {
            if (dl_product_list.Items.Count == 0)
            {
                dl_list_view.Visible = false;
                getAllMusicList();
                dl_product_list.DataSource = dt;
                dl_product_list.DataBind();
                dl_product_list.Visible = true;
            }

            else
            {
                dl_product_list.Visible = true;
                dl_list_view.Visible = false;
                btn_grid_view.ForeColor = System.Drawing.Color.Black;
                btn_list_view.ForeColor = System.Drawing.Color.Silver;
            }
        }

        //Method to get data to display in List view
        /*********************************************************************************************/
        protected void btn_list_view_Click(object sender, EventArgs e)
        {
            if (dl_list_view.Items.Count == 0)
            {
                dl_product_list.Visible = false;
                dl_product_list.Dispose();
                getAllMusicList();
                dl_list_view.DataSource = dt;
                dl_list_view.DataBind();
                dl_list_view.Visible = true;
                btn_list_view.ForeColor = System.Drawing.Color.Black;
                btn_grid_view.ForeColor = System.Drawing.Color.Silver;
            }
            else
            {
                dl_product_list.Visible = false;
                dl_list_view.Visible = true;
                btn_list_view.ForeColor = System.Drawing.Color.Black;
                btn_grid_view.ForeColor = System.Drawing.Color.Silver;
            }
        }

        //Method to Sort the List
        /*********************************************************************************************/

        private void sortListBy()
        {
            if (ddl_sort_list.SelectedValue == "Ascending")
            {
                if (Request.QueryString["category"] != null)
                {
                    displayProductList();
                }
                else
                {
                    productClass = new ProductClass();
                    dt = productClass.sortProductDetails("spSortProductsList", ddl_sort_list.SelectedValue, 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    dl_product_list.DataSource = dt;
                    dl_product_list.DataBind();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(dt.Rows[i][5]) <= 0)
                        {
                            (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(dt.Rows[i][6]) > 0)
                        {
                            (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + dt.Rows[i][4].ToString();
                            (dl_product_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString())) * ((int)dt.Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                }
                

            }

            if (ddl_sort_list.SelectedValue == "Descending")
            {
                if (Request.QueryString["category"] != null)
                {
                    displayProductList();
                }
                else
                {
                    productClass = new ProductClass();
                    dt = productClass.sortProductDetails("spSortProductsList", ddl_sort_list.SelectedValue, 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    dl_product_list.DataSource = dt;
                    dl_product_list.DataBind();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(dt.Rows[i][5]) <= 0)
                        {
                            (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(dt.Rows[i][6]) > 0)
                        {
                            (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + dt.Rows[i][4].ToString();
                            (dl_product_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString())) * ((int)dt.Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                }
               
            }

            if (ddl_sort_list.SelectedValue == "LowToHigh")
            {
                if (Request.QueryString["category"] != null)
                {
                    displayProductList();
                }
                else
                {
                    productClass = new ProductClass();
                    dt = productClass.sortProductDetails("spSortProductsList", ddl_sort_list.SelectedValue, 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    dl_product_list.DataSource = dt;
                    dl_product_list.DataBind();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(dt.Rows[i][5]) <= 0)
                        {
                            (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(dt.Rows[i][6]) > 0)
                        {
                            (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + dt.Rows[i][4].ToString();
                            (dl_product_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString())) * ((int)dt.Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                }
                
            }

            if (ddl_sort_list.SelectedValue == "HighToLow")
            {
                if (Request.QueryString["category"] != null)
                {
                    displayProductList();
                }
                else
                {
                    productClass = new ProductClass();
                    dt = productClass.sortProductDetails("spSortProductsList", ddl_sort_list.SelectedValue, 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                    dl_product_list.DataSource = dt;
                    dl_product_list.DataBind();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (Convert.ToInt32(dt.Rows[i][5]) <= 0)
                        {
                            (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                            (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                            (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                        }
                        if (Convert.ToInt32(dt.Rows[i][6]) > 0)
                        {
                            (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + dt.Rows[i][4].ToString();
                            (dl_product_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString())) * ((int)dt.Rows[i][6])) / 100).ToString();
                        }
                        else
                        {
                            (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                        }
                    }
                }
            }
        }

        protected void ddl_sort_list_SelectedIndexChanged(object sender, EventArgs e)
        {
            sortListBy();
        }

        //Method to display ProductList With Filter and sorting
        /*********************************************************************************************/
        protected void displayProductList()
        {
            string category = Request.QueryString["category"];
            productClass = new ProductClass();
            dt = productClass.sortProductDetailsWithFilter("spSortProductsListWithFilter", ddl_sort_list.SelectedValue, category, 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
            dl_product_list.DataSource = dt;
            dl_product_list.DataBind();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (Convert.ToInt32(dt.Rows[i][5]) <= 0)
                {
                    (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                    (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                    (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                }
                if (Convert.ToInt32(dt.Rows[i][6]) > 0)
                {
                    (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + dt.Rows[i][4].ToString();
                    (dl_product_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString())) * ((int)dt.Rows[i][6])) / 100).ToString();
                }
                else
                {
                    (dl_product_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                }
            }
        }
        //Method to display movie,music,book,product list by category/genre
        /***********************************************************************************************/

        protected void dl_audio_indian_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Audio Indian")
            {
                Response.Redirect("MusicList.aspx?category=" + Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }
        protected void dl_international_cat_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Audio International")
            {
                Response.Redirect("MusicList.aspx?category=" + Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        protected void dl_video_indian_ItemCommand(object source, DataListCommandEventArgs e)
        {
            Response.Redirect("MusicList.aspx?category=" + Server.UrlEncode(e.CommandArgument.ToString()));
        }

        protected void dl_video_international_ItemCommand(object source, DataListCommandEventArgs e)
        {
            Response.Redirect("MusicList.aspx?category=" + Server.UrlEncode(e.CommandArgument.ToString()));
        }

        protected void dl_movie_cat_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Movie")
            {
                Response.Redirect("MovieList.aspx?category=" +Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }
        protected void dl_book_cat_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Book")
            {
                Response.Redirect("BookList.aspx?category=" +Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        protected void dl_product_cat_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Product")
            {
                Response.Redirect("ProductList.aspx?category=" +Server.UrlEncode(e.CommandArgument.ToString()));
            }
        }

        //Method To Display List with specific Category and Format
        /****************************************************************************************************/
        //protected void dl_format_details_ItemCommand(object source, DataListCommandEventArgs e)
        //{
        //    productClass = new ProductClass();
        //    dt = productClass.GetProductDetailsByCategoryAndFormat(lbl_genre.Text, e.CommandArgument.ToString(), "Music");
        //    dl_product_list.DataSource = dt;
        //    dl_product_list.DataBind();
        //    format_div.Visible = false;
        //}

        //Method To Display List by changing list count
        /****************************************************************************************************/
        protected void ddl_total_products_SelectedIndexChanged(object sender, EventArgs e)
        {
            string category = Request.QueryString["category"];
            productClass = new ProductClass();
            if (category != null)
            {
                ds = productClass.fetchProductListWithFilter("product", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), category);
                dl_product_list.DataSource = ds.Tables[0];
                dl_product_list.DataBind();
                totalRows = (int)ds.Tables[1].Rows[0][0];
                DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
            }
            else
            {
                ds = productClass.fetchProductList("product", 0, Convert.ToInt32(ddl_total_products.SelectedItem.Text));
                dl_product_list.DataSource = ds.Tables[0];
                dl_product_list.DataBind();
                totalRows = (int)ds.Tables[1].Rows[0][0];
                DatabindRepeater(0, Convert.ToInt32(ddl_total_products.SelectedItem.Text), totalRows);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (Convert.ToInt32(ds.Tables[0].Rows[i][5]) <= 0)
                    {
                        (dl_product_list.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                        (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                        (dl_product_list.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                    }
                }
            }
            //dt = productClass.sortMusicDetails("spChangeListCountToDisplay", ddl_total_products.SelectedValue);
            //dl_product_list.DataSource = dt;
            //dl_product_list.DataBind();
        }

        //Method to add item to cart/wishlist/compare from Grid view
        /******************************************************************************************/
        protected void dl_music_list_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "AddCart")
            {
                Response.Redirect("Cart.aspx?Id=" + e.CommandArgument.ToString() + "&type=Product");
            }
            else if (e.CommandName == "Details")
            {
                Response.Redirect("ProductDetails.aspx?Id=" + e.CommandArgument + "&type=Product");
            }
            else if (e.CommandName == "Wishlist")
            {
                if (Session["UserID"] == null)
                {
                    //Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "clickedMe()", true);
                    //ScriptManager.RegisterStartupScript(Page, typeof(Page), "message", "javascript:clickedMe('" + (e.Item.FindControl("btn_wishList") as LinkButton) + "');", true);
                    //ClientMessageBox.Show("Please Login First", this);

                    //ClientMessageBox.Show("Please Login First", this);
                    lbl_wishlist_msg.Text = "Please Login First";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                }
                else
                {
                    productClass = new ProductClass();
                    productClass.title = (e.Item.FindControl("lbl_title") as Label).Text;
                    productClass.user_id = Session["UserId"].ToString();
                    productClass.mrp = Convert.ToDecimal((e.Item.FindControl("lbl_mrp") as Label).Text);
                    productClass.product_id = e.CommandArgument.ToString();
                    productClass.prod_image = (e.Item.FindControl("music_img") as Image).ImageUrl;
                    int i = productClass.addMusicDetailsToWishlist(productClass);

                    if (i >= 1)
                    {
                        lbl_wishlist_msg.Text = "Product Added To Wishlist";
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                    }
                }
            }
        }

        //Method to add item to cart/wishlist/compare from List view
        /******************************************************************************************/
        protected void dl_list_view_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "AddCart")
            {
                Response.Redirect("Cart.aspx?Id=" + e.CommandArgument.ToString() + "&type=Music");
            }
            else if (e.CommandName == "Details")
            {
                Response.Redirect("MusicDetails.aspx?Id=" + e.CommandArgument + "&type=Music");
            }
            else if (e.CommandName == "Wishlist")
            {
                if (Session["UserID"] == null)
                {
                    lbl_wishlist_msg.Text = "Please Login First";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                }
                else
                {
                    productClass = new ProductClass();
                    int i = 0;
                    //productClass.addMusicDetailsToWishlist(Session["UserId"].ToString(), e.CommandArgument.ToString());

                    if (i >= 1)
                    {
                        lbl_wishlist_msg.Text = "Product Added To Wishlist";
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                    }
                }
            }
        }

      
    }
}