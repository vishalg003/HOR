﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm
{
    public partial class register : System.Web.UI.Page
    {
        CustomerClass customerClass;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getCountries();
            }
        }

        protected void btn_register_Click(object sender, EventArgs e)
        {
            if (ddl_country.SelectedItem.Text == "--Select Country--")
            {
                lbl_country_error.Text = "Please Select Your Country";
                return;
            }
            customerClass = new CustomerClass();
            customerClass._FName = txtFname.Text;
            customerClass._LName = txtLname.Text;
            customerClass._Mobile = txtMobile.Text;
            customerClass._Alternate = txtAlternateNo.Text;
            customerClass._Email = txtEmail.Text;
            customerClass._Password = txtPassword.Text;
            customerClass._Address = txtAddress.Text;
            customerClass._country = ddl_country.SelectedItem.Text;
            customerClass._state = ddlstate.SelectedItem.Text;
            customerClass._city = ddlcity.SelectedItem.Text;
            customerClass._locality = txtlocality.Text;
            customerClass._pincode = txtpincode.Text;
           
             int row_affected = CustomerClass.insertUserDetails(customerClass);
             if (row_affected > 0)
             {
                 Response.Redirect("login.aspx");
             }
             else
             { 
                ClientMessageBox.Show("User Already Exist Please Enter Another Email Id",this);
             }
            
        }

        void clear()
        {
            txtFname.Text = txtLname.Text = txtMobile.Text = txtAlternateNo.Text = txtEmail.Text =
            txtPassword.Text = txtAddress.Text;
        }

        protected void ddl_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                getState();
                lbl_country_error.Visible = false;
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        protected void ddlstate_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                getCity();
            }
            catch (Exception)
            {

                throw;
            }
        }
        //Method to bind countries to dropdown
        /*************************************************************  */
        private void getCountries()
        {
            CartClass cart = new CartClass();
            dt = cart.getCountries();
            ddl_country.DataTextField = "name";
            ddl_country.DataValueField = "id";
            ddl_country.DataSource = dt;
            ddl_country.DataBind();
            ddl_country.SelectedItem.Text = "--Select Country--";
            

        }
        private void getState()
        {
            CartClass cart = new CartClass();
            dt = cart.getStates(Convert.ToInt32(ddl_country.SelectedValue));
            if (dt.Rows.Count > 0)
            {
                ddlstate.DataTextField = "name";
                ddlstate.DataValueField = "id";
                ddlstate.DataSource = dt;
                ddlstate.DataBind();
            }
        }

        private void getCity()
        {
            CartClass cart = new CartClass();
            dt = cart.getCities(Convert.ToInt32(ddlstate.SelectedValue));
            if (dt.Rows.Count > 0)
            {
                ddlcity.DataTextField = "name";
                ddlcity.DataSource = dt;
                ddlcity.DataBind();
            }
        }
    }
}