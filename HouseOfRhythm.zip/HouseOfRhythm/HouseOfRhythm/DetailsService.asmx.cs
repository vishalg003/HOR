﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm.WebService
{
    /// <summary>
    /// Summary description for DetailsService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class DetailsService : System.Web.Services.WebService
    {
        [WebMethod]
        public List<string> MusicCategory(string searchTerm, string origin, string media)
        {
            DataTable dt = (AdminProductClass.getMusicCategory("spAdminGetMusicCategoryToInsertUpdate", searchTerm, origin, media));
            List<string> musicCategory = dt.AsEnumerable().Select(r => r.Field<string>("Category_Name")).ToList();
            return musicCategory;
        }

        [WebMethod]
        public List<string> MovieCategory(string searchTerm)
        {
            DataTable dt = (AdminProductClass.getProductCategory("spAdminGetMovieCategoryToInsertUpdate", searchTerm));
            List<string> musicCategory = dt.AsEnumerable().Select(r => r.Field<string>("Category_Name")).ToList();
            return musicCategory;
        }

        [WebMethod]
        public List<string> BookCategory(string searchTerm)
        {
            DataTable dt = (AdminProductClass.getProductCategory("spAdminGetBookCategoryToInsertUpdate", searchTerm));
            List<string> musicCategory = dt.AsEnumerable().Select(r => r.Field<string>("Category_Name")).ToList();
            return musicCategory;
        }

        [WebMethod]
        public List<string> ProductCategory(string searchTerm)
        {
            DataTable dt = (AdminProductClass.getProductCategory("spAdminGetProductCategoryToInsertUpdate", searchTerm));
            List<string> musicCategory = dt.AsEnumerable().Select(r => r.Field<string>("Category_Name")).ToList();
            return musicCategory;
        }

        [WebMethod]
        public List<string> Distributors(string searchTerm)
        {
            DataTable dt = (AdminProductClass.getProductCategory("spAdminGetPurchaseDealersToInsertUpdate", searchTerm));
            List<string> musicCategory = dt.AsEnumerable().Select(r => r.Field<string>("dealer_name")).ToList();
            return musicCategory;
        }

        [WebMethod]
        public List<string> PurchaseProductTitle(string searchTerm)
        {
            DataTable dt = (AdminProductClass.getProductCategory("spAdminGetPurchaseProductTitleToInsertUpdate", searchTerm));
            List<string> musicCategory = dt.AsEnumerable().Select(r => r.Field<string>("title")).ToList();
            return musicCategory;
        }

        [WebMethod]
        public void rangeSlider(string value1)
        {
            //DataTable dt = (AdminProductClass.getProductCategory("spAdminGetPurchaseProductTitleToInsertUpdate", val1, val2));
            //List<string> musicCategory = dt.AsEnumerable().Select(r => r.Field<string>("title")).ToList();
            //return musicCategory;
        }
    }
}
