﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayerHor;

namespace HouseOfRhythm
{
    public partial class Order_overview : System.Web.UI.Page
    {
        CartClass order = new CartClass();
        DataTable dt;
        DataSet ds,ds1;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserId"] != null)
            {
                DisplayOrderDetails();
            }
        }

        private void DisplayOrderDetails()
        {
            try
            {
                order = new CartClass();
                ds = order.GetCartDetailsForDisplay(Session["UserId"].ToString());
                if (ds.Tables[0].Rows.Count > 0 && ds.Tables[1].Rows.Count > 0)
                {
                    dl_order_overview.DataSource = ds.Tables[1];
                    dl_order_overview.DataBind();
                    lblcartsubtotal.Text = ds.Tables[0].Rows[0][5].ToString();
                    lblshippingcharges.Text = ds.Tables[0].Rows[0][2].ToString();
                    lblgrandtotal.Text = ds.Tables[0].Rows[0][3].ToString();
                    for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                    {
                        if (Convert.ToDecimal(ds.Tables[1].Rows[i][6]) == Convert.ToDecimal(ds.Tables[1].Rows[i][8]))
                        {
                            (dl_order_overview.Items[i].FindControl("Label2") as Label).Visible = false;
                            (dl_order_overview.Items[i].FindControl("rs") as Label).Visible = false;
                        }
                        ds1 = order.getstockDetails((dl_order_overview.Items[i].FindControl("lblprodid") as Label).Text);
                        if (ds1.Tables[0].Rows.Count > 0)
                        {
                            if (Convert.ToInt32(ds1.Tables[0].Rows[0][0]) < Convert.ToInt32((dl_order_overview.Items[i].FindControl("lblquantity") as Label).Text) && Convert.ToChar(ds1.Tables[0].Rows[0][1]) != 'Y')
                            {
                                if (Convert.ToInt32(ds1.Tables[0].Rows[0][0]) < 1)
                                {
                                    (dl_order_overview.Items[i].FindControl("lbl_outofstock") as Label).Text = "Out Of stock";
                                    (dl_order_overview.Items[i].FindControl("lbl_message") as Label).Text = "This Prodeuct Not included in your order";
                                    (dl_order_overview.Items[i].FindControl("lbl_price_title") as Label).Visible = false;
                                    (dl_order_overview.Items[i].FindControl("lblprice") as Label).Visible = false;
                                    (dl_order_overview.Items[i].FindControl("rs") as Label).Visible = false;
                                    (dl_order_overview.Items[i].FindControl("Label2") as Label).Visible = false;
                                    (dl_order_overview.Items[i].FindControl("lblquantity") as Label).Visible = false;
                                    (dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Visible = false;
                                    decimal total = Convert.ToDecimal(lblgrandtotal.Text) - Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Text);
                                    decimal subtotal = Convert.ToDecimal(lblcartsubtotal.Text) - Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Text);
                                    lblcartsubtotal.Text = subtotal.ToString();
                                    if (Convert.ToDecimal(lblcartsubtotal.Text) <= 1000 && Convert.ToDecimal(lblshippingcharges.Text) != 60 && Convert.ToDecimal(lblcartsubtotal.Text)!=0 &&ds.Tables[0].Rows[0][6]=="India")
                                    {
                                        lblshippingcharges.Text = "60.00";
                                        lblgrandtotal.Text = (total + 60).ToString();
                                    }
                                    else
                                    {
                                        lblgrandtotal.Text = total.ToString();
                                        lblcartsubtotal.Text = subtotal.ToString();
                                    }
                                }
                                else
                                {
                                    (dl_order_overview.Items[i].FindControl("lbl_outofstock") as Label).Text = "Only " + ds1.Tables[0].Rows[0][0].ToString() + "  Available";
                                    (dl_order_overview.Items[i].FindControl("lblquantity") as Label).Text = ds1.Tables[0].Rows[0][0].ToString();
                                    decimal total = Convert.ToDecimal(lblgrandtotal.Text) - Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Text);
                                    decimal subtotal = Convert.ToDecimal(lblcartsubtotal.Text) - Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Text);
                                    if ((dl_order_overview.Items[i].FindControl("lblprice") as Label).Text != (dl_order_overview.Items[i].FindControl("Label2") as Label).Text)
                                    {
                                        (dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Text = (Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblquantity") as Label).Text) * Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblprice") as Label).Text)).ToString();
                                        total = total + Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Text);
                                        subtotal = subtotal + Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Text);
                                    }
                                    else
                                    {
                                        (dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Text = (Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblquantity") as Label).Text) * Convert.ToDecimal((dl_order_overview.Items[i].FindControl("Label2") as Label).Text)).ToString();
                                        total = total + Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Text);
                                        subtotal = subtotal + Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Text);
                                    }
                                    decimal shipping = Convert.ToDecimal(lblshippingcharges.Text);
                                    decimal cartsubtotal = Convert.ToDecimal(lblcartsubtotal.Text);
                                    if (subtotal <= 1000 && shipping != 60 && cartsubtotal != 0 && ds.Tables[0].Rows[0][6].ToString() == "India")
                                    {
                                        lblshippingcharges.Text = "60.00";
                                        decimal pre_total = Convert.ToDecimal(lblgrandtotal.Text);
                                        lblgrandtotal.Text = (total+60).ToString();
                                        lblcartsubtotal.Text = subtotal.ToString();
                                    }
                                    else
                                    {
                                        lblgrandtotal.Text = total.ToString();
                                        lblcartsubtotal.Text = subtotal.ToString();
                                    }
                                }
                            }
                        }
                        else
                        {
                            (dl_order_overview.Items[i].FindControl("lbl_price_title") as Label).Visible = false;
                            (dl_order_overview.Items[i].FindControl("lblprice") as Label).Visible = false;
                            (dl_order_overview.Items[i].FindControl("rs") as Label).Visible = false;
                            (dl_order_overview.Items[i].FindControl("Label2") as Label).Visible = false;
                            (dl_order_overview.Items[i].FindControl("lblquantity") as Label).Visible = false;
                            (dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Visible = false;
                            (dl_order_overview.Items[i].FindControl("quantity") as Label).Visible = false;
                            (dl_order_overview.Items[i].FindControl("lbl_outofstock") as Label).Text = "Out Of stock";
                            (dl_order_overview.Items[i].FindControl("lbl_message") as Label).Text = "This Prodeuct Not included in your order";
                            decimal total = Convert.ToDecimal(lblgrandtotal.Text) - Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Text);
                            decimal subtotal = Convert.ToDecimal(lblcartsubtotal.Text) - Convert.ToDecimal((dl_order_overview.Items[i].FindControl("lblsubtotal") as Label).Text);
                            lblgrandtotal.Text = total.ToString();
                            if (total <= 1000 && Convert.ToDecimal(lblshippingcharges.Text) != 60 && Convert.ToDecimal(lblcartsubtotal.Text) != 0 && ds.Tables[0].Rows[0][6] == "India")
                            {
                                total = Convert.ToDecimal(lblgrandtotal.Text) + 60;
                                lblgrandtotal.Text = total.ToString();
                                lblshippingcharges.Text = "60.00";
                            }
                            lblcartsubtotal.Text = subtotal.ToString();
                        }
                        
                        
                    }
                    DataTable orderlist = new DataTable();
                    orderlist.Columns.Add("pro_id");
                    orderlist.Columns.Add("protitle");
                    orderlist.Columns.Add("proimage");
                    orderlist.Columns.Add("discountprice");
                    orderlist.Columns.Add("price");
                    orderlist.Columns.Add("quantity");
                    orderlist.Columns.Add("subtotal");
                    for (int j = 0; j < dl_order_overview.Items.Count; j++)
                    {
                        ds1 = order.getstockDetails((dl_order_overview.Items[j].FindControl("lblprodid") as Label).Text);
                        if (ds1.Tables[0].Rows.Count > 0)
                        {
                            if (Convert.ToInt32(ds1.Tables[0].Rows[0][0]) >= 1)
                            {
                                DataRow row = orderlist.NewRow();
                                row["pro_id"] = (dl_order_overview.Items[j].FindControl("lblprodid") as Label).Text;
                                row["protitle"] = (dl_order_overview.Items[j].FindControl("lblproducttitle") as Label).Text;
                                row["proimage"] = (dl_order_overview.Items[j].FindControl("productImage") as Image).ImageUrl;
                                row["discountprice"] = (dl_order_overview.Items[j].FindControl("lblprice") as Label).Text;
                                row["price"] = (dl_order_overview.Items[j].FindControl("Label2") as Label).Text;
                                row["quantity"] = (dl_order_overview.Items[j].FindControl("lblquantity") as Label).Text;
                                row["subtotal"] = (dl_order_overview.Items[j].FindControl("lblsubtotal") as Label).Text;
                                orderlist.Rows.Add(row);
                                Session["OrderList"] = orderlist;
                            }
                            else if (Convert.ToInt32(ds1.Tables[0].Rows[0][0]) <= 0 && Convert.ToChar(ds1.Tables[0].Rows[0][1]) == 'Y')
                            {
                                DataRow row = orderlist.NewRow();
                                row["pro_id"] = (dl_order_overview.Items[j].FindControl("lblprodid") as Label).Text;
                                row["protitle"] = (dl_order_overview.Items[j].FindControl("lblproducttitle") as Label).Text;
                                row["proimage"] = (dl_order_overview.Items[j].FindControl("productImage") as Image).ImageUrl;
                                row["discountprice"] = (dl_order_overview.Items[j].FindControl("lblprice") as Label).Text;
                                row["price"] = (dl_order_overview.Items[j].FindControl("Label2") as Label).Text;
                                row["quantity"] = (dl_order_overview.Items[j].FindControl("lblquantity") as Label).Text;
                                row["subtotal"] = (dl_order_overview.Items[j].FindControl("lblsubtotal") as Label).Text;
                                orderlist.Rows.Add(row);
                                Session["OrderList"] = orderlist;
                            }
                        }
                    }
                }
                else
                {
                    dl_order_overview.DataSource = null;
                    dl_order_overview.DataBind();
                }
                dt = new DataTable();
                dt = order.getUserDetailsForCheckout(Session["UserId"].ToString());
                lblname.Text=dt.Rows[0][0].ToString() + " " + dt.Rows[0][1].ToString();
                lbladdress.Text = dt.Rows[0][2].ToString();
                lbllocality.Text = dt.Rows[0][3].ToString() + ", " + dt.Rows[0][4].ToString() + ", " + dt.Rows[0][5].ToString();
                lblstate.Text = dt.Rows[0][6].ToString() + " (" + dt.Rows[0][7].ToString() + ")";
                DataTable shippingdetails = new DataTable();
                if (Session["ShippingDetails"] != null)
                {
                    shippingdetails = Session["ShippingDetails"] as DataTable;
                    lblshippingname.Text = shippingdetails.Rows[0][0].ToString();
                    lblshippingaddress.Text = shippingdetails.Rows[0][1].ToString();
                    lblshippinglocality.Text = shippingdetails.Rows[0][2].ToString() + ", " + shippingdetails.Rows[0][3].ToString() + ", " + shippingdetails.Rows[0][4].ToString(); ;
                    lblshippingstate.Text = shippingdetails.Rows[0][6].ToString() + ", " + shippingdetails.Rows[0][5].ToString();
                }
                else
                {
                    lblshippingname.Text = dt.Rows[0][0].ToString() + " " + dt.Rows[0][1].ToString();
                    lblshippingaddress.Text = dt.Rows[0][2].ToString();
                    lblshippinglocality.Text = dt.Rows[0][3].ToString() + ", " + dt.Rows[0][4].ToString() + ", " + dt.Rows[0][5].ToString();
                    lblshippingstate.Text = dt.Rows[0][6].ToString() + " (" + dt.Rows[0][7].ToString() + ")";
                }
                DataTable OrderTotal = new DataTable();
                OrderTotal.Columns.Add("Delivery_Charges");
                OrderTotal.Columns.Add("Total_amount");
                OrderTotal.Columns.Add("SubTotal");
                DataRow row1 = OrderTotal.NewRow();
                row1["Delivery_Charges"] = lblshippingcharges.Text;
                row1["Total_amount"] = lblgrandtotal.Text;
                row1["subTotal"] = lblcartsubtotal.Text;
                OrderTotal.Rows.Add(row1);
                Session["OrderTotal"] = OrderTotal;
                
            }
            catch (Exception)
            {

                throw;
            }
        }

        protected void dl_order_overview_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals("Delete"))
            {
                if (Session["UserId"] != null)
                {
                    string prodid = (e.Item.FindControl("lblprodid") as Label).Text;
                    order = new CartClass();
                    order._product_id = prodid;
                    order._email = Session["UserId"].ToString();
                    int i = order.DeleteProductFromCart(order);
                    DisplayOrderDetails();
                }
            }
        }
    }
}