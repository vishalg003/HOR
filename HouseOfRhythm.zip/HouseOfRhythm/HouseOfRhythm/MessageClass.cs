﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class MessageClass
{
    public MessageClass()
    {

    }
    static public string InsertMsg = "SUBMITTED SUCCESSFULLY";
    static public string DisApproveMsg = "DISAPPROVED SUCCESSFULLY";
    static public string ApproveMsg = "APPROVED SUCCESSFULLY";
    static public string UpdateMsg = "UPDATED SUCCESSFULLY";
    static public string DeleteMsg = "REMOVED SUCCESSFULLY";
    static public string AgreementMsg = "PLEASE CHECK THE TERMS & CONDITIONS FIRST";
    static public string ValidUserIdPassMsg = "INVALID USER ID OR PASSWORD";
    static public string AlreadyRegMgs = "YOU ARE ALREADY REGISTERED. TO RETRIEVE YOUR PASSWORD CLICK ON - FORGOT PASSWORD?";
    static public string LoginCheckMsg = "PLEASE DO LOGIN FIRST";
    static public string AlreadyApplied = "YOU ARE ALREADY APPLIED FOR THIS JOB";
    static public string Applied = "YOU HAVE APPLIED SUCCESSFULLY";
    static public string Replied = "YOU HAVE REPLIED SUCCESSFULLY";
    static public string FileFormat = "PLEASE UPLOAD THE FILE IN BELOW GIVEN FORMAT(S)";

}