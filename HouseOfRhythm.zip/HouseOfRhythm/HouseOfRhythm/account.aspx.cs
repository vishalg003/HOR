﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayerHor;

namespace HouseOfRhythm
{

    public partial class account : System.Web.UI.Page
    {
        ProductClass productClass;
        DataTable table,dt;
        DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] != null)
                {
                    get_OrderDetails();
                    getWishlist();
                    getCountries();
                    getUserDetailsforUpdate();
                }
                else
                {
                    Response.Redirect("login.aspx");
                }
            }
        }

        private void getWishlist()
        {
                productClass = new ProductClass();
                table = productClass.GetProductDetailsFromWishlist(Session["UserID"].ToString());
                dl_user_wishlist1.DataSource = table;
                dl_user_wishlist1.DataBind();
        }

        private void getUserDetailsforUpdate()
        {
            CustomerClass customer = new CustomerClass();
            ds=customer.getUserDetails(Session["UserId"].ToString());
            txtFname.Text=ds.Tables[0].Rows[0][0].ToString();
            txtLname.Text = ds.Tables[0].Rows[0][1].ToString();
            txtMobile.Text = ds.Tables[0].Rows[0][5].ToString();
            txtAlternateNo.Text = ds.Tables[0].Rows[0][6].ToString();
            txtEmail.Text = ds.Tables[0].Rows[0][2].ToString();
            //txtPassword.Text=table.Rows[0][3].ToString();
            txtAddress.Text = ds.Tables[0].Rows[0][4].ToString();
            ddlcountry.SelectedItem.Text = ds.Tables[0].Rows[0][7].ToString();
            if (ddlcountry.Text != "--Select Coutry--")
            {
                CartClass cart = new CartClass();
                if (ds.Tables[1].Rows.Count > 0)
                {
                    dt = cart.getStates(Convert.ToInt32(ds.Tables[1].Rows[0][0].ToString()));
                    if (dt.Rows.Count > 0)
                    {
                        ddlstate.DataTextField = "name";
                        ddlstate.DataValueField = "id";
                        ddlstate.DataSource = dt;
                        ddlstate.DataBind();
                    }
                }
                
                ddlstate.SelectedItem.Text = ds.Tables[0].Rows[0][8].ToString();
            }
            if (ddlstate.Text != "")
            {
                CartClass cart = new CartClass();
                if (ds.Tables[2].Rows.Count > 0)
                {
                    dt = cart.getCities(Convert.ToInt32(ds.Tables[2].Rows[0][0].ToString()));
                    if (dt.Rows.Count > 0)
                    {
                        ddlcity.DataTextField = "name";
                        ddlcity.DataSource = dt;
                        ddlcity.DataBind();
                    }
                    ddlcity.SelectedItem.Text = ds.Tables[0].Rows[0][9].ToString();
                }
                
            }
            //ddlstate.SelectedItem.Text=ds.Tables[0].Rows[0][8].ToString();
            //
            txtlocality.Text = ds.Tables[0].Rows[0][10].ToString();
            txtpincode.Text = ds.Tables[0].Rows[0][11].ToString();
            lbl_customer_name.Text = ds.Tables[0].Rows[0][0].ToString() + ds.Tables[0].Rows[0][1].ToString();
            lbl_name.Text = ds.Tables[0].Rows[0][0].ToString() + "  " + ds.Tables[0].Rows[0][1].ToString();
            lbl_address.Text = ds.Tables[0].Rows[0][4].ToString();
            lbl_locality_city.Text = ds.Tables[0].Rows[0][10].ToString() + ", " + ds.Tables[0].Rows[0][9].ToString() + ", " + ds.Tables[0].Rows[0][11].ToString();
            lbl_state_country.Text = ds.Tables[0].Rows[0][8].ToString() + " ( " + ds.Tables[0].Rows[0][7].ToString() + " )";
        }

        protected void btn_register_Click(object sender, EventArgs e)
        {
           CustomerClass customerClass = new CustomerClass();
            customerClass._FName = txtFname.Text;
            customerClass._LName = txtLname.Text;
            customerClass._Mobile = txtMobile.Text;
            customerClass._Alternate = txtAlternateNo.Text;
            customerClass._Email = Session["UserId"].ToString();
            customerClass._Address = txtAddress.Text;
            customerClass._country = ddlcountry.SelectedItem.Text;
            customerClass._state = ddlstate.SelectedItem.Text;
            customerClass._city = ddlcity.SelectedItem.Text;
            customerClass._locality = txtlocality.Text;
            customerClass._pincode = txtpincode.Text;
            int row_affected = CustomerClass.updateUserDetails(customerClass);
        }
        private void get_OrderDetails()
        {
            try
            {
                    productClass = new ProductClass();
                    table = productClass.GetOrderList(Session["UserID"].ToString());
                    dl_my_orders1.DataSource = table;
                    dl_my_orders1.DataBind();
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        protected void dl_user_wishlist1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.Equals("Remove"))
                {
                    productClass = new ProductClass();
                    productClass.user_id = Session["UserId"].ToString();
                    productClass.product_id = e.CommandArgument.ToString();
                    productClass.deleteProductFromWishlist(productClass);
                    getWishlist();

                }

            }
            catch (Exception)
            {
                
                throw;
            }
        }
        protected void ddlcountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                getState();
                //lbl_country_error.Visible = false;
            }
            catch (Exception)
            {

                throw;
            }
        }
        protected void ddlstate_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                getCity();
                //lbl_country_error.Visible = false;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void getCountries()
        {
            CartClass cart = new CartClass();
            dt = cart.getCountries();
            ddlcountry.DataTextField = "name";
            ddlcountry.DataValueField = "id";
            ddlcountry.DataSource = dt;
            ddlcountry.DataBind();
            ddlcountry.SelectedItem.Text = "--Select Country--";


        }
        private void getState()
        {
            CartClass cart = new CartClass();
            dt = cart.getStates(Convert.ToInt32(ddlcountry.SelectedValue));
            if (dt.Rows.Count > 0)
            {
                ddlstate.DataTextField = "name";
                ddlstate.DataValueField = "id";
                ddlstate.DataSource = dt;
                ddlstate.DataBind();
            }
        }

        private void getCity()
        {
            CartClass cart = new CartClass();
            dt = cart.getCities(Convert.ToInt32(ddlstate.SelectedValue));
            if (dt.Rows.Count > 0)
            {
                ddlcity.DataTextField = "name";
                ddlcity.DataSource = dt;
                ddlcity.DataBind();
            }
        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            try
            {
                CustomerClass customer = new CustomerClass();
                dt=customer.getPassword(Session["UserId"].ToString());
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        protected void btn_save1_Click(object sender, EventArgs e)
        {
            try
            {
                CustomerClass customer = new CustomerClass();
                dt = customer.getPassword(Session["UserId"].ToString());
                if (dt.Rows[0][0].ToString() == txtoldpassword.Text)
                {
                    if (txtnewpassword.Text == txtconfirmpassword.Text)
                    {
                        customer._Email = Session["UserId"].ToString();
                        customer._Password = txtconfirmpassword.Text;
                        int i = customer.ChangePassword(customer);
                        if (i > 0)
                        {

                            ClientMessageBox.Show("Password Changed Successfully", this);
                        }
                    }
                    else
                    {
                        //lblmessage.Text = "These Password don't match.Try again?";
                        //ClientMessageBox.Show("These Password don't match.Try again?", this);
                    }
                }
                else
                {
                    ClientMessageBox.Show("Please Enter Correct Old Password",this);
                }

            }
            catch (Exception)
            {
                
                throw;
            }
        }
    }
}