﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HouseOfRhythm
{
    public partial class TestPaypal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_paynow_Click(object sender, EventArgs e)
        {
            int orderid = 10000;
            Session["OrderID"] = orderid;
            Response.Write("<form action='https://www.sandbox.paypal.com/cgi-bin/webscr' method='post' name='buyCredits' id='buyCredits'>");
            Response.Write("<input type='hidden' name='cmd' value='_xclick'>");
            Response.Write("<input type='hidden' name='business' value='vishalg003@gmail.com'>");
            Response.Write("<input type='hidden' name='currency_code' value='USD'>");
            Response.Write("<input type='hidden' name='item_name' value='Payment for Donate'>");
            Response.Write("<input type='hidden' name='item_number' value='0'>");
            Response.Write("<input type='hidden' name='amount' value='1'>");
            Response.Write("<input type='hidden' name='return' value='http://localhost:1959/Default.aspx?order_id=" + orderid.ToString() + "'>");
            Response.Write("</form>");

            Response.Write("<script type='text/javascript'>");
            Response.Write("document.getElementById('buyCredits').submit();");
            Response.Write("</script>");
            //int orderid = 10000;
            //Session["OrderID"] = orderid;
            //Response.Write("<form action='https://www.paypal.com/cgi-bin/webscr' method='post' name='buyCredits' id='buyCredits'>");
            //Response.Write("<input type='hidden' name='cmd' value='_xclick'>");
            //Response.Write("<input type='hidden' name='business' value='vishalg003@gmail.com'>");
            //Response.Write("<input type='hidden' name='currency_code' value='INR'>");
            //Response.Write("<input type='hidden' name='item_name' value='Payment for Donate'>");
            //Response.Write("<input type='hidden' name='item_number' value='0'>");
            //Response.Write("<input type='hidden' name='amount' value='1'>");
            //Response.Write("<input type='hidden' name='return' value='http://localhost:1959/Default.aspx?order_id=" + orderid.ToString() + "'>");
            //Response.Write("</form>");

            //Response.Write("<script type='text/javascript'>");
            //Response.Write("document.getElementById('buyCredits').submit();");
            //Response.Write("</script>");
        }
    }
}