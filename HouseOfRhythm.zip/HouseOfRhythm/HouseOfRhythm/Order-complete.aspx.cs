﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayerHor;

namespace HouseOfRhythm
{
    public partial class Order_complete : System.Web.UI.Page
    {
        CartClass order;
        DataSet ds;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserId"] != null)
            {
                displayOrderDetails();
            }
        }

        private void displayOrderDetails()
        {
            try
            {
                 order = new CartClass();
                 ds = order.GetOrderDetailsForDisplay(Request.QueryString["orderid"]);
                dl_order_complete.DataSource=ds.Tables[0];
                dl_order_complete.DataBind();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    if (Convert.ToDecimal(ds.Tables[0].Rows[i][2]) == Convert.ToDecimal(ds.Tables[0].Rows[i][5]))
                    {
                        (dl_order_complete.Items[i].FindControl("Label2") as Label).Visible = false;
                        (dl_order_complete.Items[i].FindControl("rs") as Label).Visible = false;
                    }
                }
                lbl_sub_total.Text = ds.Tables[1].Rows[0][5].ToString();
                lblorderdate.Text = ds.Tables[1].Rows[0][1].ToString();
                lbl_shipping_charges.Text = ds.Tables[1].Rows[0][14].ToString();
                lbltotalamount.Text = ds.Tables[1].Rows[0][0].ToString();
                lblorderid.Text = ds.Tables[1].Rows[0][2].ToString();
                lblshippingname.Text = ds.Tables[1].Rows[0][7].ToString();
                lblshippingaddress.Text = ds.Tables[1].Rows[0][4].ToString();
                lblshippinglocality.Text = ds.Tables[1].Rows[0][11].ToString() + ", " + ds.Tables[1].Rows[0][10].ToString() + ", " + ds.Tables[1].Rows[0][12].ToString();
                lblshippingstate.Text = ds.Tables[1].Rows[0][9].ToString() + " (" + ds.Tables[1].Rows[0][8].ToString() + ")";
                dt = new DataTable();
                dt = order.getUserDetailsForCheckout(Session["UserId"].ToString());
                lblname.Text = dt.Rows[0][0].ToString() + " " + dt.Rows[0][1].ToString();
                lbladdress.Text = dt.Rows[0][2].ToString();
                lbllocality.Text = dt.Rows[0][3].ToString() + ", " + dt.Rows[0][4].ToString() + ", " + dt.Rows[0][5].ToString();
                lblstate.Text = dt.Rows[0][6].ToString() + " (" + dt.Rows[0][7].ToString() + ")";
            }
            catch (Exception)
            {
                
                throw;
            }
        }
    }
}