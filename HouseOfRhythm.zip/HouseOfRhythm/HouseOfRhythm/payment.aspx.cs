﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayerHor;
using System.Net.Mail;
using InstamojoAPI;
using System.IO;

namespace HouseOfRhythm
{
    public partial class payment : System.Web.UI.Page
    {
        CartClass placeorder;
        DataSet ds;
        DataTable dt,table,dt1,ordertotal;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                if (Session["TransactionID"] != null && Request.QueryString["id"] != null)
                {
                    if (Session["TransactionID"].ToString() == Request.QueryString["id"])
                    {
                        saveorderDetails();
                    }
                }
            }
        }
        protected void btnplaceorder_Click(object sender, EventArgs e)
        {
            if (chkcod.Checked)
            {
                saveorderDetails();
            }
            else if(chkonline.Checked)
            {
                
                string Insta_client_id = "tm5N2XNtpDhOAvkysqu5uTnsBH9RM4dxuSEQtzPi",
                  Insta_client_secret = "CYgHBSjFfJQYnqNgBVJzSL85bYZADrqWZorHpoE3nuxBIwDq1CARgV5P8BpV4LP13pw9pGOqMWo2lMpf33jFpvNwqTT21n1VC0so4gRHoMIY5PsElYGAq01cWwoFFRcs",
                  Insta_Endpoint = "https://api.instamojo.com/v2/",
                  Insta_Auth_Endpoint = "https://www.instamojo.com/oauth2/token/";

                Instamojo objClass = InstamojoImplementation.getApi(Insta_client_id, Insta_client_secret, Insta_Endpoint, Insta_Auth_Endpoint);

                PaymentOrder objPaymentRequest = new PaymentOrder();
                //Required POST parameters
                if (Session["ShippingDetails"] != null)
                {
                    dt = Session["ShippingDetails"] as DataTable;
                    objPaymentRequest.name = dt.Rows[0][0].ToString();
                    objPaymentRequest.phone = dt.Rows[0][7].ToString();
                }
                else
                {
                    placeorder = new CartClass();
                    table = placeorder.getUserDetailsForCheckout(Session["UserId"].ToString());
                    objPaymentRequest.name = table.Rows[0][0] + " " + table.Rows[0][1].ToString();
                    objPaymentRequest.phone = table.Rows[0][8].ToString();

                }
                if(Session["OrderTotal"]!=null)
                {
                    ordertotal = Session["OrderTotal"] as DataTable;
                }
                objPaymentRequest.email = Session["UserId"].ToString();
                objPaymentRequest.description = "House of Rhythm";
                objPaymentRequest.amount = 9; //Convert.ToDouble(ordertotal.Rows[0][1]);
                objPaymentRequest.currency = "INR";
                objPaymentRequest.transaction_id = "0000001";

                string randomName = Path.GetRandomFileName();
                randomName = randomName.Replace(".", string.Empty);
                objPaymentRequest.transaction_id = "test" + randomName;

                objPaymentRequest.redirect_url = "http://localhost:1959/payment.aspx";
                objPaymentRequest.webhook_url = "https://your.server.com/webhook";

                CreatePaymentOrderResponse objPaymentResponse = objClass.createNewPaymentRequest(objPaymentRequest);
                string url = objPaymentResponse.payment_options.payment_url;
                string ID = url.Substring(41);
                string[] UrlId = ID.Split('?');
                ID = UrlId[0];
                Session["TransactionID"] = ID;
                Response.Redirect(url);
            }
        }

        private void saveorderDetails()
        {
            try
            {
                string orderid = "";
                placeorder = new CartClass();
                dt = Session["ShippingDetails"] as DataTable;
                table = placeorder.getUserDetailsForCheckout(Session["UserId"].ToString());
                ds = placeorder.GetCartDetailsForDisplay(Session["UserId"].ToString());
                orderid = AutoIncrementCode.get_order_Id();
                placeorder.order_id = orderid;
                placeorder._email = Session["UserId"].ToString();
                ordertotal = new DataTable();
                ordertotal = Session["OrderTotal"] as DataTable;
                if (Session["OrderTotal"] != null && Session["OrderList"] != null)
                {
                    placeorder._delivery_charges = Convert.ToDecimal(ordertotal.Rows[0][0]);
                    placeorder._total_amount = Convert.ToDecimal(ordertotal.Rows[0][1]);
                    placeorder._cart_subtotal = Convert.ToDecimal(ordertotal.Rows[0][2]);
                    placeorder._order_date = DateTime.Now.ToString();

                    if (Session["shippingDetails"] != null)
                    {
                        placeorder._shipping_address = dt.Rows[0][1].ToString();
                        placeorder._name = dt.Rows[0][0].ToString();
                        placeorder._country = dt.Rows[0][2].ToString();
                        placeorder._state = dt.Rows[0][3].ToString();
                        placeorder._city = dt.Rows[0][4].ToString();
                        placeorder._locality = dt.Rows[0][5].ToString();
                        placeorder._pincode = dt.Rows[0][6].ToString();
                        placeorder._mobile_no = dt.Rows[0][7].ToString();
                    }
                    else
                    {
                        placeorder._shipping_address = table.Rows[0][2].ToString();
                        placeorder._name = table.Rows[0][0] + " " + table.Rows[0][1].ToString();
                        placeorder._country = table.Rows[0][7].ToString();
                        placeorder._state = table.Rows[0][6].ToString();
                        placeorder._city = table.Rows[0][4].ToString();
                        placeorder._locality = table.Rows[0][3].ToString();
                        placeorder._pincode = table.Rows[0][5].ToString();
                        placeorder._mobile_no = table.Rows[0][8].ToString();
                    }
                    placeorder._payment_type = "Cash On Delivery";
                    placeorder._order_status = "Pending";
                    placeorder.insertOrderDetails(placeorder);
                    DataTable orderlist = new DataTable();
                    orderlist = Session["OrderList"] as DataTable;
                    for (int i = 0; i < orderlist.Rows.Count; i++)
                    {
                        placeorder.order_id = orderid;
                        placeorder._product_id = orderlist.Rows[i][0].ToString();
                        placeorder._quantity = orderlist.Rows[i][5].ToString();
                        placeorder._subtotal = Convert.ToDecimal(orderlist.Rows[i][6].ToString());
                        placeorder._product_title = orderlist.Rows[i][1].ToString();
                        placeorder._product_image = orderlist.Rows[i][2].ToString();
                        placeorder._product_mrp = Convert.ToDecimal(orderlist.Rows[i][3].ToString());
                        placeorder._email = Session["UserId"].ToString();
                        placeorder._original_price = Convert.ToDecimal(orderlist.Rows[i][4]);
                        placeorder.insertOrderProductDetails(placeorder);
                        DataSet ds1;
                        ds1 = placeorder.getstockDetails(orderlist.Rows[i][0].ToString());
                        int stock = Convert.ToInt32(ds1.Tables[0].Rows[0][0].ToString());
                        CartClass cart = new CartClass();
                        int update_stock = stock - Convert.ToInt32(placeorder._quantity);
                        cart._product_id = placeorder._product_id;
                        cart.stock = update_stock;
                        cart.updateStockAfterOrder(cart);
                    }
                    if (Session["shippingDetails"] != null)
                    {
                        MailMessage mailMessage = new MailMessage("nitikeshkedari@gmail.com", Session["UserId"].ToString());
                        mailMessage.Subject = "";
                        mailMessage.Body = "Dear " + dt.Rows[0][0].ToString() + "\n" + "Thank you for your online purchase.This is a confirmation and summary of your order,which is currently being processed" + "\n\n\n" +
                            "For your convinence, you'll be able to check the status of all your online orders and manage your account by visiting the 'My Account' Section of our Website or by clicking this link" + "\n\n" +
                            "www.houseofrhythm.in/myaccount.aspx?" + Session["UserId"].ToString() + "\n\n\n" +
                            "Here is a review of your order:" + "\n\n" +
                            "Your Order Number is:" + orderid +
                            "\n\n" +
                            "Subtotal-" + ordertotal.Rows[0][2] + "\n" +
                            "Delivery Charges-" + ordertotal.Rows[0][0] + "\n" +
                            "Total Amount-" + ordertotal.Rows[0][1] +

                                           " \n\n\nKind Regards,\nHouse Of Rhythm.";
                        SmtpClient smtpClient = new SmtpClient();
                        try
                        {
                            smtpClient.Send(mailMessage);
                        }
                        catch (Exception)
                        {
                        }
                    }
                    else
                    {
                        MailMessage mailMessage = new MailMessage("nitikeshkedari@gmail.com", Session["UserId"].ToString());
                        mailMessage.Subject = "Order Confirmation-Your Order with House Of Rhythm " + orderid + " has been Successfully Placed";
                        mailMessage.Body = "Dear " + table.Rows[0][0] + " " + table.Rows[0][1].ToString() + "\n" + "Thank you for your online purchase.This is a confirmation and summary of your order,which is currently being processed" + "\n\n\n" +
                            "For your convinence, you'll be able to check the status of all your online orders and manage your account by visiting the 'My Account' Section of our Website or by clicking this link" + "\n\n" +
                            "www.houseofrhythm.in" + "\n\n\n" +
                            "Here is a review of your order:" + "\n\n" +
                            "Your Order Number is:" + orderid +
                            "\n\n" +
                            "Subtotal-" + ordertotal.Rows[0][2] + "\n" +
                            "Delivery Charges-" + ordertotal.Rows[0][0] + "\n" +
                            "Total Amount-" + ordertotal.Rows[0][1] +

                                           " \n\n\nKind Regards,\nHouse Of Rhythm.";
                        SmtpClient smtpClient = new SmtpClient();
                        try
                        {
                            smtpClient.Send(mailMessage);
                        }
                        catch (Exception)
                        {
                        }
                    }
                    Session.Remove("OrderTotal");
                    Session.Remove("OrderList");
                    //placeorder._product_id = ds.Tables[1].Rows[i][1].ToString();
                    //placeorder._quantity = ds.Tables[1].Rows[i][2].ToString();
                    //placeorder._subtotal = Convert.ToDecimal(ds.Tables[1].Rows[i][3].ToString());
                    //placeorder._product_title = ds.Tables[1].Rows[i][4].ToString();
                    //placeorder._product_image = ds.Tables[1].Rows[i][5].ToString();
                    //placeorder._product_mrp = Convert.ToDecimal(ds.Tables[1].Rows[i][6].ToString());
                    //placeorder._email = Session["UserId"].ToString();
                    //placeorder._original_price = Convert.ToDecimal(ds.Tables[1].Rows[i][8]);
                    //placeorder.insertOrderProductDetails(placeorder);
                    //int stock = Convert.ToInt32(ds1.Tables[0].Rows[0][0].ToString());
                    //CartClass cart = new CartClass();
                    //int update_stock = stock - Convert.ToInt32(placeorder._quantity);
                    //cart._product_id = placeorder._product_id;
                    //cart.stock = update_stock;
                    //cart.updateStockAfterOrder(cart);

                    Response.Redirect("Order-complete.aspx?orderid=" + orderid);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}