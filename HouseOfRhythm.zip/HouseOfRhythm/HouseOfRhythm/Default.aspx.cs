﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm
{
    public partial class Default : System.Web.UI.Page
    {
        DataTable dt;
        InsertBannerDetails insertBannerDetails;
        //BusinessLayerHor.ProductDetails productdetails;        
        ProductClass productClass;
        Advertisement add;
        List<string> list_id, list_type;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getBannerImages();
                getFeaturedProductsDetails();
                getNew_arrivalProductDetails();
                getBest_sellerProductDetails();
                get_PreorderList();
                getAdvertisement();
            }
        }

        private void getBannerImages()
        {
            insertBannerDetails = new InsertBannerDetails();
            dt = insertBannerDetails.fetchBannerImages();
            if (dt.Rows.Count > 0)
            {
                dt_main_banner.DataSource = dt;
                dt_main_banner.DataBind();
            }
           
        }

        //Method to get ralted items of displayed products 
        /**************************************************************************************************/
        private void getFeaturedProductsDetails()
        {
            productClass = new ProductClass();
            dt = productClass.fetchProductDetails("featured product");
            dl_featured_products.DataSource = dt;
            dl_featured_products.DataBind();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (Convert.ToInt32(dt.Rows[i][5]) <= 0)
                {
                    (dl_featured_products.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                    (dl_featured_products.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                    (dl_featured_products.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                }
                if (Convert.ToInt32(dt.Rows[i][6]) > 0)
                {
                    (dl_featured_products.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + dt.Rows[i][4].ToString();
                    (dl_featured_products.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString())) * ((int)dt.Rows[i][6])) / 100).ToString();
                }
                else
                {
                    (dl_featured_products.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                }
            }
        }
        private void get_PreorderList()
        {
            try
            {
                productClass = new ProductClass();
                dt = productClass.fetchProductDetails("preorder");
                dl_preorder_list.DataSource = dt;
                dl_preorder_list.DataBind();
                //lbl_discount.Text = dt.Rows[1][5].ToString() + "% Off on Pre-Order Booking";
                for (int i = 0; i < dl_preorder_list.Items.Count; i++)
                {
                    if (Convert.ToInt32(dt.Rows[i][5]) > 0)
                    {
                        (dl_preorder_list.Items[i].FindControl("lbldiscount") as Label).Text = dt.Rows[i][5].ToString()+"% Off";
                        (dl_preorder_list.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + dt.Rows[i][4].ToString();
                        (dl_preorder_list.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString())) * ((int)dt.Rows[i][5])) / 100).ToString();
                    }
                    else
                    {
                        (dl_preorder_list.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                    }
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        private void getNew_arrivalProductDetails()
        {
            productClass = new ProductClass();
            dt = productClass.fetchProductDetails("new release");
            dl_new_arrival.DataSource = dt;
            dl_new_arrival.DataBind();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (Convert.ToInt32(dt.Rows[i][7]) <= 0)
                {
                    (dl_new_arrival.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                    (dl_new_arrival.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                    (dl_new_arrival.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                }
                if (Convert.ToInt32(dt.Rows[i][5]) > 0)
                {
                    (dl_new_arrival.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + dt.Rows[i][4].ToString();
                    (dl_new_arrival.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString())) * ((int)dt.Rows[i][5])) / 100).ToString();
                }
                else
                {
                    (dl_new_arrival.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                }
            }

        }
        private void getBest_sellerProductDetails()
        {
            productClass = new ProductClass();
            dt = productClass.fetchProductDetails("best_seller");
            dl_best_seller.DataSource = dt;
            dl_best_seller.DataBind();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (Convert.ToInt32(dt.Rows[i][7]) <= 0)
                {
                    (dl_best_seller.Items[i].FindControl("btn_add_cart") as Button).Enabled = false;
                    (dl_best_seller.Items[i].FindControl("lbl_stock") as Label).Text = "Out Of Stock";
                    (dl_best_seller.Items[i].FindControl("lbl_stock") as Label).Visible = true;
                }
                if (Convert.ToInt32(dt.Rows[i][5]) > 0)
                {
                    (dl_best_seller.Items[i].FindControl("lbl_discount") as Label).Text = "Rs." + dt.Rows[i][4].ToString();
                    (dl_best_seller.Items[i].FindControl("lbl_mrp") as Label).Text = ((Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString()))) - (Convert.ToInt32(Convert.ToDecimal(dt.Rows[i][4].ToString())) * ((int)dt.Rows[i][5])) / 100).ToString();
                }
                else
                {
                    (dl_best_seller.Items[i].FindControl("lbl_discount") as Label).Visible = false;
                }
            }
        }
        //Method to add product to cart, wishlist, compare
        /**************************************************************************************************/
        protected void dl_featured_products_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "AddCart")
            {
                Response.Redirect("Cart.aspx?Id=" + e.CommandArgument.ToString() + "&type="+(e.Item.FindControl("lbl_type") as Label).Text);
            }
            else if (e.CommandName == "Details")
            {
                if ((e.Item.FindControl("lbl_type") as Label).Text.Equals("Music"))
                    Response.Redirect("MusicDetails.aspx?Id=" + e.CommandArgument + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);

                else if ((e.Item.FindControl("lbl_type") as Label).Text.Equals("Movie"))
                    Response.Redirect("MovieDetails.aspx?Id=" + e.CommandArgument + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);

                else
                    Response.Redirect("BookDetails.aspx?Id=" + e.CommandArgument + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);
            }
            else if (e.CommandName == "Compare")
            {
                if (Request.Cookies["ProdId"] != null)
                {
                    list_id = ((Request.Cookies["ProdId"].Value).Split(',')).ToList();
                    list_type = ((Request.Cookies["ProdType"].Value).Split(',')).ToList();
                }
                if (Request.Cookies["ProdId"] == null)
                {
                    Response.Cookies["ProdId"].Value = e.CommandArgument.ToString();
                    Response.Cookies["ProdType"].Value = (e.Item.FindControl("lbl_type") as Label).Text;
                }
                else if (list_id.Count >= 2)
                {
                    ClientMessageBox.Show("You have Already select 2 Items", this);
                }
                else if ((Request.Cookies["ProdType"].Value).Contains((e.Item.FindControl("lbl_type") as Label).Text))
                {
                    Response.Cookies["ProdId"].Value = Request.Cookies["ProdId"].Value + "," + e.CommandArgument;
                    Response.Cookies["ProdId"].Expires = DateTime.Now.AddDays(1);
                    Response.Cookies["ProdType"].Value = Request.Cookies["ProdType"].Value + "," + (e.Item.FindControl("lbl_type") as Label).Text; ;
                    Response.Cookies["ProdType"].Expires = DateTime.Now.AddDays(1);
                }
                else
                {
                    ClientMessageBox.Show("Please Select Similar Type", this);
                }
            }
            else if (e.CommandName == "Wishlist")
            {
                if (Session["UserID"] == null)
                {
                    ClientMessageBox.Show("Please Login First", this);
                    //lbl_wishlist_msg.Text = "Please Login First";
                    //Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                }
                else
                {
                    productClass = new ProductClass();
                    productClass.title = (e.Item.FindControl("lbl_music_title") as Label).Text;
                    productClass.user_id = Session["UserId"].ToString();
                    productClass.mrp = Convert.ToDecimal((e.Item.FindControl("lbl_mrp") as Label).Text);
                    productClass.product_id = e.CommandArgument.ToString();
                    productClass.prod_image = (e.Item.FindControl("music_img") as Image).ImageUrl;
                    int i = productClass.addMusicDetailsToWishlist(productClass);

                    if (i >= 1)
                    {
                        //lbl_wishlist_msg.Text = "Product Addes To Wishlist";
                        //Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                        ClientMessageBox.Show("Product Added To Wish List", this);
                    }
                }
            }
            else
            {
                //Response.Redirect("Compare.aspx?Id=" + e.CommandArgument.ToString() + "&type=Music");
            }
        }

        protected void btn_Click(object sender, EventArgs e)
        {
            //Response.Redirect("~/shop-list.aspx");
        }

        //protected void dl_best_seller_ItemCommand(object source, DataListCommandEventArgs e)
        //{
        //    if(e.CommandName.Equals("AddToCart"))
        //    {
        //        Response.Redirect("Cart.aspx?Id=" + e.CommandArgument.ToString() + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);
        //    }
        //}

        //protected void dl_new_arrival_ItemCommand(object source, DataListCommandEventArgs e)
        //{
        //    if (e.CommandName.Equals("Add_ToCart"))
        //    {
        //        Response.Redirect("Cart.aspx?Id=" + e.CommandArgument.ToString() + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);
        //    }
        //}

        protected void dl_best_seller_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "AddCart")
            {
                Response.Redirect("Cart.aspx?Id=" + e.CommandArgument.ToString() + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);
            }
            else if (e.CommandName == "Details")
            {
                if ((e.Item.FindControl("lbl_type") as Label).Text.Equals("Music"))
                    Response.Redirect("MusicDetails.aspx?Id=" + e.CommandArgument + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);

                else if ((e.Item.FindControl("lbl_type") as Label).Text.Equals("Movie"))
                    Response.Redirect("MovieDetails.aspx?Id=" + e.CommandArgument + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);

                else
                    Response.Redirect("BookDetails.aspx?Id=" + e.CommandArgument + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);
            }
            else if (e.CommandName == "Compare")
            {
                if (Request.Cookies["ProdId"] != null)
                {
                    list_id = ((Request.Cookies["ProdId"].Value).Split(',')).ToList();
                    list_type = ((Request.Cookies["ProdType"].Value).Split(',')).ToList();
                }
                if (Request.Cookies["ProdId"] == null)
                {
                    Response.Cookies["ProdId"].Value = e.CommandArgument.ToString();
                    Response.Cookies["ProdType"].Value = (e.Item.FindControl("lbl_type") as Label).Text;
                }
                else if (list_id.Count >= 2)
                {
                    ClientMessageBox.Show("You have Already select 2 Items", this);
                }
                else if ((Request.Cookies["ProdType"].Value).Contains((e.Item.FindControl("lbl_type") as Label).Text))
                {
                    Response.Cookies["ProdId"].Value = Request.Cookies["ProdId"].Value + "," + e.CommandArgument;
                    Response.Cookies["ProdId"].Expires = DateTime.Now.AddDays(1);
                    Response.Cookies["ProdType"].Value = Request.Cookies["ProdType"].Value + "," + (e.Item.FindControl("lbl_type") as Label).Text; ;
                    Response.Cookies["ProdType"].Expires = DateTime.Now.AddDays(1);
                }
                else
                {
                    ClientMessageBox.Show("Please Select Similar Type", this);
                }
            }
            else if (e.CommandName == "Wishlist")
            {
                if (Session["UserID"] == null)
                {
                    ClientMessageBox.Show("Please Login First", this);
                    //lbl_wishlist_msg.Text = "Please Login First";
                    //Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                }
                else
                {
                    productClass = new ProductClass();
                    productClass.title = (e.Item.FindControl("lbl_music_title") as Label).Text;
                    productClass.user_id = Session["UserId"].ToString();
                    productClass.mrp = Convert.ToDecimal((e.Item.FindControl("lbl_mrp") as Label).Text);
                    productClass.product_id = e.CommandArgument.ToString();
                    productClass.prod_image = (e.Item.FindControl("music_img") as Image).ImageUrl;
                    int i = productClass.addMusicDetailsToWishlist(productClass);

                    if (i >= 1)
                    {
                        //lbl_wishlist_msg.Text = "Product Addes To Wishlist";
                        //Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                        ClientMessageBox.Show("Product Added To Wish List", this);
                    }
                }
            }
        }


        private void getAdvertisement()
        {
            add = new Advertisement();
            dt = add.getAdvertisement();
            if (dt.Rows.Count > 0)
            {
                dl_advertise.DataSource = dt;
                dl_advertise.DataBind();
                //ad_image1.ImageUrl = dt.Rows[0][1].ToString();
                //ad_image2.ImageUrl = dt.Rows[1][1].ToString();
                //ad_image3.ImageUrl = dt.Rows[2][1].ToString();
            }
        }
        protected void dl_new_arrival_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "AddCart")
            {
                Response.Redirect("Cart.aspx?Id=" + e.CommandArgument.ToString() + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);
            }
            else if (e.CommandName == "Details")
            {
                if ((e.Item.FindControl("lbl_type") as Label).Text.Equals("Music"))
                    Response.Redirect("MusicDetails.aspx?Id=" + e.CommandArgument + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);

                else if ((e.Item.FindControl("lbl_type") as Label).Text.Equals("Movie"))
                    Response.Redirect("MovieDetails.aspx?Id=" + e.CommandArgument + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);

                else
                    Response.Redirect("BookDetails.aspx?Id=" + e.CommandArgument + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);
            }
            else if (e.CommandName == "Compare")
            {
                if (Request.Cookies["ProdId"] != null)
                {
                    list_id = ((Request.Cookies["ProdId"].Value).Split(',')).ToList();
                    list_type = ((Request.Cookies["ProdType"].Value).Split(',')).ToList();
                }
                if (Request.Cookies["ProdId"] == null)
                {
                    Response.Cookies["ProdId"].Value = e.CommandArgument.ToString();
                    Response.Cookies["ProdType"].Value = (e.Item.FindControl("lbl_type") as Label).Text;
                }
                else if (list_id.Count >= 2)
                {
                    ClientMessageBox.Show("You have Already select 2 Items", this);
                }
                else if ((Request.Cookies["ProdType"].Value).Contains((e.Item.FindControl("lbl_type") as Label).Text))
                {
                    Response.Cookies["ProdId"].Value = Request.Cookies["ProdId"].Value + "," + e.CommandArgument;
                    Response.Cookies["ProdId"].Expires = DateTime.Now.AddDays(1);
                    Response.Cookies["ProdType"].Value = Request.Cookies["ProdType"].Value + "," + (e.Item.FindControl("lbl_type") as Label).Text; ;
                    Response.Cookies["ProdType"].Expires = DateTime.Now.AddDays(1);
                }
                else
                {
                    ClientMessageBox.Show("Please Select Similar Type", this);
                }
            }
            else if (e.CommandName == "Wishlist")
            {
                if (Session["UserID"] == null)
                {
                    ClientMessageBox.Show("Please Login First", this);
                    //lbl_wishlist_msg.Text = "Please Login First";
                    //Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                }
                else
                {
                    productClass = new ProductClass();
                    productClass.title = (e.Item.FindControl("lbl_music_title") as Label).Text;
                    productClass.user_id = Session["UserId"].ToString();
                    productClass.mrp = Convert.ToDecimal((e.Item.FindControl("lbl_mrp") as Label).Text);
                    productClass.product_id = e.CommandArgument.ToString();
                    productClass.prod_image = (e.Item.FindControl("music_img") as Image).ImageUrl;
                    int i = productClass.addMusicDetailsToWishlist(productClass);

                    if (i >= 1)
                    {
                        //lbl_wishlist_msg.Text = "Product Addes To Wishlist";
                        //Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                        ClientMessageBox.Show("Product Added To Wish List", this);
                    }
                }
            }
        }

        protected void dl_preorder_list_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "AddCart")
            {
                Response.Redirect("Cart.aspx?Id=" + e.CommandArgument.ToString() + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);
            }
            else if (e.CommandName == "Details")
            {
                if ((e.Item.FindControl("lbl_type") as Label).Text.Equals("Music"))
                    Response.Redirect("MusicDetails.aspx?Id=" + e.CommandArgument + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);

                else if ((e.Item.FindControl("lbl_type") as Label).Text.Equals("Movie"))
                    Response.Redirect("MovieDetails.aspx?Id=" + e.CommandArgument + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);

                else
                    Response.Redirect("BookDetails.aspx?Id=" + e.CommandArgument + "&type=" + (e.Item.FindControl("lbl_type") as Label).Text);
            }
            else if (e.CommandName == "Compare")
            {
                if (Request.Cookies["ProdId"] != null)
                {
                    list_id = ((Request.Cookies["ProdId"].Value).Split(',')).ToList();
                    list_type = ((Request.Cookies["ProdType"].Value).Split(',')).ToList();
                }
                if (Request.Cookies["ProdId"] == null)
                {
                    Response.Cookies["ProdId"].Value = e.CommandArgument.ToString();
                    Response.Cookies["ProdType"].Value = (e.Item.FindControl("lbl_type") as Label).Text;
                }
                else if (list_id.Count >= 2)
                {
                    ClientMessageBox.Show("You have Already select 2 Items", this);
                }
                else if ((Request.Cookies["ProdType"].Value).Contains((e.Item.FindControl("lbl_type") as Label).Text))
                {
                    Response.Cookies["ProdId"].Value = Request.Cookies["ProdId"].Value + "," + e.CommandArgument;
                    Response.Cookies["ProdId"].Expires = DateTime.Now.AddDays(1);
                    Response.Cookies["ProdType"].Value = Request.Cookies["ProdType"].Value + "," + (e.Item.FindControl("lbl_type") as Label).Text; ;
                    Response.Cookies["ProdType"].Expires = DateTime.Now.AddDays(1);
                }
                else
                {
                    ClientMessageBox.Show("Please Select Similar Type", this);
                }
            }
            else if (e.CommandName == "Wishlist")
            {
                if (Session["UserID"] == null)
                {
                    ClientMessageBox.Show("Please Login First", this);
                    //lbl_wishlist_msg.Text = "Please Login First";
                    //Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                }
                else
                {
                    productClass = new ProductClass();
                    productClass.title = (e.Item.FindControl("lbl_music_title") as Label).Text;
                    productClass.user_id = Session["UserId"].ToString();
                    productClass.mrp = Convert.ToDecimal((e.Item.FindControl("lbl_mrp") as Label).Text);
                    productClass.product_id = e.CommandArgument.ToString();
                    productClass.prod_image = (e.Item.FindControl("music_img") as Image).ImageUrl;
                    int i = productClass.addMusicDetailsToWishlist(productClass);

                    if (i >= 1)
                    {
                        //lbl_wishlist_msg.Text = "Product Addes To Wishlist";
                        //Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "msg()", true);
                        ClientMessageBox.Show("Product Added To Wish List", this);
                    }
                }
            }
        }

        protected void ad_image1_Click(object sender, ImageClickEventArgs e)
        {
             add = new Advertisement();
            dt = add.getAdvertisement();
            Response.Redirect(dt.Rows[0][0].ToString());
            
        }

        protected void ad_image2_Click(object sender, ImageClickEventArgs e)
        {
            add = new Advertisement();
            dt = add.getAdvertisement();
            Response.Redirect(dt.Rows[1][0].ToString());
        }

        protected void ad_image3_Click(object sender, ImageClickEventArgs e)
        {
            add = new Advertisement();
            dt = add.getAdvertisement();
            Response.Redirect(dt.Rows[2][0].ToString());
        }

        protected void dl_advertise_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals("OnClick"))
            {
                Response.Redirect(e.CommandArgument.ToString());
            }
        }

        protected void dt_main_banner_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName.Equals("BuyNow"))
            {
                if ((e.Item.FindControl("lbl_type") as Label).Text == "Music")
                {
                    Response.Redirect("MusicDetails.aspx?Id=" + e.CommandArgument + "&type=Music");
                }
                else if ((e.Item.FindControl("lbl_type") as Label).Text == "Movie")
                {
                    Response.Redirect("MovieDetails.aspx?Id=" + e.CommandArgument + "&type=Movie");
                }
                else if ((e.Item.FindControl("lbl_type") as Label).Text == "Book")
                {
                    Response.Redirect("BookDEtails.aspx?Id=" + e.CommandArgument + "&type=Book");
                }
                else
                { 
                    Response.Redirect("ProductDetails.aspx?Id="+e.CommandArgument+"&type=Product");
                }
               
            }
        }

    }
}