﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using BusinessObject;
using System.IO;
using System.Drawing;
using System.Data;
using System.Drawing.Imaging;


namespace HouseOfRhythm.Admin
{
    public partial class AddMovies : System.Web.UI.Page
    {
        MoviesObject movieobject;
        DataTable table;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["Id"] != null)
                {
                    btnupdate.Enabled = true;
                    getMovieDetailsById();
                }
                else
                {
                    txtsearch.Text = AutoIncrementCode.get_Moviecode("spAutoIncrementMoviesCode");                    
                }
                getFormat();
                getAddedList();
            }
        }


        private void getFormat()
        {
            table = AdminClass.getFormatDetails();
            ddl_format.DataSource = table;
            ddl_format.DataTextField = "type";
            ddl_format.DataValueField = "type";
            ddl_format.DataBind();
        }
        private MoviesObject getValuesToInsertUpdate()
        {
            movieobject = new MoviesObject();
            movieobject._Id = txtsearch.Text;
            movieobject._Title = inputTitle.Text;
            movieobject._Actor = inputActor.Text;
            movieobject._Actress = inputActress.Text;
            movieobject._Director = inputDirector.Text;
            movieobject._Producer = inputProducer.Text;
            movieobject._Composer = inputComposer.Text;
            movieobject._Genre = txtGenre.Text;
            movieobject._realeaseYear = inputResease.Text;
            movieobject._Subtitle = inputSubtitle.Text;
            movieobject._Format = ddl_format.SelectedValue;
            movieobject._catalogNo = inputCatalogNo.Text;
            movieobject._Sku = inputSKU.Text;
            movieobject._barcodeNo = inputBarcodeNo.Text;
            movieobject._Label = inputLabel.Text;
            movieobject._no_of_disc = Convert.ToInt32(inputNoOfDisk.Text);
            movieobject._Stock = Convert.ToInt32(inputStock.Text);
            movieobject._Studios = inputStudios.Text;
            movieobject._Mrp = Convert.ToDecimal(inputMRP.Text);
            if (inputDiscount.Text != "")
                movieobject._Discount = Convert.ToInt32(inputDiscount.Text);
            else
                movieobject._Discount = 0;
            movieobject._Synopsis = inputDescription.Text;
            movieobject._Type = "Movie";
            movieobject._Runtime = inputRunTime.Text;
            movieobject._Rated = inputRated.Text;
            movieobject._Region = inputRegion.Text;
            movieobject._modifiedDate = DateTime.Now;
            movieobject._fromDate = inputFromDate.Text;
            movieobject._toDate = inputToDate.Text;
            movieobject.language = txtlanguage.Text;

            if (chk_featured_prod.Checked)
                movieobject._featuredProduct = 'Y';
            else
                movieobject._featuredProduct = 'N';

            if (chk_new_arrival.Checked)
                movieobject._newArrival = 'Y';
            else
                movieobject._newArrival = 'N';

            if (chk_best_seller.Checked)
                movieobject._bestSeller = 'Y';
            else
                movieobject._bestSeller = 'N';

            if (chk_approve.Checked)
                movieobject._Approved = 'Y';
            else
                movieobject._Approved = 'N';

            if (chk_sale.Checked)
                movieobject._Sale = 'Y';
            else
                movieobject._Sale = 'N';
            if (chk_pre_order.Checked)
                movieobject._PreOrder = 'Y';
            else
                movieobject._PreOrder = 'N';

            if (FileUpload1.HasFile)
                PhotoUpload();
            else
            {
                movieobject._mainImage = lbl_mainImagePath.Text;
                movieobject._thumbnailImage = lbl_thumbnailImagePath.Text;
            }

            return movieobject;
        }


        /* Method to blank all textboxes */
        private void clearTextbox()
        {
            inputActor.Text = "";
            inputActress.Text = "";
            inputBarcodeNo.Text = "";
            inputCatalogNo.Text = "";
            inputComposer.Text = "";
            inputDescription.Text = "";
            inputDirector.Text = "";
            inputDiscount.Text = "";
            inputFromDate.Text = "";
            inputLabel.Text = "";
            inputMRP.Text = "";
            inputNoOfDisk.Text = "";
            inputProducer.Text = "";
            inputRated.Text = "";
            inputRegion.Text = "";
            inputResease.Text = "";
            inputRunTime.Text = "";
            inputSKU.Text = "";
            inputStock.Text = "";
            inputStudios.Text = "";
            inputSubtitle.Text = "";
            inputTitle.Text = "";
            inputToDate.Text = "";
            txtGenre.Text = "";
            
        }
        
        /* Method To Insert Product Record */
        /******************************************************************/
        protected void btnsave_Click(object sender, EventArgs e)
        {
            movieobject = getValuesToInsertUpdate();
            Movies movie = new Movies();
            int i = movie.insertUpdateMovies(movieobject);
            if (i > 0)
            {
                ClientMessageBox.Show("Record Inserted", this);
                clearTextbox();
            }
            txtsearch.Text = AutoIncrementCode.get_Moviecode("spAutoIncrementMoviesCode");
            getAddedList();
            getFormat();
          
        }

        /* Method To Update Product Record */
        /******************************************************************/
        protected void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                movieobject = getValuesToInsertUpdate();
                Movies movie = new Movies();
                int i = movie.updateMovies(movieobject);
                if (i > 0)
                {
                    ClientMessageBox.Show("Record Updated", this);
                }
                getAddedList();
                getFormat();
            }
            catch (Exception)
            {

                throw;
            }

        }


        /* ******************************************* Image Resizing Code *********************************************** */
        public void PhotoUpload()
        {
            if (FileUpload1.HasFile)
            {
                if (FileUpload1.PostedFile != null && FileUpload1.PostedFile.FileName != "")
                {
                    string strExtension = System.IO.Path.GetExtension(FileUpload1.FileName);
                    if ((strExtension.ToUpper() == ".JPG") || (strExtension.ToUpper() == ".JPEG") || (strExtension.ToUpper() == ".GIF") || (strExtension.ToUpper() == ".PNG"))
                    {
                        // Resize Image Before Uploading to Photo Folder
                        System.Drawing.Image imageToresize = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
                        int imgHeight = imageToresize.Height;
                        int imgWidth = imageToresize.Width;
                        int maxHeight = 684;
                        int maxWidth = 482;
                        imgHeight = (imgHeight * maxWidth) / imgWidth;
                        imgWidth = maxWidth;
                        if (imgHeight > maxHeight)
                        {
                            imgWidth = (imgWidth * imgHeight) / imgHeight;
                            imgHeight = maxHeight;
                        }

                        using (Bitmap bitmap = new Bitmap(imageToresize, imgWidth, imgHeight))
                        {
                            movieobject._mainImage = "~/ProductImages/Music/MainImage/" + movieobject._Id + strExtension;
                            bitmap.Save(Server.MapPath(movieobject._mainImage), System.Drawing.Imaging.ImageFormat.Jpeg);
                        }

                        imageToresize = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
                        imgHeight = imageToresize.Height;
                        imgWidth = imageToresize.Width;
                        maxHeight = 143;
                        maxWidth = 115;
                        imgHeight = (imgHeight * maxWidth) / imgWidth;
                        imgWidth = maxWidth;
                        if (imgHeight > maxHeight)
                        {
                            imgWidth = (imgWidth * imgHeight) / imgHeight;
                            imgHeight = maxHeight;
                        }

                        using (Bitmap bitmap = new Bitmap(imageToresize, imgWidth, imgHeight))
                        {
                            movieobject._thumbnailImage = "~/ProductImages/Music/Thumbnail/" + movieobject._Id + strExtension;
                            bitmap.Save(Server.MapPath(movieobject._thumbnailImage), System.Drawing.Imaging.ImageFormat.Jpeg);
                        }
                    }
                }

            }
        }

        //public void PhotoUpload()
        //{
        //    if (FileUpload1.HasFile)
        //    {
        //        if (FileUpload1.PostedFile != null && FileUpload1.PostedFile.FileName != "")
        //        {
        //            string strExtension = System.IO.Path.GetExtension(FileUpload1.FileName);
        //            if ((strExtension.ToUpper() == ".JPG") || (strExtension.ToUpper() == ".JPEG") || (strExtension.ToUpper() == ".GIF") || (strExtension.ToUpper() == ".PNG"))
        //            {
        //                // Resize Image Before Uploading to Photo Folder
        //                System.Drawing.Image imageToresize = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
        //                int imgHeight = imageToresize.Height;
        //                int imgWidth = imageToresize.Width;
        //                int maxHeight = 684;
        //                int maxWidth = 482;
        //                imgHeight = (imgHeight * maxWidth) / imgWidth;
        //                imgWidth = maxWidth;
        //                if (imgHeight > maxHeight)
        //                {
        //                    imgWidth = (imgWidth * imgHeight) / imgHeight;
        //                    imgHeight = maxHeight;
        //                }

        //                using (Bitmap bitmap = new Bitmap(imageToresize, imgWidth, imgHeight))
        //                {
        //                    imageToresize.Dispose();
        //                    movieobject._mainImage = "~/ProductImages/Movie/Main/" + movieobject._Id + strExtension;
        //                    bitmap.Save(Server.MapPath(movieobject._mainImage), System.Drawing.Imaging.ImageFormat.Jpeg);
        //                    bitmap.Dispose();
        //                }

        //                imageToresize = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
        //                imgHeight = imageToresize.Height;
        //                imgWidth = imageToresize.Width;
        //                maxHeight = 143;
        //                maxWidth = 115;
        //                imgHeight = (imgHeight * maxWidth) / imgWidth;
        //                imgWidth = maxWidth;
        //                if (imgHeight > maxHeight)
        //                {
        //                    imgWidth = (imgWidth * imgHeight) / imgHeight;
        //                    imgHeight = maxHeight;
        //                }

        //                using (Bitmap bitmap = new Bitmap(imageToresize, imgWidth, imgHeight))
        //                {
        //                    imageToresize.Dispose();
        //                    movieobject._thumbnailImage = "~/ProductImages/Movie/Thumbnail/" + movieobject._Id + strExtension;
        //                    bitmap.Save(Server.MapPath(movieobject._thumbnailImage), System.Drawing.Imaging.ImageFormat.Jpeg);
        //                    bitmap.Dispose();
        //                }
        //            }
        //        }
        //    }
        //    else
        //    {
        //        movieobject._mainImage = lblmainimage.Text;
        //        movieobject._thumbnailImage = lblthumbnailimage.Text;
        //    }

        //}

        private void getAddedList()
        {
            table = AdminClass.getRecords("Movie");
            gv_movie_list.DataSource = table;
            gv_movie_list.DataBind();
        }

        protected void GenerateBarcode(object sender, EventArgs e)
        {
            Random random = new Random();
            inputBarcodeNo.Text = (Convert.ToString(random.Next(10000000, 80000000)));
        }

        private void getMovieDetailsById()
        {
            table = AdminProductClass.getProductById(Request.QueryString["Id"], "Movie");
            if (table.Rows.Count > 0)
            {
                txtsearch.Text = table.Rows[0][0].ToString();
                inputTitle.Text = table.Rows[0][1].ToString();
                inputActor.Text = table.Rows[0][2].ToString();
                inputActress.Text = table.Rows[0][3].ToString();
                inputDirector.Text = table.Rows[0][4].ToString();
                inputProducer.Text = table.Rows[0][5].ToString();
                inputComposer.Text = table.Rows[0][6].ToString();
                inputSubtitle.Text = table.Rows[0][7].ToString();
                inputStudios.Text = table.Rows[0][8].ToString();
                inputResease.Text = table.Rows[0][9].ToString();
                inputRunTime.Text = table.Rows[0][10].ToString();
                inputRated.Text = table.Rows[0][11].ToString();
                inputRegion.Text = table.Rows[0][12].ToString();
                //inputGenre.Text = table.Rows[0][13].ToString();
                lbl_mainImagePath.Text = table.Rows[0][13].ToString();
                lbl_thumbnailImagePath.Text = table.Rows[0][14].ToString();
                inputCatalogNo.Text = table.Rows[0][15].ToString();
                inputSKU.Text = table.Rows[0][16].ToString();
                inputBarcodeNo.Text = table.Rows[0][17].ToString();
                inputLabel.Text = table.Rows[0][18].ToString();
                if (table.Rows[0][19].ToString() != "")
                    ddl_format.SelectedValue = table.Rows[0][19].ToString();
                txtGenre.Text = table.Rows[0][20].ToString();
                inputStock.Text = table.Rows[0][21].ToString();
                inputNoOfDisk.Text = table.Rows[0][22].ToString();
                inputMRP.Text = table.Rows[0][23].ToString();
                inputDiscount.Text = table.Rows[0][24].ToString();
                inputFromDate.Text = table.Rows[0][25].ToString();
                inputToDate.Text = table.Rows[0][26].ToString();
                inputDescription.Text = table.Rows[0][27].ToString();

                if (table.Rows[0][28].ToString() == "Y")
                    chk_new_arrival.Checked = true;
                else
                    chk_new_arrival.Checked = false;

                if (table.Rows[0][29].ToString() == "Y")
                    chk_best_seller.Checked = true;
                else
                    chk_best_seller.Checked = false;

                if (table.Rows[0][30].ToString() == "Y")
                    chk_featured_prod.Checked = true;
                else
                    chk_featured_prod.Checked = false;

                if (table.Rows[0][31].ToString() == "Y")
                    chk_sale.Checked = true;
                else
                    chk_sale.Checked = false;

                if (table.Rows[0][32].ToString() == "Y")
                    chk_approve.Checked = true;
                else
                    chk_approve.Checked = false;
                if (table.Rows[0][33].ToString() == "Y")
                    chk_pre_order.Checked = true;
                else
                    chk_pre_order.Checked = false;
            }
            else
            {
                ClientMessageBox.Show("No Record Found. Please Confirm Movie ID", this);
                txtsearch.Text = AutoIncrementCode.get_Moviecode("spAutoIncrementMoviesCode");
            }
        }
    }
}