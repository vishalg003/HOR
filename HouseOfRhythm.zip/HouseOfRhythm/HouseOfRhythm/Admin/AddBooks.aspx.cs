﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessObject;
using BusinessLayerHor;
using System.Drawing;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class AddBooks : System.Web.UI.Page
    {
        BookObject bookobject;
        DataTable table;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                if (Request.QueryString["Id"] != null)
                {
                    btnupdate.Enabled = true;
                    chk_sale.Enabled = true;
                    chk_approve.Enabled = true;
                    getBookDetailsById();
                }
                else
                {
                    txtsearch.Text = AutoIncrementCode.get_Bookcode("spAutoIncrementBooksCode");
                }
                getAddedList();
            }
            if (!IsPostBack)
            {
                getAddedList();
            }
        }

        /* Method to Insert Book Records */
        /*************************************************************************************/
        protected void btnsave_Click(object sender, EventArgs e)
        {
            bookobject = getValuesToInsertUpdate();
            Books book = new Books();
            int i = book.insertUpdateBook(bookobject);
            if (i > 0)
            {
                ClientMessageBox.Show("Record Inserted Succesfully", this);
            }
            ClearTextbox();
        }


       /*Method to blank all textboxes */
        private void ClearTextbox()
        {
            inputAuthor.Text = "";
            inputDescription.Text = "";
            inputDiscount.Text = "";
            inputFromDate.Text = "";
            inputISBN.Text = "";
            inputMRP.Text = "";
            inputNoOfPages.Text = "";
            inputPublish.Text = "";
            inputPublisher.Text = "";
            inputSize.Text = "";
            inputSKU.Text = "";
            inputStock.Text = "";
            inputTitle.Text = "";
            inputToDate.Text = "";
            txtGenre.Text = "";
        }
        /* Method to Update Book Records */
        /*************************************************************************************/
        protected void btnupdate_Click(object sender, EventArgs e)
        {
            bookobject = getValuesToInsertUpdate();
            Books book = new Books();
            int i = book.updateBookDetails(bookobject);
            if (i > 0)
            {
                ClientMessageBox.Show("Record Updated Succesfully", this);
                ClearTextbox();
            }
            getAddedList();
        }

        public void PhotoUpload()
        {
            if (FileUpload1.HasFile)
            {
                if (FileUpload1.PostedFile != null && FileUpload1.PostedFile.FileName != "")
                {
                    string strExtension = System.IO.Path.GetExtension(FileUpload1.FileName);
                    if ((strExtension.ToUpper() == ".JPG") || (strExtension.ToUpper() == ".JPEG") || (strExtension.ToUpper() == ".GIF") || (strExtension.ToUpper() == ".PNG"))
                    {
                        // Resize Image Before Uploading to Photo Folder
                        System.Drawing.Image imageToresize = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
                        int imgHeight = imageToresize.Height;
                        int imgWidth = imageToresize.Width;
                        int maxHeight = 684;
                        int maxWidth = 482;
                        imgHeight = (imgHeight * maxWidth) / imgWidth;
                        imgWidth = maxWidth;
                        if (imgHeight > maxHeight)
                        {
                            imgWidth = (imgWidth * imgHeight) / imgHeight;
                            imgHeight = maxHeight;
                        }

                        using (Bitmap bitmap = new Bitmap(imageToresize, imgWidth, imgHeight))
                        {
                            bookobject._main_image = "~/ProductImages/Book/Main/" + bookobject._book_id + strExtension;
                            bitmap.Save(Server.MapPath(bookobject._main_image), System.Drawing.Imaging.ImageFormat.Jpeg);
                        }

                        imageToresize = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
                        imgHeight = imageToresize.Height;
                        imgWidth = imageToresize.Width;
                        maxHeight = 143;
                        maxWidth = 115;
                        imgHeight = (imgHeight * maxWidth) / imgWidth;
                        imgWidth = maxWidth;
                        if (imgHeight > maxHeight)
                        {
                            imgWidth = (imgWidth * imgHeight) / imgHeight;
                            imgHeight = maxHeight;
                        }

                        using (Bitmap bitmap = new Bitmap(imageToresize, imgWidth, imgHeight))
                        {
                            bookobject._thumbnail_image = "~/ProductImages/Book/Thumbnail/" + bookobject._book_id + strExtension;
                            bitmap.Save(Server.MapPath(bookobject._thumbnail_image), System.Drawing.Imaging.ImageFormat.Jpeg);
                        }
                    }
                }
            }
            else
            {
                bookobject._thumbnail_image = lblthumbnailimage.Text;
                bookobject._main_image = lblmainimage.Text;
            }
        }

        private void getAddedList()
        {
            table = AdminClass.getRecords("Book");
            gv_book_list.DataSource = table;
            gv_book_list.DataBind();
        }

        /* Method to swet values to book object class to insert and update values */
        /*********************************************************************************************/
        private BookObject getValuesToInsertUpdate()
        {
            bookobject = new BookObject();
            bookobject._book_id = txtsearch.Text;
            bookobject._book_title = inputTitle.Text;
            bookobject._author_name = inputAuthor.Text;
            bookobject._publisher_name = inputPublisher.Text;
            bookobject._isbn_no = inputISBN.Text;
            bookobject._sku = inputSKU.Text;
            bookobject._description = inputDescription.Text;
            bookobject._no_of_pages =Convert.ToInt32(inputNoOfPages.Text);
            bookobject._size = inputSize.Text;
            bookobject._publish_date = inputPublish.Text;
            bookobject._mrp = Convert.ToDecimal(inputMRP.Text);
            if (inputDiscount.Text != "")
            {
                bookobject._discount = Convert.ToInt32(inputDiscount.Text);
            }
            else
            {
                bookobject._discount = 0;
            }
            bookobject._Stock = Convert.ToInt32(inputStock.Text);
            bookobject._cartegory = txtGenre.Text;
            bookobject._type = "Book";
            bookobject._fromDate = inputFromDate.Text;
            bookobject._toDate = inputToDate.Text;
            bookobject._modifyDate = DateTime.Now;

            if (chk_featured_prod.Checked)
                bookobject._featured_product = 'Y';
            else
                bookobject._featured_product = 'N';

            if (chk_new_arrival.Checked)
                bookobject._new_arrival = 'Y';
            else
                bookobject._new_arrival = 'N';

            if (chk_best_seller.Checked)
                bookobject._best_seller = 'Y';
            else
                bookobject._best_seller = 'N';

            if (chk_approve.Checked)
                bookobject._approved = 'Y';
            else
                bookobject._approved = 'N';

            if (chk_sale.Checked)
                bookobject._Sale = 'Y';
            else
                bookobject._Sale = 'N';
            if (chk_pre_order.Checked)
                bookobject._PreOrder = 'Y';
            else
                bookobject._PreOrder = 'N';

            if (FileUpload1.HasFile)
                PhotoUpload();
            else
            {
                bookobject._main_image = lblmainimage.Text;
                bookobject._thumbnail_image = lblthumbnailimage.Text;
            }

            return bookobject;
        }

        private void getBookDetailsById()
        {
            table = AdminProductClass.getProductById(Request.QueryString["Id"], "Book");
            if (table.Rows.Count > 0)
            {
                txtsearch.Text = table.Rows[0][0].ToString();
                inputTitle.Text = table.Rows[0][1].ToString();
                inputAuthor.Text = table.Rows[0][2].ToString();
                inputPublisher.Text = table.Rows[0][3].ToString();
                inputISBN.Text = table.Rows[0][4].ToString();
                inputSKU.Text = table.Rows[0][5].ToString();
                inputStock.Text = table.Rows[0][6].ToString();
                inputNoOfPages.Text = table.Rows[0][7].ToString();
                inputSize.Text = table.Rows[0][8].ToString();
                inputPublish.Text = table.Rows[0][9].ToString();
                txtGenre.Text = table.Rows[0][10].ToString();
                lblmainimage.Text = table.Rows[0][11].ToString();
                lblthumbnailimage.Text = table.Rows[0][12].ToString();
                inputMRP.Text = table.Rows[0][13].ToString();
                inputDiscount.Text = table.Rows[0][14].ToString();
                inputFromDate.Text = table.Rows[0][15].ToString();
                inputToDate.Text = table.Rows[0][16].ToString();
                inputDescription.Text = table.Rows[0][17].ToString();

                if (table.Rows[0][18].ToString() == "Y")
                    chk_new_arrival.Checked = true;
                else
                    chk_new_arrival.Checked = false;

                if (table.Rows[0][19].ToString() == "Y")
                    chk_best_seller.Checked = true;
                else
                    chk_best_seller.Checked = false;

                if (table.Rows[0][20].ToString() == "Y")
                    chk_featured_prod.Checked = true;
                else
                    chk_featured_prod.Checked = false;

                if (table.Rows[0][21].ToString() == "Y")
                    chk_sale.Checked = true;
                else
                    chk_sale.Checked = false;

                if (table.Rows[0][22].ToString() == "Y")
                    chk_approve.Checked = true;
                else
                    chk_approve.Checked = false;
                if (table.Rows[0][23].ToString() == "Y")
                    chk_pre_order.Checked = true;
                else
                    chk_pre_order.Checked = false;

            }
            else
            {
                ClientMessageBox.Show("No Record Found. Please Confirm Book ID", this);
                txtsearch.Text = AutoIncrementCode.get_Bookcode("spAutoIncrementBooksCode");
            }
        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    DataTable dt = new DataTable();
            //    Books book = new Books();
            //    dt = book.getBookDetails(txtsearch.Text);
            //    for (int i = 0; i < dt.Rows.Count; i++)
            //    {
            //        inputTitle.Text = dt.Rows[0][1].ToString();
            //        inputAuthor.Text = dt.Rows[0][2].ToString();
            //        inputPublisher.Text = dt.Rows[0][3].ToString();
            //        inputISBN.Text = dt.Rows[0][4].ToString();
            //        inputNoOfPages.Text = dt.Rows[0][5].ToString();
            //        inputSize.Text = dt.Rows[0][6].ToString();
            //        inputPublish.Text = dt.Rows[0][7].ToString();
            //        inputMRP.Text = dt.Rows[0][8].ToString();
            //        lblthumbnailimage.Text = dt.Rows[0][9].ToString();
            //        inputSKU.Text = dt.Rows[0][10].ToString();
            //        inputDescription.Text = dt.Rows[0][11].ToString();
            //        inputDiscount.Text = dt.Rows[0][13].ToString();
            //        lblmainimage.Text = dt.Rows[0][14].ToString();
            //        inputGenre.Text = dt.Rows[0][15].ToString();
            //        inputlanguage.Text = dt.Rows[0][16].ToString();

            //    }

            //}
            //catch (Exception)
            //{
                
            //    throw;
            //}
        }
    }
}