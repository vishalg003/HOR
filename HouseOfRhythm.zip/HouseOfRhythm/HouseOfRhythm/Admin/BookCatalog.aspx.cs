﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class BookCatalog : System.Web.UI.Page
    {
        DataSet table;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getBookCatalog(gv_bookCatalog.PageIndex, gv_bookCatalog.PageSize);
            }
        }

        protected void gv_book_catlog_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "UpdateRecord")
            {
                int rowIndex = int.Parse(e.CommandArgument.ToString());
                Response.Redirect("AddBooks.aspx?bookId=" + (gv_bookCatalog.Rows[rowIndex].Cells[0]).Text);
            }
        }

        /* Method to bind data to Gridview with Manual Paging */
        /*******************************************************************************************/
        private void getBookCatalog(int pageIndex, int pageSize)
        {
            table = AdminClass.getProductCatalog(pageIndex, pageSize, "Book");
            int totalPages = (int)(table.Tables[1].Rows[0][0]) / pageSize;
            if (((int)(table.Tables[1].Rows[0][0]) % pageSize) != 0)
            {
                totalPages += 1;
            }

            List<ListItem> pages = new List<ListItem>();
            if (totalPages > 1)
            {
                for (int i = 1; i <= totalPages; i++)
                {
                    pages.Add(new ListItem(i.ToString(), i.ToString(), i != (pageIndex + 1)));
                }
            }
            gv_bookCatalog.DataSource = table.Tables[0];
            gv_bookCatalog.DataBind();
            repeaterPaging.DataSource = pages;
            repeaterPaging.DataBind();

            if (table.Tables[0].Rows.Count < pageSize)
            {
                btn_paging_next.Enabled = false;
            }
            else
            {
                btn_paging_next.Enabled = true;
            }
        }

        /* Method to bind data to Gridview and Page number to button with Manual Paging */
        /*******************************************************************************************/
        protected void linkButton_Click(object sender, EventArgs e)
        {
            int pageIndex = int.Parse((sender as LinkButton).CommandArgument);
            pageIndex -= 1;
            prevNextButtonClick(pageIndex);
        }

        /* Method to bind data to Gridview with PREVIOUS button click */
        /*******************************************************************************************/
        protected void btn_paging_prev_Click(object sender, EventArgs e)
        {
            int pageIndex = Convert.ToInt32(ViewState["pageNo"]) - 1;
            prevNextButtonClick(pageIndex);
        }

        /* Method to bind data to Gridview with NEXT button click */
        /*******************************************************************************************/
        protected void btn_paging_next_Click(object sender, EventArgs e)
        {
            int pageIndex = Convert.ToInt32(ViewState["pageNo"]) + 1;
            prevNextButtonClick(pageIndex);
        }

        private void prevNextButtonClick(int pageIndex)
        {
            ViewState["pageNo"] = pageIndex.ToString();
            gv_bookCatalog.PageIndex = pageIndex;
            if (gv_bookCatalog.PageIndex == 0)
            {
                btn_paging_prev.Enabled = false;
            }
            else
            {
                btn_paging_prev.Enabled = true;
            }
            getBookCatalog(pageIndex, gv_bookCatalog.PageSize);
        }
    }
}