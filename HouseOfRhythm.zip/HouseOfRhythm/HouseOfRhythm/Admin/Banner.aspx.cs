﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Drawing;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class Banner : System.Web.UI.Page
    {
        InsertBannerDetails insertBannerDetails;
        int rows_affected;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                getBannerDetails();
            }
        }

        //Method To Insert Main Banner Details
        /* **********************************************************************************************/
        protected void btn_add_mainBanner_Click(object sender, EventArgs e)
        {
            insertBannerDetails = new InsertBannerDetails();
            insertBannerDetails._Title = txt_banner_title.Text;
            insertBannerDetails._shortDescription = txt_descp.Text;
            insertBannerDetails._imagePath = "../BannerImages/MainBanner/" + getImagePath(1400,400,"../BannerImages/MainBanner/", fp_banner_image);
            insertBannerDetails.product_id = txtproductid.Text;
            insertBannerDetails.product_type = ddltype.SelectedItem.Text;
            rows_affected = insertBannerDetails.addMainBannerDetails(insertBannerDetails);
            if (rows_affected >= 1)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b> Main Banner/ Slider Images</b>  Has Been <b> Added Successfully </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                clearMainBannerTextbox();
            }
        }


        //Method To Insert Small Banner Details
        /* **********************************************************************************************/
        //protected void btn_add_smallBanner_Click(object sender, EventArgs e)
        //{
        //    insertBannerDetails = new InsertBannerDetails();
        //    insertBannerDetails._Title = txt_sb_title.Text;
        //    insertBannerDetails._shortDescription = txt_sb_descp.Text;
        //    insertBannerDetails._imagePath = "../BannerImages/SmallBanner/" + getImagePath(396, 297, "../BannerImages/SmallBanner/", FileUpload1);

        //    rows_affected = insertBannerDetails.addSmallBannerDetails(insertBannerDetails);
        //    if (rows_affected >= 1)
        //    {
        //        lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b> Samll Banner</b>  Has Been <b> Added Successfully </b>";
        //        Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
        //    }
        //}

        //Method To Insert Small Banner Details
        /* **********************************************************************************************/
        protected void btn_single_banner_Click(object sender, EventArgs e)
        {
            insertBannerDetails = new InsertBannerDetails();
            insertBannerDetails._Title = txt_single_title.Text;
            insertBannerDetails._shortDescription = txt_single_descp.Text;
            insertBannerDetails._Page = ddl_page_list.SelectedValue;
            insertBannerDetails._imagePath = "../BannerImages/SmallBanner/" + getImagePath(1300, 320, "../BannerImages/SmallBanner/", FileUpload2);

            rows_affected = insertBannerDetails.addSingleBannerDetails(insertBannerDetails);
            if (rows_affected >= 1)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b> Single Banner</b>  Has Been <b> Added Successfully </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                clearSingleBannerTextboxes();
            }
        }

        //Method To Clear Main Banner TextBoxes
        public void clearMainBannerTextbox()
        {
            try
            {
                txt_banner_title.Text = "";
                txt_descp.Text = "";
                txtproductid.Text = "";
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        //Method to Clear Single Banner Textboxes
        public void clearSingleBannerTextboxes()
        {
            try
            {
                txt_single_descp.Text = "";
                txt_single_title.Text = "";
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        //Method To Fetch Banner details
        /* **********************************************************************************************/

        private void getBannerDetails()
        {
            //DataTable dt = new DataTable();
            //insertBannerDetails = new InsertBannerDetails();
            //dt = insertBannerDetails.getBannerDetails();
            //gridview_banner.DataSource = dt;
            //gridview_banner.DataBind();
        }


        //Method Resize Image and Save to folder
        /* **********************************************************************************************/
        private string getImagePath(int width, int height, string path, FileUpload fileUp)
        {
            string imageName = "";
            FileUpload fp = fileUp;
            if (fileUp.HasFile)
            {
                if (fileUp.PostedFile != null && fileUp.PostedFile.FileName != "")
                {
                    string strExtension = System.IO.Path.GetExtension(fileUp.FileName);
                    if ((strExtension.ToUpper() == ".JPG") || (strExtension.ToUpper() == ".JPEG") || (strExtension.ToUpper() == ".GIF") || (strExtension.ToUpper() == ".PNG"))
                    {                     
                        // Resize Image Before Uploading to Photo Folder
                        System.Drawing.Image imageToresize = System.Drawing.Image.FromStream(fileUp.PostedFile.InputStream);
                        int imgHeight = imageToresize.Height;
                        int imgWidth = imageToresize.Width;
                        int maxHeight = height;
                        int maxWidth = width;
                        imgHeight = (imgHeight * maxWidth) / imgWidth;
                        imgWidth = maxWidth;
                        if (imgHeight > maxHeight)
                        {
                            imgWidth = (imgWidth * imgHeight) / imgHeight;
                            imgHeight = maxHeight;
                        }

                        using (Bitmap bitmap = new Bitmap(imageToresize, imgWidth, imgHeight))
                        {
                            imageName = fileUp.FileName;
                            bitmap.Save(Server.MapPath(path + imageName), System.Drawing.Imaging.ImageFormat.Jpeg);
                        }
                    }
                }
            }
            return imageName;
        }

        protected void btn_search_Click(object sender, EventArgs e)
        {
            insertBannerDetails = new InsertBannerDetails();
            dt = insertBannerDetails.SearchMainBannerDetails(txt_banner_title.Text);
            if (dt.Rows.Count > 0)
            {
                txt_banner_title.Text = dt.Rows[0][0].ToString();
                lblimage.Text = dt.Rows[0][1].ToString();
                txt_descp.Text = dt.Rows[0][2].ToString();
                txtproductid.Text = dt.Rows[0][3].ToString();
                ddltype.Text = dt.Rows[0][4].ToString();
            }
            else
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b> Rocord Not Found</b> ";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
            }
        }

        protected void btn_update_Click(object sender, EventArgs e)
        {
            insertBannerDetails = new InsertBannerDetails();
            insertBannerDetails._Title = txt_banner_title.Text;
            insertBannerDetails._shortDescription = txt_descp.Text;
            insertBannerDetails.product_id = txtproductid.Text;
            insertBannerDetails.product_type = ddltype.SelectedItem.Text;
            if (fp_banner_image.HasFile)
            {
                insertBannerDetails._imagePath = "../BannerImages/MainBanner/" + getImagePath(1400, 400, "../BannerImages/MainBanner/", fp_banner_image);
            }
            else {
                insertBannerDetails._imagePath = lblimage.Text;
            }
            int i = insertBannerDetails.updateMainBannerDetails(insertBannerDetails);
            if (i >= 1)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b> Main Banner</b>  Has Been <b> Update Successfully </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                clearMainBannerTextbox();
            }
        }

        protected void btn_delete_Click(object sender, EventArgs e)
        {
            insertBannerDetails = new InsertBannerDetails();
            insertBannerDetails._Title = txt_banner_title.Text;
            int i = insertBannerDetails.DeleteMainBannerDetails(insertBannerDetails);
            if (i >= 1)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b> Main Banner</b>  Has Been <b> Delete Successfully </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
            }
        }

        protected void btn_smallsearch_Click(object sender, EventArgs e)
        {
            insertBannerDetails = new InsertBannerDetails();
            dt = insertBannerDetails.SearchSingleBannerDetails(txt_single_title.Text);
            if (dt.Rows.Count > 0)
            {
                txt_single_title.Text = dt.Rows[0][0].ToString();
                txt_single_descp.Text = dt.Rows[0][2].ToString();
                ddl_page_list.Text = dt.Rows[0][3].ToString();
                lbl_image_path.Text = dt.Rows[0][1].ToString();
            }
            else
            {
                    lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b> Record Not Found</b>";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
            }
        }

        protected void btn_update_single_Click(object sender, EventArgs e)
        {
            insertBannerDetails = new InsertBannerDetails();
            insertBannerDetails._Title = txt_single_title.Text;
            insertBannerDetails._shortDescription = txt_single_descp.Text;
            insertBannerDetails._Page = ddl_page_list.Text;
            if (FileUpload2.HasFile)
            {
                insertBannerDetails._imagePath = "../BannerImages/SmallBanner/" + getImagePath(1300, 320, "../BannerImages/SmallBanner/", FileUpload2);
            }
            else
            {
                insertBannerDetails._imagePath = lbl_image_path.Text;    
            }
            int i = insertBannerDetails.updatesingleBannerDetails(insertBannerDetails);
            if (rows_affected >= 1)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b> Single Banner</b>  Has Been <b> Update Successfully </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                clearSingleBannerTextboxes();
            }
        }

        protected void btn_delete_single_Click(object sender, EventArgs e)
        {
            insertBannerDetails = new InsertBannerDetails();
            insertBannerDetails._Title = txt_single_title.Text;
            int i = insertBannerDetails.DeleteSingleBannerDetails(insertBannerDetails);
            if (rows_affected >= 1)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b> Single Banner</b>  Has Been <b> Deleted Successfully </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
            }
        }
    }
}