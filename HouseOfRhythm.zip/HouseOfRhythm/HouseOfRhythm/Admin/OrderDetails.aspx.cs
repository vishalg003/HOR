﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayerHor;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Text;
using System.IO;
using System.Net.Mail;

namespace HouseOfRhythm.Admin
{
    public partial class OrderDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["OrderId"] != null)
                {
                    getOrderDetails();
                }
            }
        }

        private void getOrderDetails()
        {
            DataSet ds = AdminProductClass.getOrderDetails(Request.QueryString["OrderId"].ToString());
            gv_customer_order_list.DataSource = ds.Tables[0];
            gv_customer_order_list.DataBind();
            lblOrderId.Text = "Order # " + Request.QueryString["OrderId"].ToString();
            lbl_order_Id.Text = Request.QueryString["OrderId"].ToString();
            lbl_customer_name.Text = ds.Tables[1].Rows[0][0].ToString() + " " + ds.Tables[1].Rows[0][1].ToString();
            txt_fname.Text = ds.Tables[1].Rows[0][0].ToString();
            txt_lname.Text = ds.Tables[1].Rows[0][1].ToString();
            lbl_customer_email.Text = ds.Tables[1].Rows[0][2].ToString();
            lbl_customer_no.Text = ds.Tables[1].Rows[0][3].ToString();

            lbl_billing_address.Text = ds.Tables[1].Rows[0][6].ToString() + ", " + ds.Tables[1].Rows[0][12].ToString() + ", " +
                                        ds.Tables[1].Rows[0][11].ToString() + ", " + ds.Tables[1].Rows[0][10].ToString() + ", " +
                                        ds.Tables[1].Rows[0][14].ToString() + ", " + ds.Tables[1].Rows[0][13].ToString();

            lbl_shipping_address.Text = ds.Tables[1].Rows[0][5].ToString() + ", " + ds.Tables[1].Rows[0][17].ToString() + ", " +
                                        ds.Tables[1].Rows[0][16].ToString() + ", " + ds.Tables[1].Rows[0][15].ToString() + ", " +
                                        ds.Tables[1].Rows[0][14].ToString() + ", " + ds.Tables[1].Rows[0][18].ToString();

            txtStatus.Text = lbl_order_status.Text = ds.Tables[0].Rows[0][0].ToString();
            lblOrderDate.Text = lbl_order_date.Text = ds.Tables[1].Rows[0][4].ToString();
            //lbl_subtotal.Text = ds.Tables[1].Rows[0][7].ToString();
            (gv_customer_order_list.FooterRow.FindControl("lbl_subtotal") as Label).Text = ds.Tables[1].Rows[0][7].ToString();
            //lbl_grand_total.Text = ds.Tables[1].Rows[0][8].ToString();
            (gv_customer_order_list.FooterRow.FindControl("lbl_grand_total") as Label).Text = ds.Tables[1].Rows[0][8].ToString();
            lbl_payment_type.Text = ds.Tables[0].Rows[0][5].ToString();
            lbl_deliver_charge.Text = "Flat Rate Of : <b>" + ds.Tables[0].Rows[0][6].ToString() + "</b>";
            //lbl_shipping_cost.Text = ds.Tables[0].Rows[0][6].ToString();
            (gv_customer_order_list.FooterRow.FindControl("lbl_shipping_cost") as Label).Text = ds.Tables[0].Rows[0][6].ToString();

            if (ds.Tables[4] != null)
            {
                if (ds.Tables[4].Rows.Count > 0)
                {
                    (gv_customer_order_list.FooterRow.FindControl("Label4") as Label).Visible = true;
                    (gv_customer_order_list.FooterRow.FindControl("lbl_refund") as Label).Text = ds.Tables[4].Rows[0][0].ToString();
                    (gv_customer_order_list.FooterRow.FindControl("lbl_refund") as Label).Visible = true;
                }
            }

            if (lbl_order_status.Text.Equals("Cancelled"))
            {
                btn_cancel.Visible = btn_hold.Visible = btn_invoice.Visible = btn_ship.Visible = false;
                btn_Reorder.Visible = true;
            }
            if (lbl_order_status.Text.Equals("Hold"))
            {
                btn_cancel.Visible = btn_hold.Visible = btn_invoice.Visible = btn_ship.Visible = false;
                btn_unHold.Visible = true;
            }
            if (lbl_order_status.Text.Equals("Pending"))
            {
                btn_cancel.Visible = btn_hold.Visible = btn_invoice.Visible = btn_send_email.Visible = true;
                btn_unHold.Visible = btn_ship.Visible = false;
            }
            if (ds.Tables[2].Rows.Count > 0)
            {
                dl_comments.DataSource = ds.Tables[2];
                dl_comments.DataBind();
            }
            if (lbl_order_status.Text.Equals("Invoiced"))
            {
                btn_invoice.Visible = false;
                btn_ship.Visible = btn_print_invoice.Visible = true;
            }
            if (lbl_order_status.Text.Equals("Delivered"))
            {
                btn_delivered.Visible = btn_invoice.Visible = btn_ship.Visible = btn_hold.Visible = false;
                btn_credit_memo.Visible = btn_print_invoice.Visible = true;
            }

            if (lbl_order_status.Text.Equals("Shipped"))
            {
                btn_cancel.Visible = btn_hold.Visible = btn_invoice.Visible = btn_ship.Visible = false;
               btn_Reorder.Visible = btn_delivered.Visible = btn_print_invoice.Visible = true;
            }
            if (lbl_order_status.Text.Equals("Unhold"))
            {
                btn_cancel.Visible = btn_hold.Visible = btn_invoice.Visible = btn_ship.Visible = true;
                btn_unHold.Visible = false;
            }
            if (lbl_order_status.Text.Equals("Credit Memo"))
            {
                btn_invoice.Visible = btn_hold.Visible= btn_cancel.Visible = false;
                btn_Reorder.Visible = true;
            }
        }


        protected void btn_ship_bill_addr_Click(object sender, EventArgs e)
        {
            getCustomerAddress(lbl_order_Id.Text, "");
            ViewState["type"] = "Ship";
        }

        protected void btn_edit_bill_addr_Click(object sender, EventArgs e)
        {
            getCustomerAddress("", lbl_customer_email.Text);
            ViewState["type"] = "Bill";
        }

        protected void btn_close_edit_Click(object sender, EventArgs e)
        {
            address_edit_sec.Visible = false;
        }

        protected void btn_saveAddress_Click(object sender, EventArgs e)
        {
            int i = 0;
            if (ViewState["type"].Equals("Ship"))
                i = AdminProductClass.updateCustomerAddressForOrder(lbl_order_Id.Text, ViewState["type"].ToString(), txt_address.Text, txt_country.Text, txt_state.Text, txt_city.Text, txt_locality.Text, txt_zipcode.Text, txt_phone_no.Text);
            else
                i = AdminProductClass.updateCustomerAddressForOrder(lbl_customer_email.Text, ViewState["type"].ToString(), txt_address.Text, txt_country.Text, txt_state.Text, txt_city.Text, txt_locality.Text, txt_zipcode.Text, txt_phone_no.Text);

            getOrderDetails();
        }

        private void getCustomerAddress(string order_id, string email)
        {
            DataTable table = AdminProductClass.getCustomerAddress(order_id, email);
            if (table.Rows.Count > 0)
            {
                txt_address.Text = table.Rows[0][0].ToString();
                txt_country.Text = table.Rows[0][1].ToString();
                txt_state.Text = table.Rows[0][2].ToString();
                txt_city.Text = table.Rows[0][3].ToString();
                txt_locality.Text = table.Rows[0][4].ToString();
                txt_zipcode.Text = table.Rows[0][5].ToString();
                txt_phone_no.Text = table.Rows[0][6].ToString();
                address_edit_sec.Visible = true;
            }
        }

        protected void btn_Invoice_Click(object sender, EventArgs e)
        {
            int i = 0;
            string id = AutoIncrementCode.get_invoice_Id();
            if (chk_box_send_mail.Checked != true)
            {
                if (txtComment.Text == "")
                    i = AdminProductClass.insertProcessingDetails(lbl_order_Id.Text, "Invoiced", "Invoiced", "Customer Not Notified", "Invoice Generated", id, "spAdminInsertInvoiceDetailsAndInsertComment");
                else
                    i = AdminProductClass.insertProcessingDetails(lbl_order_Id.Text, "Invoiced", "Invoiced", "Customer Not Notified", txtComment.Text, id, "spAdminInsertInvoiceDetailsAndInsertComment");
            }
            else
            {
                if (txtComment.Text == "")
                {
                    i = AdminProductClass.insertProcessingDetails(lbl_order_Id.Text, "Invoiced", "Invoiced", "Customer Not Notified", "Invoice Generated", id, "spAdminInsertInvoiceDetailsAndInsertComment");
                    sendEmailToCustomer("Invoice Notification", "Thank you for your recent order from our House Of Rhythm. We are pleased to inform you that your package for order " + lbl_order_Id.Text +
                            " has been shipped on Date: " + DateTime.Now.ToString("dd/mm/yyyy") + ".\n We look forward to conducting future business with you.");
                }
                else
                {
                    i = AdminProductClass.insertProcessingDetails(lbl_order_Id.Text, "Invoiced", "Invoiced", "Customer Not Notified", txtComment.Text, id, "spAdminInsertInvoiceDetailsAndInsertComment");
                    sendEmailToCustomer("Shipment Notification", txtComment.Text);
                }
            }
            if (i > 0)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b>" + lblOrderId.Text + " Invoice has been generated </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                getOrderDetails();
            }

        }

        protected void btn_print_invoice_Click(object sender, EventArgs e)
        {
            Response.Redirect("Invoice.aspx?orderId=" + lbl_order_Id.Text);
        }

        protected void btn_Shipping_Click(object sender, EventArgs e)
        {
            int i = 0;
            if (chk_box_send_mail.Checked == false)
            {
                if (txtComment.Text == "")
                    i = AdminProductClass.changeOrderStatus(lbl_order_Id.Text, "Shipped", "Customer Not Notified", "Shipment Generated");
                else
                    i = AdminProductClass.changeOrderStatus(lbl_order_Id.Text, "Shipped", "Customer Not Notified", txtComment.Text);
            }
            else
            {
                if (txtComment.Text == "")
                {
                    i = AdminProductClass.changeOrderStatus(lbl_order_Id.Text, "Shipped", "Customer Notified", "Shipment Generated");
                    sendEmailToCustomer("Shipment Notification", "Thank you for your recent order from our House Of Rhythm. We are pleased to inform you that your package for order " + lbl_order_Id.Text +
                            " has been shipped on Date: " + DateTime.Now.ToString("dd/mm/yyyy") + ".\n We look forward to conducting future business with you.");
                }
                else
                {
                    i = AdminProductClass.changeOrderStatus(lbl_order_Id.Text, "Shipped", "Customer Notified", txtComment.Text);
                    sendEmailToCustomer("Shipment Notification", txtComment.Text);
                }
            }

            if (i > 0)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b>" + lblOrderId.Text + "</b> Has Been Added to <b> Shipping </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
            }
            chk_box_send_mail.Checked = false;
            txtComment.Text = "";
            getOrderDetails();
        }

        protected void btn_credit_memo_Click(object sender, EventArgs e)
        {
            txt_refund.ReadOnly = false;
            txt_payment_mode.ReadOnly = false;
            txt_refund_date.ReadOnly = false;
            txt_refund_date.CssClass = "input-Resease form-control";
            btn_refund.Enabled = true;
        }

        protected void btn_refund_Click(object sender, EventArgs e)
        {
            if (txt_refund.Text == "")
                lbl_refund_amt.Text = "Enter Refund Amount";
            else if (txt_payment_mode.Text == "")
                lbl_payment_mode.Text = "Enter Payment mode";
            else
            {
                string[] value = new string[]
                {
                    txt_refund.Text, txt_payment_mode.Text, txt_refund_date.Text, 
                    lbl_order_Id.Text, "Credit Memo", "Customer Not Notified"
                };
                int i = 0;
                if (chk_box_send_mail.Checked == false)
                {
                    if (txtComment.Text == "")
                        i = AdminClass.setRefundStatus(value, "Amount Refunded");
                    else
                        i = AdminClass.setRefundStatus(value,  txtComment.Text);
                }
                else
                {
                    if (txtComment.Text == "")
                    {
                        i = AdminClass.setRefundStatus(value, "Amount Refunded");
                        sendEmailToCustomer("Order Cancellation Notification", "This e-mail serves as confirmation of the successful cancellation of your" +
                              "order: " + lbl_order_Id.Text + "placed on " + lbl_order_date.Text + ".\n\nShould you have any questions, please do not hesitate" +
                              "to contact us.");
                    }
                    else
                    {
                        i = AdminClass.setRefundStatus(value, txtComment.Text);
                        sendEmailToCustomer("Order Cancellation Notification", txtComment.Text);
                    }
                }

                if (i > 0)
                {
                    lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b>" + lblOrderId.Text + "</b> Credit Memo generated";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                }
                chk_box_send_mail.Checked = false;
                txtComment.Text = "";
            }
            getOrderDetails();
        }

        protected void btn_delivered_Click(object sender, EventArgs e)
        {
            int i = 0;
            if (txtComment.Text == "")
                i = AdminProductClass.changeOrderStatus(lbl_order_Id.Text, "Delivered", "Notification Not Applicable", "Order Process Complete and Delivered");
            else
                i = AdminProductClass.changeOrderStatus(lbl_order_Id.Text, "Delivered", "Notification Not Applicable", txtComment.Text);
                if (i > 0)
                {
                    lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b>" + lblOrderId.Text + "</b> Has been <b> Delivered </b>";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                    getOrderDetails();
                }
        }

        protected void btn_Reorder_Click(object sender, EventArgs e)
        {
            int i = AdminProductClass.changeOrderStatus(lbl_order_Id.Text, "Pending", "Notification Not Applicable", txtComment.Text);
            if (i > 0)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b>" + lblOrderId.Text + "</b> Has Been <b> Reordered </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                btn_cancel.Visible = btn_hold.Visible = btn_invoice.Visible = btn_ship.Visible = true;
                btn_Reorder.Visible = false;
                getOrderDetails();
            }
        }

        protected void btn_hold_Click(object sender, EventArgs e)
        {
            int i = AdminProductClass.changeOrderStatus(lbl_order_Id.Text, "Hold", "Notification Not Applicable", txtComment.Text);
            if (i > 0)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b>" + lblOrderId.Text + "</b> Has Been Put on <b> Hold </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                btn_cancel.Visible = btn_hold.Visible = btn_invoice.Visible = btn_ship.Visible = false;
                getOrderDetails();
            }
        }

        protected void btn_Unhold_Click(object sender, EventArgs e)
        {
            int i = AdminProductClass.changeOrderStatus(lbl_order_Id.Text, "Unhold", "Notification Not Applicable", txtComment.Text);
            if (i > 0)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b>" + lblOrderId.Text + "</b> Has Been Put on <b> Hold </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                btn_cancel.Visible = btn_hold.Visible = btn_invoice.Visible = btn_ship.Visible = false;
                getOrderDetails();
            }
        }

        protected void btn_cancel_Click(object sender, EventArgs e)
        {
            int i = AdminProductClass.changeOrderStatus(lbl_order_Id.Text, "Cancelled", "Notification Not Applicable", txtComment.Text);
            if (i > 0)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-trash-o \"></i> <b>" + lblOrderId.Text + "</b>  Has Been <b> Cancled </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                btn_cancel.Visible = btn_hold.Visible = btn_invoice.Visible = btn_ship.Visible = false;
                getOrderDetails();
            }
        }

        protected void btn_submit_comment_Click(object sender, EventArgs e)
        {
            int i = AdminProductClass.changeOrderStatus(lbl_order_Id.Text, lbl_order_status.Text, "Notification Not Applicable", txtComment.Text);
            if (i > 0)
            {
                getOrderDetails();
            }
        }

        private void sendEmailToCustomer(string subject, string body)
        {
            MailMessage mailMessage = new MailMessage("nitikeshkedari@gmail.com", "nitikeshkedari@gmail.com");
            mailMessage.Subject = subject;
            mailMessage.Body = "Dear " + lbl_customer_name.Text + "\n\n\n" + body +
                               " \n\n\nKind Regards,\nHouse Of Rhythm.";
            SmtpClient smtpClient = new SmtpClient();
            try
            {
                smtpClient.Send(mailMessage);
            }
            catch (Exception)
            {
            }
        }
    }
}