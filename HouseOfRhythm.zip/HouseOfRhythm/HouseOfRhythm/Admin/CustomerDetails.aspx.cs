﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class CustomerDetails : System.Web.UI.Page
    {
        static DataSet table;
        static string type = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getCustomerDetails();
            }
        }

        /* Mehtod to get CUSTOMER Information */
        /***********************************************************************************/
        private void getCustomerDetails()
        {
            if (Request.QueryString["email"] != null)
            {
                table = AdminClass.getUserDetails(Request.QueryString["email"].ToString());
                if (table.Tables[0].Rows.Count > 0)
                {
                    lbl_name.Text = table.Tables[0].Rows[0][0].ToString() + " " + table.Tables[0].Rows[0][1].ToString();
                    lbl_email.Text = table.Tables[0].Rows[0][2].ToString();
                    lbl_mobile.Text = table.Tables[0].Rows[0][5].ToString();
                    lbl_rgstr_date.Text = table.Tables[0].Rows[0][7].ToString(); ;
                    lbl_last_login.Text = table.Tables[0].Rows[0][8].ToString();
                    lbl_email_status.Text = "Verified";
                    lbl_bill_address.Text = table.Tables[0].Rows[0][4].ToString() + ", " + table.Tables[0].Rows[0][13].ToString() + ", " +
                                            table.Tables[0].Rows[0][12].ToString() + ", " + table.Tables[0].Rows[0][11].ToString() + ", " +
                                            table.Tables[0].Rows[0][10].ToString() + ", " + table.Tables[0].Rows[0][14].ToString();

                    txt_bill_house.Text = table.Tables[0].Rows[0][4].ToString();
                    txt_bill_locality.Text = table.Tables[0].Rows[0][12].ToString();
                    txt_bill_city.Text = table.Tables[0].Rows[0][12].ToString();
                    txt_bill_state.Text = table.Tables[0].Rows[0][11].ToString();
                    txt_bill_country.Text = table.Tables[0].Rows[0][10].ToString();
                    txt_bill_zipcode.Text = table.Tables[0].Rows[0][14].ToString();

                    txt_Fname.Text = table.Tables[0].Rows[0][0].ToString();
                    txt_Lname.Text = table.Tables[0].Rows[0][1].ToString();
                    txt_email.Text = table.Tables[0].Rows[0][2].ToString();
                    txt_mobile.Text = table.Tables[0].Rows[0][5].ToString();
                    txt_alt_no.Text = table.Tables[0].Rows[0][6].ToString();
                }

                if (table.Tables[1].Rows.Count > 0)
                {
                    lbl_ship_address.Text = table.Tables[1].Rows[0][0].ToString() + ", " + table.Tables[1].Rows[0][1].ToString() + ", " +
                                             table.Tables[1].Rows[0][3].ToString() + ", " + table.Tables[1].Rows[0][4].ToString() + ", " +
                                             table.Tables[1].Rows[0][5].ToString() + ", " + table.Tables[1].Rows[0][2].ToString();

                    txt_ship_house.Text = table.Tables[1].Rows[0][0].ToString();
                    txt_ship_locality.Text = table.Tables[1].Rows[0][1].ToString();
                    txt_ship_city.Text = table.Tables[1].Rows[0][3].ToString();
                    txt_ship_state.Text = table.Tables[1].Rows[0][4].ToString();
                    txt_ship_country.Text = table.Tables[1].Rows[0][5].ToString();
                    txt_ship_pincode.Text = table.Tables[1].Rows[0][2].ToString();
                }
                if (table.Tables[2].Rows.Count > 0)
                {
                    gv_orders_list.DataSource = table.Tables[2];
                    gv_orders_list.DataBind();
                }
                else
                {
                    lbl_order_msg.Text = "No Records Found";
                    lbl_order_msg.Visible = true;
                }
                if (table.Tables[3].Rows.Count > 0)
                {
                    gv_cart_list.DataSource = table.Tables[3];
                    gv_cart_list.DataBind();
                    lbl_cart_count.Text = "(" + table.Tables[3].Rows.Count + ")";
                }
                else
                {
                    lbl_cart_msg.Text = "No Records Found";
                    lbl_cart_msg.Visible = true;
                }
                if (table.Tables[4].Rows.Count > 0)
                {
                    gv_wish_list.DataSource = table.Tables[4];
                    gv_wish_list.DataBind();
                    lbl_wishlist_count.Text = "(" + table.Tables[4].Rows.Count + ")";
                }
                else
                {
                    lbl_wishlist_msg.Text = "No Records Found";
                    lbl_wishlist_msg.Visible = true;
                }
            }
        }


        protected void btn_update_BillAddress(object sender, EventArgs e)
        {
            int i = AdminProductClass.updateCustomerAddress(Request.QueryString["email"].ToString(), "Bill", txt_bill_house.Text, txt_bill_country.Text, txt_bill_state.Text, txt_bill_city.Text, txt_bill_locality.Text, txt_bill_zipcode.Text);
            if (i > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                getCustomerDetails();
            }
        }

        protected void btn_update_ShipAddress(object sender, EventArgs e)
        {
            int i = AdminProductClass.updateCustomerAddress(Request.QueryString["email"], "Ship", txt_ship_house.Text, txt_ship_country.Text, txt_ship_state.Text, txt_ship_city.Text, txt_ship_locality.Text, txt_ship_pincode.Text);
            if (i > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                getCustomerDetails();
            }
        }

        protected void btn_update_CustomerInfo(object sender, EventArgs e)
        {
            int i = AdminProductClass.updateCustomerInfo( txt_Fname.Text, txt_Lname.Text, txt_email.Text, txt_mobile.Text, txt_alt_no.Text);
            if (i > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                getCustomerDetails();
            }
        }
    }
}