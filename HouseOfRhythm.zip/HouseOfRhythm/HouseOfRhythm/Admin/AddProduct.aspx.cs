﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessObject;
using BusinessLayerHor;
using System.IO;
using System.Drawing;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class AddProduct : System.Web.UI.Page
    {
        ProductObject productObject;
        DataTable table;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["Id"] != null)
            {
                btn_update.Enabled = true;
                getProductDetailsById();
            }
            else
            {
                inputProductId.Text = AutoIncrementCode.get_Productcode("spAutoIncrementProductCode");
            }
            getAddedList();
        }

        private void getAddedList()
        {
            table = AdminClass.getRecords("Movie");
            gv_product_list.DataSource = table;
            gv_product_list.DataBind();
        }

        protected void btn_save_Click(object sender, EventArgs e)
        {
            Product product = new Product();
            productObject = setValuesToInsertUpdate();
            int i = product.addDetails(productObject);
            if (i > 0)
            {
                ClientMessageBox.Show("Record Inserted successfully", this);
            }
            inputProductId.Text = AutoIncrementCode.get_Productcode("spAutoIncrementProductCode");
            getAddedList();
        }

        protected void GenerateBarcode(object sender, EventArgs e)
        {
            Random random = new Random();
            inputBarcodeNo.Text = (Convert.ToString(random.Next(10000000, 80000000)));
        }

        protected void btn_update_Click(object sender, EventArgs e)
        {
            Product product = new Product();
            productObject = setValuesToInsertUpdate();
            int i = product.updateDetails(productObject);
            if (i > 0)
            {
                ClientMessageBox.Show("Record Updated successfully", this);
                clearTextbox();
            }
            //inputProductId.Text = AutoIncrementCode.get_Productcode("spAutoIncrementProductCode");
            getAddedList();
        }

        /* Method to blank all textboxes */
        private void clearTextbox()
        {
            inputBarcodeNo.Text = "";
            inputDescription.Text = "";
            inputDiscount.Text = "";
            inputLongDescp.Text = "";
            inputMRP.Text = "";
            inputProductId.Text = "";
            inputStock.Text = "";
            inputTitle.Text = "";
            inputWeight.Text = "";
            txt_discount_frm_date.Text = "";
            txt_discount_to_date.Text = "";
            txtGenre.Text = "";
        }

        /* Method to assign values to Product class variables */
        /*****************************************************************************************/
        private ProductObject setValuesToInsertUpdate()
        {
            productObject = new ProductObject();
            productObject._Id = inputProductId.Text;
            productObject._Title = inputTitle.Text;
            productObject._shortDescp = inputDescription.Text;
            productObject._longDescp = inputLongDescp.Text;
            productObject._stock = Convert.ToInt32(inputStock.Text);
            productObject._Mrp = Convert.ToDecimal(inputMRP.Text);
            productObject._Discount = Convert.ToInt32(inputDiscount.Text);
            productObject._Weight = Convert.ToDecimal(inputWeight.Text);
            productObject._Category = txtGenre.Text;
            productObject._barcode = inputBarcodeNo.Text;
            productObject._modifiedDate = DateTime.Now;

            if (chk_featured_prod.Checked)
                productObject._featuredProduct = 'Y';
            else
                productObject._featuredProduct = 'N';

            if (chk_new_arrival.Checked)
                productObject._newArrival = 'Y';
            else
                productObject._newArrival = 'N';

            if (chk_best_seller.Checked)
                productObject._bestSeller = 'Y';
            else
                productObject._bestSeller = 'N';

            if (chk_approve.Checked)
                productObject._Approve = 'Y';
            else
                productObject._Approve = 'N';

            if (chk_sale.Checked)
                productObject._Sale = 'Y';
            else
                productObject._Sale = 'N';
 
            productObject._fromDate = txt_discount_frm_date.Text;
            productObject._toDate = txt_discount_to_date.Text;
           
            if (FileUpload1.HasFile)
                PhotoUpload();
            else
            {
                productObject._mainImage = lbl_mainImagePath.Text;
                productObject._thumbnailImage = lbl_thumbnailImagePath.Text;
            }

            return productObject;
        }

        private void getProductDetailsById()
        {
            table = AdminProductClass.getProductById(Request.QueryString["Id"].ToString(), "Product");
            if (table.Rows.Count > 0)
            {
                inputProductId.Text = table.Rows[0][0].ToString();
                inputTitle.Text = table.Rows[0][1].ToString();
                inputBarcodeNo.Text = table.Rows[0][17].ToString();
                inputStock.Text = table.Rows[0][4].ToString();
                txtGenre.Text = table.Rows[0][18].ToString();
                inputMRP.Text = table.Rows[0][5].ToString();
                inputDiscount.Text = table.Rows[0][6].ToString();
                txt_discount_frm_date.Text = table.Rows[0][14].ToString(); ;
                txt_discount_to_date.Text = table.Rows[0][15].ToString();
                inputWeight.Text = table.Rows[0][16].ToString();
                lbl_mainImagePath.Text = table.Rows[0][7].ToString();
                lbl_thumbnailImagePath.Text = table.Rows[0][8].ToString();
                inputDescription.Text = table.Rows[0][2].ToString();
                inputLongDescp.Text = table.Rows[0][3].ToString();

                if (table.Rows[0][9].ToString() == "Y")
                    chk_new_arrival.Checked = true;
                else
                    chk_new_arrival.Checked = false;

                if (table.Rows[0][11].ToString() == "Y")
                    chk_best_seller.Checked = true;
                else
                    chk_best_seller.Checked = false;

                if (table.Rows[0][10].ToString() == "Y")
                    chk_featured_prod.Checked = true;
                else
                    chk_featured_prod.Checked = false;

                if (table.Rows[0][13].ToString() == "Y")
                    chk_sale.Checked = true;
                else
                    chk_sale.Checked = false;

                if (table.Rows[0][12].ToString() == "Y")
                    chk_approve.Checked = true;
                else
                    chk_approve.Checked = false;
            }
            else
            {
                ClientMessageBox.Show("No Record Found. Please Confirm Product ID", this);
                inputProductId.Text = AutoIncrementCode.get_Productcode("spAutoIncrementProductCode");
            }
        }

        public void PhotoUpload()
        {
            if (FileUpload1.HasFile)
            {
                if (FileUpload1.PostedFile != null && FileUpload1.PostedFile.FileName != "")
                {
                    string strExtension = System.IO.Path.GetExtension(FileUpload1.FileName);
                    if ((strExtension.ToUpper() == ".JPG") || (strExtension.ToUpper() == ".JPEG") || (strExtension.ToUpper() == ".GIF") || (strExtension.ToUpper() == ".PNG"))
                    {
                        // Resize Image Before Uploading to Photo Folder
                        System.Drawing.Image imageToresize = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
                        int imgHeight = imageToresize.Height;
                        int imgWidth = imageToresize.Width;
                        int maxHeight = 684;
                        int maxWidth = 482;
                        imgHeight = (imgHeight * maxWidth) / imgWidth;
                        imgWidth = maxWidth;
                        if (imgHeight > maxHeight)
                        {
                            imgWidth = (imgWidth * imgHeight) / imgHeight;
                            imgHeight = maxHeight;
                        }

                        using (Bitmap bitmap = new Bitmap(imageToresize, imgWidth, imgHeight))
                        {
                            productObject._mainImage = "~/ProductImages/Product/Main/" + productObject._Id + strExtension;
                            bitmap.Save(Server.MapPath(productObject._mainImage), System.Drawing.Imaging.ImageFormat.Jpeg);
                        }

                        imageToresize = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
                        imgHeight = imageToresize.Height;
                        imgWidth = imageToresize.Width;
                        maxHeight = 143;
                        maxWidth = 115;
                        imgHeight = (imgHeight * maxWidth) / imgWidth;
                        imgWidth = maxWidth;
                        if (imgHeight > maxHeight)
                        {
                            imgWidth = (imgWidth * imgHeight) / imgHeight;
                            imgHeight = maxHeight;
                        }

                        using (Bitmap bitmap = new Bitmap(imageToresize, imgWidth, imgHeight))
                        {
                            productObject._thumbnailImage = "~/ProductImages/Product/Thumbnail/" + productObject._Id + strExtension;
                            bitmap.Save(Server.MapPath(productObject._thumbnailImage), System.Drawing.Imaging.ImageFormat.Jpeg);
                        }
                    }
                }

            }
        }
    }
}