﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;
using iTextSharp.text.html.simpleparser;
using System.Text;
using System.Data;
using BusinessLayerHor;
using System.IO;

namespace HouseOfRhythm.Admin
{
    public partial class Invoice : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["AdminID"] != null)
                {
                    if (Request.QueryString["orderId"] != null)
                    {
                        getOrderDetailsById();
                    }
                }
                else
                    Response.Redirect("Default.aspx");
            }
        }

        private void getOrderDetailsById()
        {
            DataSet ds = AdminProductClass.getOrderDetails(Request.QueryString["orderId"].ToString());
            gv_order.DataSource = ds.Tables[0];
            gv_order.DataBind();
            lbl_date.Text = DateTime.Now.ToString("dd/MMM/yyyy");
            lblOrderId.Text = " " + Request.QueryString["OrderId"].ToString();
            lbl_customer_name.Text = ds.Tables[1].Rows[0][0].ToString() + " " + ds.Tables[1].Rows[0][1].ToString();
            lbl_customer_email.Text = ds.Tables[1].Rows[0][2].ToString();
            lbl_customer_no.Text = ds.Tables[1].Rows[0][3].ToString();
            if(ds.Tables[3].Rows.Count > 0)
            lbl_invoice_no.Text = ds.Tables[3].Rows[0][0].ToString();

            lbl_shipping_address.Text = ds.Tables[1].Rows[0][5].ToString();  
            (gv_order.FooterRow.FindControl("lbl_subtotal") as Label).Text = ds.Tables[1].Rows[0][7].ToString();
            (gv_order.FooterRow.FindControl("lbl_grand_total") as Label).Text = ds.Tables[1].Rows[0][8].ToString();
            (gv_order.FooterRow.FindControl("lbl_shipping_cost") as Label).Text = ds.Tables[0].Rows[0][6].ToString();
        }

        protected void btnPDF_Generate(object sender, EventArgs e)
        {
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=TestPage.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            this.Page.RenderControl(hw);
            //StringReader sr = new StringReader(sw.ToString());
            //MemoryStream memStream = new MemoryStream();
            Document pdfDoc = new Document(PageSize.A4, 8f, 8f, 8f, 8f);
            //HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            //PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            PdfWriter writer = PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            pdfDoc.Open();
            byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(sw.ToString());
            MemoryStream ms = new MemoryStream(byteArray);
            XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, ms, System.Text.Encoding.UTF8);
            pdfDoc.Close();
            Response.Write(pdfDoc);
            Response.End();

            //StringReader sr = new StringReader(Request.Form[hfGridHtml.UniqueID]);
            //Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            //PdfWriter writer = PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            //pdfDoc.Open();
            //XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, sr);
            //pdfDoc.Close();
            //Response.ContentType = "application/pdf";
            //Response.AddHeader("content-disposition", "attachment;filename=HTML.pdf");
            //Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //Response.Write(pdfDoc);
            //Response.End();
        }
    }
}