﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;

namespace HouseOfRhythm.Admin
{
    public partial class Categories : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_add_music_category_Click(object sender, EventArgs e)
        {
            int i = AdminProductClass.addMusicCategory(ddl_media_type.SelectedValue, ddl_origin.SelectedValue, txt_music_cat.Text);
            if (i > 0)
            {
                ClientMessageBox.Show("Music Category " + txt_music_cat.Text + " added Successfully", this);
            }
        }
    }
}