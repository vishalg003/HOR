﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class Dashboard : System.Web.UI.Page
    {
        static DataTable singleTable;
        static DataSet multipleTable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getOrderReport();
            }
        }

        private void getOrderReport()
        {
            multipleTable = AdminProductClass.getDataRecord("spAdminGetVariousDetailsForDashboard");
            gv_orders_list.DataSource = multipleTable.Tables[0];
            gv_orders_list.DataBind();

            lbl_total_orders.Text = multipleTable.Tables[1].Rows[0][0].ToString();
            lbl_total_sales.Text = multipleTable.Tables[4].Rows[0][0].ToString();
            lbl_new_customer_count.Text = multipleTable.Tables[6].Rows[0][0].ToString();

            dl_product_list.DataSource = multipleTable.Tables[2];
            dl_product_list.DataBind();

            gv_bestSeller_list.DataSource = multipleTable.Tables[3];
            gv_bestSeller_list.DataBind();

            gv_new_customer_list.DataSource = multipleTable.Tables[5];
            gv_new_customer_list.DataBind();
        }

        protected void gv_product_RowCommond(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "type")
            {
                GridViewRow rowSelect = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
                int rowIndex = rowSelect.RowIndex;
                if (Convert.ToInt32(gv_bestSeller_list.Rows[rowIndex].Cells[0].Text) <= 20000000)
                {
                   Response.Redirect("AddMusic.aspx?Id" + gv_bestSeller_list.Rows[rowIndex].Cells[0].Text);
                }

                else if (Convert.ToInt32(gv_bestSeller_list.Rows[rowIndex].Cells[0].Text) > 200000000 && Convert.ToInt32(gv_bestSeller_list.Rows[rowIndex].Cells[0].Text) <= 300000000)
                {
                    Response.Redirect("AddMovies.aspx?Id=" + gv_bestSeller_list.Rows[rowIndex].Cells[0].Text);
                }

                else if (Convert.ToInt32(gv_bestSeller_list.Rows[rowIndex].Cells[0].Text) >= 300000000 && Convert.ToInt32(gv_bestSeller_list.Rows[rowIndex].Cells[0].Text) <= 400000000)
                {
                    Response.Redirect("AddBooks.aspx?Id=" + gv_bestSeller_list.Rows[rowIndex].Cells[0].Text);
                }
                else
                {
                    Response.Redirect("AddProduct.aspx?Id=" + gv_bestSeller_list.Rows[rowIndex].Cells[0].Text);
                }

            }
        }
    }
}