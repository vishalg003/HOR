﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BusinessLayerHor;

namespace HouseOfRhythm.Admin
{
    public partial class PurchaseReport : System.Web.UI.Page
    {
        static DataTable table;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getCustomerReports(txt_date_from.Text, txt_date_to.Text, "spAdminGetPurchaseReport", "Current");
            }
        }

        private void getCustomerReports(string from_date, string to_date, string procedure, string type)
        {
            table = AdminClass.getReporstByDate(from_date, to_date, procedure, type);
            gv_purchase_report.DataSource = table;
            gv_purchase_report.DataBind();
        }

        protected void btn_reset_filters_Click(object sender, EventArgs e)
        {
            getCustomerReports(txt_date_from.Text, txt_date_to.Text, "spAdminGetPurchaseReport", "Current");
            txt_date_from.Text = txt_date_to.Text = "";
            ddl_days.SelectedIndex = 0;
        }

        protected void btn_export_Click(object sender, EventArgs e)
        {
            if (ddl_export.SelectedValue.Equals("Excel"))
            {
                // Clear all content output from the buffer stream
                Response.ClearContent();
                // Specify the default file name using "content-disposition" RESPONSE header
                Response.AppendHeader("content-disposition", "attachment; filename=PurchaseReport" + DateTime.Now.ToString("dd/mm/yyyy") + ".xls");
                // Set excel as the HTTP MIME type
                Response.ContentType = "application/excel";
                // Create an instance of stringWriter for writing information to a string
                System.IO.StringWriter stringWriter = new System.IO.StringWriter();
                // Create an instance of HtmlTextWriter class for writing markup 
                // characters and text to an ASP.NET server control output stream
                HtmlTextWriter htw = new HtmlTextWriter(stringWriter);

                // Set white color as the background color for gridview header row
                //gv_low_stock_report.HeaderRow.Style.Add("background-color", "#FFFFFF");

                //// Set background color of each cell of GridView1 header row
                //foreach (TableCell tableCell in gv_low_stock_report.HeaderRow.Cells)
                //{
                //    tableCell.Style["background-color"] = "#A55129";
                //}

                //// Set background color of each cell of each data row of GridView1
                //foreach (GridViewRow gridViewRow in gv_low_stock_report.Rows)
                //{
                //    gridViewRow.BackColor = System.Drawing.Color.White;
                //    foreach (TableCell gridViewRowTableCell in gridViewRow.Cells)
                //    {
                //        gridViewRowTableCell.Style["background-color"] = "#FFF7E7";
                //    }
                //}

                gv_purchase_report.RenderControl(htw);
                Response.Write(stringWriter.ToString());
                Response.End();
            }
        }

        protected void btn_show_Report_Click(object sender, EventArgs e)
        {
            getCustomerReports(txt_date_from.Text, txt_date_to.Text, "spAdminGetPurchaseReport", ddl_days.SelectedValue);
        }

        public override void VerifyRenderingInServerForm(Control control)
        {

        }
    }
}