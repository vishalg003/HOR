﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class Format : System.Web.UI.Page
    {
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
            }
        }

        protected void btn_save_Click(object sender, EventArgs e)
        {
            int i = Formats.insertFromat(txt_format.Text);
            if (i > 0)
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check \"></i> <b> Details added SUCCESSFULLY </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
                gridview_format.DataBind();
            }
        }
    }
}