﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class CustomerCatalog : System.Web.UI.Page
    {
        DataSet table;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["sortType"] != null)
                {
                    if (Session["sortType"].Equals("name"))
                    {
                        nameChange(0, 50, "Customer", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
                        setDataToGridview(0, 50, table);
                    }
                    else if (Session["sortType"].Equals("email"))
                    {
                        nameChange(0, 50, "Email", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
                        setDataToGridview(0, 50, table);
                    }
                    else if (Session["sortType"].Equals("mobile"))
                    {
                        nameChange(0, 50, "Mobile", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
                        setDataToGridview(0, 50, table);
                    }
                    else if (Session["sortType"].Equals("country"))
                    {
                        nameChange(0, 50, "Country", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
                        setDataToGridview(0, 50, table);
                    }
                    else if (Session["sortType"].Equals("state"))
                    {
                        nameChange(0, 50, "State", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
                        setDataToGridview(0, 50, table);
                    }
                    else if (Session["sortType"].Equals("pincode"))
                    {
                        nameChange(0, 50, "Pincode", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
                        setDataToGridview(0, 50, table);
                    }
                    else
                    {
                        dateChange(0, 50, Convert.ToDateTime(Session["from"].ToString()), Convert.ToDateTime(Session["from"].ToString()));
                        setDataToGridview(0, 50, table);
                    }
                }
                else
                    getCustomerDetails(gv_customer_list.PageIndex, gv_customer_list.PageSize);
            }
        }

        private void getCustomerDetails(int pageIndex, int pageSize)
        {
            table = AdminClass.getProductCatalog(pageIndex, pageSize, "Customer");
            setDataToGridview(pageIndex, pageSize, table);
        }

        private void setDataToGridview(int pageIndex, int pageSize, DataSet table)
        {
            if (table.Tables[1].Rows.Count > 0)
            {
                int totalPages = (int)(table.Tables[1].Rows[0][0]) / pageSize;
                if (((int)(table.Tables[1].Rows[0][0]) % pageSize) != 0)
                {
                    totalPages += 1;
                }

                List<ListItem> pages = new List<ListItem>();
                if (totalPages > 1)
                {
                    for (int i = 1; i <= totalPages; i++)
                    {
                        pages.Add(new ListItem(i.ToString(), i.ToString(), i != (pageIndex + 1)));
                    }
                }
                gv_customer_list.DataSource = table.Tables[0];
                gv_customer_list.DataBind();
                repeaterPaging.DataSource = pages;
                repeaterPaging.DataBind();

                if (table.Tables[0].Rows.Count < pageSize)
                {
                    btn_paging_next.Enabled = false;
                }
                else
                {
                    btn_paging_next.Enabled = true;
                }
            }
        }

        /* Method to bind data to Gridview and Page number to button with Manual Paging */
        /*******************************************************************************************/
        protected void linkButton_Click(object sender, EventArgs e)
        {
            int pageIndex = int.Parse((sender as LinkButton).CommandArgument);
            pageIndex -= 1;
            prevNextButtonClick(pageIndex);
        }

        /* Method to bind data to Gridview with PREVIOUS button click */
        /*******************************************************************************************/
        protected void btn_paging_prev_Click(object sender, EventArgs e)
        {
            int pageIndex = Convert.ToInt32(ViewState["pageNo"]) - 1;
            prevNextButtonClick(pageIndex);
        }

        /* Method to bind data to Gridview with NEXT button click */
        /*******************************************************************************************/
        protected void btn_paging_next_Click(object sender, EventArgs e)
        {
            int pageIndex = Convert.ToInt32(ViewState["pageNo"]) + 1;
            prevNextButtonClick(pageIndex);
        }

        /* Method to filter table with CUSTOMER NAME Filter */
        /*******************************************************************************************/
        protected void name_TextChanged(object sender, EventArgs e)
        {
            Session["filterValue"] = (gv_customer_list.HeaderRow.FindControl("txt_name") as TextBox).Text;
            Session["sortType"] = "name";
            nameChange(0, 50, "Customer", Session["filterValue"].ToString(), "spAdminSort_OrderCatalog_ByCustomerName");
            setDataToGridview(0, 50, table);
        }

        /* Method to filter table with CUSTOMER EMAIL Filter */
        /*******************************************************************************************/
        protected void email_TextChanged(object sender, EventArgs e)
        {
            Session["filterValue"] = (gv_customer_list.HeaderRow.FindControl("txt_email") as TextBox).Text;
            Session["sortType"] = "email";
            nameChange(0, 50, "Email", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
            setDataToGridview(0, 50, table);
        }

        /* Method to filter table with CUSTOMER NUMBER Filter */
        /*******************************************************************************************/
        protected void mobileNo_TextChanged(object sender, EventArgs e)
        {
            Session["filterValue"] = (gv_customer_list.HeaderRow.FindControl("txt_mobile") as TextBox).Text;
            Session["sortType"] = "mobile";
            nameChange(0, 50, "Mobile", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
            setDataToGridview(0, 50, table);
        }

        /* Method to filter table with CUSTOMER NUMBER Filter */
        /*******************************************************************************************/
        protected void country_TextChanged(object sender, EventArgs e)
        {
            Session["filterValue"] = (gv_customer_list.HeaderRow.FindControl("txt_country") as TextBox).Text;
            Session["sortType"] = "country";
            nameChange(0, 50, "Country", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
            setDataToGridview(0, 50, table);
        }

        /* Method to filter table with CUSTOMER NUMBER Filter */
        /*******************************************************************************************/
        protected void state_TextChanged(object sender, EventArgs e)
        {
            Session["filterValue"] = (gv_customer_list.HeaderRow.FindControl("txt_state") as TextBox).Text;
            Session["sortType"] = "state";
            nameChange(0, 50, "State", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
            setDataToGridview(0, 50, table);
        }

        /* Method to filter table with CUSTOMER NUMBER Filter */
        /*******************************************************************************************/
        protected void pincode_TextChanged(object sender, EventArgs e)
        {
            Session["filterValue"] = (gv_customer_list.HeaderRow.FindControl("txt_pincode") as TextBox).Text;
            Session["sortType"] = "picode";
            nameChange(0, 50, "Pincode", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
            setDataToGridview(0, 50, table);
        }

        /* Method to filter table with CUSTOMER NUMBER Filter */
        /*******************************************************************************************/
        protected void createDate_TextChanged(object sender, EventArgs e)
        {
            Session["from"] = Convert.ToDateTime((gv_customer_list.HeaderRow.FindControl("txt_rgstr_date_from") as TextBox).Text);
            Session["to"] = Convert.ToDateTime((gv_customer_list.HeaderRow.FindControl("txt_rgstr_date_to") as TextBox).Text);
            Session["sortType"] = "date";
            dateChange(0, 50, Convert.ToDateTime(Session["from"]), Convert.ToDateTime(Session["from"]));
            setDataToGridview(0, 50, table);
        }

        private void prevNextButtonClick(int pageIndex)
        {
            ViewState["pageNo"] = pageIndex.ToString();
            gv_customer_list.PageIndex = pageIndex;
            if (gv_customer_list.PageIndex == 0)
            {
                btn_paging_prev.Enabled = false;
            }
            else
            {
                btn_paging_prev.Enabled = true;
            }

            if (Session["sortType"] != null)
            {
                if (Session["sortType"].Equals("name"))
                {
                    nameChange(pageIndex, 50, "Customer",Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
                }
                else if (Session["sortType"].Equals("email"))
                {
                    nameChange(pageIndex, 50, "Email", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
                }
                else if (Session["sortType"].Equals("mobile"))
                {
                    nameChange(pageIndex, 50, "Mobile", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
                }
                else if (Session["sortType"].Equals("country"))
                {
                    nameChange(pageIndex, 50, "Country", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
                }
                else if (Session["sortType"].Equals("state"))
                {
                    nameChange(pageIndex, 50, "State", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
                }
                else if (Session["sortType"].Equals("pincode"))
                {
                    nameChange(pageIndex, 50, "Pincode", Session["filterValue"].ToString(), "spAdminSort_CustomerList_ByFilters");
                }
                else
                {
                    dateChange(pageIndex, 50, Convert.ToDateTime(Session["from"]), Convert.ToDateTime(Session["to"]));
                }
                setDataToGridview(pageIndex, gv_customer_list.PageSize, table);
            }

            else
            {
                getCustomerDetails(pageIndex, gv_customer_list.PageSize);
            }
        }

        /* Method to clear session variadle for other product type filters */
        /*******************************************************************************/
        private void clearFiltertypeSessions()
        {
            Session["from"] = Session["to"] = Session["filterType"] = Session["sortType"] = null;
            Session.Remove("from");
            Session.Remove("to");
            Session.Remove("filterType");
            Session.Remove("sortType");
        }

        /* Method To Sort Griveview Data By Name, Email, Mobile, Country, State, Pincode */
        /***************************************************************************************************/
        private void nameChange(int index, int size, string type, string value, string procedure)
        {
            table = AdminClass.getProductCatalog_by_SingleFilter
                               (
                                   index,
                                   size,
                                   type,
                                   value,
                                   procedure
                               );
        }

        /* Method To Sort Griveview Data By Date */
        /***************************************************************************************************/
        private void dateChange(int index, int size, DateTime value1, DateTime value2)
        {
            table = AdminClass.getProductCatalog_by_DateRangeFilter
                    (
                        0,
                        50,
                        Convert.ToDateTime(Session["from"]),
                        Convert.ToDateTime(Session["to"]),
                        "spAdminSort_CustomerCatalog_ByDateRange"
                    );
        }

        protected void btn_reset_Click(object sender, EventArgs e)
        {
            clearFiltertypeSessions();
            getCustomerDetails(gv_customer_list.PageIndex, gv_customer_list.PageSize);
        }

    }
}