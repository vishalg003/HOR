﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class NewProduct : System.Web.UI.Page
    {
        DataTable table;
        PurchasePage purchasePage;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["Id"] != null)
                {
                    txt_purchase_order_id.Text = Request.QueryString["Id"].ToString();
                    getPurchaseDetails();
                    btn_save.Enabled = false;
                }
                else
                {
                    txt_purchase_order_id.Text = AutoIncrementCode.get_purchase_Id();
                }
            }
        }

        protected void btn_save_Click(object sender, EventArgs e)
        {
            PurchasePage purchasePage = setPurchaseDetails();
            
            int i = purchasePage.insertPurchase(purchasePage);
            if (i > 0)
            {
                lbl_alert_success.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check-square \"></i> <b> Data Inserted SuccessFully <b />";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
            }
            else
            {
                lbl_alert_danger.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-exclamation-triangle \"></i> <b> Somthing went Wrong. Please Check Details <b />";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsgDanger()", true);
            }
            txt_purchase_order_id.Text = AutoIncrementCode.get_purchase_Id();
        }

        protected void btn_update_Click(object sender, EventArgs e)
        {
            PurchasePage purchasePage = setPurchaseDetails();

            int i = purchasePage.updatePurchase(purchasePage);
            if (i > 0)
            {
                lbl_alert_success.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-check-square \"></i> <b> Details Updated SuccessFully <b />";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
            }
            else
            {
                lbl_alert_danger.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-exclamation-triangle \"></i> <b> Somthing went Wrong. Please Check Details <b />";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsgDanger()", true);
            }
        }

        protected void btn_calculate_Click(object sender, EventArgs e)
        {
            if (txt_new_quantity.Text == "" || txt_new_quantity.Text == "0")
            {
                rfv_qty.IsValid = false;
            }
            else if (txt_unit_price.Text == "" || Convert.ToDecimal(txt_new_quantity.Text) == 0)
            {
                rfv_unit_price.IsValid = false;
            }
            else
            {
                txt_subtotal.Text = (Convert.ToDecimal(txt_new_quantity.Text) * Convert.ToDecimal(txt_unit_price.Text)).ToString();
                txt_discount_percent.Text = String.Format("{0:0.0}", (Convert.ToDecimal(txt_discount_price.Text) / Convert.ToDecimal(txt_subtotal.Text)) * 100);
                decimal discount_amt = Convert.ToDecimal(String.Format("{0:0.00}", (Convert.ToDecimal(txt_subtotal.Text) - Convert.ToDecimal(txt_discount_price.Text))));
                txt_tax_amount.Text = String.Format("{0:0.00}", (discount_amt * Convert.ToDecimal(txt_gst.Text)) / 100);
                txt_total_amount.Text = (String.Format("{0:0.00}", (Convert.ToDecimal(txt_tax_amount.Text) + discount_amt)));
            }
        }

        private PurchasePage setPurchaseDetails()
        {
            PurchasePage purchasePage = new PurchasePage();
            purchasePage._PurchseId = txt_purchase_order_id.Text;
            purchasePage._Dealer = txt_distributor.Text;
            purchasePage._invoiceID = txt_invoice_id.Text;
            purchasePage._Title = txt_title.Text;
            purchasePage._HsnNo = txt_hsn_no.Text;
            
            purchasePage._Stock = Convert.ToInt32(txt_new_quantity.Text);
            purchasePage._unitPrice = Convert.ToDecimal(txt_unit_price.Text);
            if (txt_gst.Text != "")
            {
                purchasePage._gstTax = Convert.ToInt32(txt_gst.Text);
            }
            else
            {
                purchasePage._gstTax = 0;
            }
            if (txt_discount_price.Text != "")
                purchasePage._discountAmount = Convert.ToDecimal(txt_discount_price.Text);
            else
                purchasePage._discountAmount = 0;

            if (txt_tax_amount.Text != "")
                purchasePage._TaxAmount = Convert.ToDecimal(txt_tax_amount.Text);
            else
                purchasePage._TaxAmount = 0;

            purchasePage._Subtotal = Convert.ToDecimal(txt_subtotal.Text);
            purchasePage._purchseAmount = Convert.ToDecimal(txt_total_amount.Text);
            purchasePage._customerPrice = Convert.ToDecimal(txt_customer_price.Text);
            purchasePage._arrivalDate = txt_arrival_date.Text;
            purchasePage._orderedDate = txt_ordered_date.Text;
            if (txt_discount_percent.Text != "")
            {
                if(txt_discount_price.Text == "0")
                purchasePage._discountPercent = Convert.ToDecimal(txt_discount_percent.Text);

            }
            else
            {
                purchasePage._discountPercent = 0;
            }

            return purchasePage;
        }

        private void getPurchaseDetails()
        {
            purchasePage = new PurchasePage();
            table = purchasePage.getPurchaseDetailsById(txt_purchase_order_id.Text);

            if (table != null)
            {
                if (table.Rows.Count > 0)
                {
                    txt_distributor.Text = table.Rows[0][0].ToString();
                    txt_invoice_id.Text = table.Rows[0][1].ToString();
                    txt_unit_price.Text = table.Rows[0][2].ToString();
                    txt_subtotal.Text = table.Rows[0][3].ToString(); ;
                    txt_gst.Text = table.Rows[0][4].ToString();
                    txt_tax_amount.Text = table.Rows[0][5].ToString();
                    txt_total_amount.Text = table.Rows[0][6].ToString();
                    txt_new_quantity.Text = table.Rows[0][7].ToString();
                    txt_ordered_date.Text = table.Rows[0][8].ToString();
                    txt_arrival_date.Text = table.Rows[0][9].ToString();
                    txt_customer_price.Text = table.Rows[0][10].ToString();
                    txt_discount_percent.Text = table.Rows[0][13].ToString();
                    txt_discount_price.Text = table.Rows[0][14].ToString();
                    txt_title.Text = table.Rows[0][15].ToString();
                    lbl_entry_date.Text = table.Rows[0][11].ToString();
                    lbl_update_date.Text = table.Rows[0][12].ToString();
                    txt_hsn_no.Text = table.Rows[0][16].ToString();
                }
            }
        }
    }
}