﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;

namespace HouseOfRhythm.Admin
{
    public partial class CategoryProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_add_Product_Category_Click(object sender, EventArgs e)
        {
            int i = AdminProductClass.addCategory("spAdminInsertProductCategory", txt_product_title.Text);
            if (i > 0)
            {
                ClientMessageBox.Show("Product Category " + txt_product_title.Text + " added successfully", this);
            }
        }
    }
}