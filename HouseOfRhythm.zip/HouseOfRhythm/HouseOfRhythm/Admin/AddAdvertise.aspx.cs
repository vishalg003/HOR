﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using BusinessLayerHor;

namespace HouseOfRhythm.Admin
{
    public partial class AddAdvertise : System.Web.UI.Page
    {
        Advertisement add;
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            txtaddvertisement_id.Text = AutoIncrementCode.get_Advertisement_Id();
        }

        protected void btn_add_image_Click(object sender, EventArgs e)
        {
            try
            {
                add = new Advertisement();
                add.advertisement_id = txtaddvertisement_id.Text;
                add.comapny_name = txtcomapnyname.Text;
                add.website_address = txtwebsiteurl.Text;
                if (chk_display.Checked)
                {
                    add.display = 'Y';
                }
                else
                {
                    add.display = 'N';
                }
                PhotoUpload();
                int i = add.insertAdvertisement();
                if (i > 0)
                {
                    ClientMessageBox.Show("Advertise Inserted Successfully!", this);
                    clearTextbox();
                }
                txtaddvertisement_id.Text = AutoIncrementCode.get_Advertisement_Id();
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        public void PhotoUpload()
        {
            if (FileUpload1.HasFile)
            {
                if (FileUpload1.PostedFile != null && FileUpload1.PostedFile.FileName != "")
                {
                    string strExtension = System.IO.Path.GetExtension(FileUpload1.FileName);
                    if ((strExtension.ToUpper() == ".JPG") || (strExtension.ToUpper() == ".JPEG") || (strExtension.ToUpper() == ".GIF") || (strExtension.ToUpper() == ".PNG"))
                    {
                        // Resize Image Before Uploading to Photo Folder
                        System.Drawing.Image imageToresize = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
                        int imgHeight = imageToresize.Height;
                        int imgWidth = imageToresize.Width;
                        int maxHeight = 300;
                        int maxWidth = 350;
                        imgHeight = (imgHeight * maxWidth) / imgWidth;
                        imgWidth = maxWidth;
                        if (imgHeight > maxHeight)
                        {
                            imgWidth = (imgWidth * imgHeight) / imgHeight;
                            imgHeight = maxHeight;
                        }

                        using (Bitmap bitmap = new Bitmap(imageToresize, imgWidth, imgHeight))
                        {
                            add.ad_image = "~/ProductImages/" + txtaddvertisement_id.Text + strExtension;
                            bitmap.Save(Server.MapPath(add.ad_image), System.Drawing.Imaging.ImageFormat.Jpeg);
                        }

                    }
                }
            }
            else
            {
                add.ad_image = lblimage.Text;
            }
        }

        private void clearTextbox()
        {
            txtcomapnyname.Text = "";
            txtwebsiteurl.Text = "";
            chk_display.Checked = false;
        }

        protected void btn_search_Click(object sender, EventArgs e)
        {
            add = new Advertisement();
            dt=add.searchAdvertisement(txtcomapnyname.Text);
            if (dt.Rows.Count > 0)
            {
                lblimage.Text = dt.Rows[0][0].ToString();
                txtaddvertisement_id.Text = dt.Rows[0][0].ToString();
                txtcomapnyname.Text = dt.Rows[0][1].ToString();
                txtwebsiteurl.Text = dt.Rows[0][2].ToString();
                if (Convert.ToChar(dt.Rows[0][4]) == 'Y')
                {
                    chk_display.Checked = true;
                }
                else
                {
                    chk_display.Checked = false;
                }
                lblimage1.Text = dt.Rows[0][3].ToString();
            }
        }

        protected void btn_update_Click(object sender, EventArgs e)
        {
            add = new Advertisement();
            add.advertisement_id = lblimage.Text;
            add.comapny_name = txtcomapnyname.Text;
            add.website_address = txtwebsiteurl.Text;
            if (FileUpload1.HasFile)
            {
                PhotoUpload();
            }
            else
            {
                add.ad_image = lblimage1.Text;
            }
            if (chk_display.Checked)
            {
                add.display = 'Y';
            }
            else
            {
                add.display = 'N';
            }
            int i = add.updateAdvertise();
            if (i > 0)
            {
                ClientMessageBox.Show("Update Successfully!", this);
                clearTextbox();
            }
        }

        protected void btn_delete_Click(object sender, EventArgs e)
        {
            add = new Advertisement();
            add.advertisement_id = lblimage.Text;
            int i = add.deleteAdvertise();
            if (i > 0)
            {
                ClientMessageBox.Show("Deleted Successfully", this);
            }
        }
    }
}