﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using BusinessObject;
using BusinessLayerHor;
using System.IO;
using System.Drawing;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class AddMusic : System.Web.UI.Page
    {
        MusicObject musicObject;
        ProductClass productClass;
        DataTable table;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["Id"] != null)
                {
                    btn_update.Enabled = true;
                    getMusicDetailsById();
                    btn_save.Enabled = false;
                }
                else
                {
                    inputMusicId.Text = AutoIncrementCode.get_Musiccode("spAutoIncrementCode");
                }
                getAddedList();
                getFormat();
            }
        }

        private void getFormat()
        {
            table = AdminClass.getFormatDetails();
            ddl_format.DataSource = table;
            ddl_format.DataTextField = "type";
            ddl_format.DataValueField = "type";
            ddl_format.DataBind();
        }

        protected void GenerateBarcode(object sender, EventArgs e)
        {
            Random random = new Random();
            inputBarcodeNo.Text = (Convert.ToString(random.Next(10000000, 80000000)));
        }

        /* Method To Insert Music Details*/
        /******************************************************************************/
        protected void btn_save_Click(object sender, EventArgs e)
        {
            productClass = new ProductClass();
            musicObject = getValuesToInsertUpdate();

            int i = productClass.insertMusic(musicObject);
            if (i > 0)
            {
                ClientMessageBox.Show("Record Inserted", this);
            }
            inputMusicId.Text = AutoIncrementCode.get_Musiccode("spAutoIncrementMusicCode");
            getAddedList();
            getFormat();
            clearTextbox();
        }

        /*Method To blank all textboxes */
        private void clearTextbox()
        {
            inputArtist.Text = "";
            inputBarcodeNo.Text = "";
            inputCatalogNo.Text = "";
            inputComposer.Text = "";
            inputDescription.Text = "";
            inputDiscount.Text = "";
            inputLabel.Text = "";
            inputLyricist.Text = "";
            inputMRP.Text = "";
            inputNoOfDisk.Text = "";
            inputResease.Text = "";
            inputSKU.Text = "";
            inputStock.Text = "";
            inputTitle.Text = "";
            inputTracks.Text = "";
            inputWeight.Text = "";
            txt_discount_frm_date.Text = "";
            txt_discount_to_date.Text = "";
            txtGenre.Text = "";
        }
        /* Method To Update Music Details*/
        /******************************************************************************/
        protected void btn_edit_Click(object sender, EventArgs e)
        {
            productClass = new ProductClass();
            musicObject = getValuesToInsertUpdate();

            int i = productClass.updateMusic(musicObject);
            if (i > 0)
            {
                ClientMessageBox.Show("Record Updated", this);
                clearTextbox();
            }
            getAddedList();
            getFormat();
        }

        private MusicObject getValuesToInsertUpdate()
        {
            musicObject = new MusicObject();

            musicObject._Id = inputMusicId.Text;
            musicObject._Tiltle = inputTitle.Text;
            musicObject._Artist = inputArtist.Text;
            musicObject._Composer = inputComposer.Text;
            musicObject._Lyricist = inputLyricist.Text;
            musicObject._Genre = txtGenre.Text;
            musicObject._NoOfDisc = Convert.ToInt32(inputNoOfDisk.Text);
            musicObject._Label = inputLabel.Text;
            musicObject._CatlogNo = inputCatalogNo.Text;
            musicObject._BarcodeNo = inputBarcodeNo.Text;
            if (inputResease.Text != "")
            {
                musicObject._ReleaseDate = inputResease.Text;
            }
            else
                musicObject._ReleaseDate = "";
            musicObject._Mrp = Convert.ToDecimal(inputMRP.Text);
            if (inputDiscount.Text != "")
                musicObject._Discount = Convert.ToInt32(inputDiscount.Text);
            else
                musicObject._Discount = 0;
            musicObject._Stock = Convert.ToInt32(inputStock.Text);
            musicObject._Tracks = inputTracks.Text;
            musicObject._Format = ddl_format.SelectedValue;
            musicObject._Sku = inputSKU.Text;
            musicObject._Description = inputDescription.Text;
            if (chk_featured_prod.Checked)
                musicObject._featuredProd = 'Y';
            else
                musicObject._featuredProd = 'N';

            if (chk_new_arrival.Checked)
                musicObject._newArrival = 'Y';
            else
                musicObject._newArrival = 'N';

            if (chk_best_seller.Checked)
                musicObject._bestSeller = 'Y';
            else
                musicObject._bestSeller = 'N';

            if (chk_approve.Checked)
                musicObject._Approve = 'Y';
            else
                musicObject._Approve = 'N';

            if (chk_sale.Checked)
                musicObject._Sale = 'Y';
            else
                musicObject._Sale = 'N';
            if (chk_pre_order.Checked)
                musicObject._PreOrder = 'Y';
            else
                musicObject._PreOrder = 'N';

            musicObject._Weight = Convert.ToDecimal(inputWeight.Text);
            musicObject._fromDate = txt_discount_frm_date.Text;
            musicObject._toDate = txt_discount_to_date.Text;
            musicObject._modifiedDate = DateTime.Now;
            musicObject._Origin = ddl_origin.SelectedValue;
            musicObject._Media = ddl_media.SelectedValue;

            if (FileUpload1.HasFile)
                PhotoUpload();
            else
            {
                musicObject._MainImage = lbl_mainImagePath.Text;
                musicObject._ThumbnailImage = lbl_thumbnailImagePath.Text;
            }

            return musicObject;
        }

        private void getMusicDetailsById()
        {
            table = AdminProductClass.getProductById(Request.QueryString["Id"], "Music");
            if (table.Rows.Count > 0 || table.Rows.Count == 1)
            {
                inputMusicId.Text = table.Rows[0][0].ToString();
                inputTitle.Text = table.Rows[0][1].ToString();
                inputArtist.Text = table.Rows[0][2].ToString();
                inputComposer.Text = table.Rows[0][3].ToString();
                inputLyricist.Text = table.Rows[0][4].ToString();
                inputCatalogNo.Text = table.Rows[0][5].ToString();
                inputSKU.Text = table.Rows[0][6].ToString();
                inputBarcodeNo.Text = table.Rows[0][7].ToString();
                inputLabel.Text = table.Rows[0][8].ToString();
                inputStock.Text = table.Rows[0][9].ToString();
                inputNoOfDisk.Text = table.Rows[0][10].ToString();
                inputMRP.Text = table.Rows[0][11].ToString();
                inputDiscount.Text = table.Rows[0][12].ToString();
                txt_discount_frm_date.Text = table.Rows[0][13].ToString();
                txt_discount_to_date.Text = table.Rows[0][14].ToString();
                inputResease.Text = table.Rows[0][15].ToString();
                inputWeight.Text = table.Rows[0][16].ToString();
                inputDescription.Text = table.Rows[0][17].ToString();
                inputTracks.Text = table.Rows[0][18].ToString();
                txtGenre.Text = table.Rows[0][24].ToString();
                if (table.Rows[0][29].ToString() != "")
                    ddl_origin.SelectedValue = table.Rows[0][29].ToString();
                if (table.Rows[0][30].ToString() != "")
                    ddl_media.SelectedValue = table.Rows[0][30].ToString();

                if (table.Rows[0][19].ToString() == "Y")
                    chk_new_arrival.Checked = true;
                else
                    chk_new_arrival.Checked = false;

                if (table.Rows[0][20].ToString() == "Y")
                    chk_best_seller.Checked = true;
                else
                    chk_best_seller.Checked = false;

                if (table.Rows[0][21].ToString() == "Y")
                    chk_featured_prod.Checked = true;
                else
                    chk_featured_prod.Checked = false;

                if (table.Rows[0][22].ToString() == "Y")
                    chk_sale.Checked = true;
                else
                    chk_sale.Checked = false;

                if (table.Rows[0][23].ToString() == "Y")
                    chk_approve.Checked = true;
                else
                    chk_approve.Checked = false;
                if (table.Rows[0][31].ToString() == "Y")
                    chk_pre_order.Checked = true;
                else
                    chk_pre_order.Checked = false;
                lbl_thumbnailImagePath.Text = table.Rows[0][26].ToString();
                if (table.Rows[0][26].ToString() != "")
                    ddl_format.SelectedValue = table.Rows[0][27].ToString();
                lbl_mainImagePath.Text = table.Rows[0][28].ToString();

                chk_approve.Enabled = true;
                chk_sale.Enabled = true;
            }
            else
            {
                ClientMessageBox.Show("No Record Found. Please Confirm Music ID", this);
                inputMusicId.Text = AutoIncrementCode.get_Musiccode("spAutoIncrementCode");
            }
        }

        /* ******************************************* Image Resizing Code *********************************************** */
        public void PhotoUpload()
        {
            if (FileUpload1.HasFile)
            {
                if (FileUpload1.PostedFile != null && FileUpload1.PostedFile.FileName != "")
                {
                    string strExtension = System.IO.Path.GetExtension(FileUpload1.FileName);
                    if ((strExtension.ToUpper() == ".JPG") || (strExtension.ToUpper() == ".JPEG") || (strExtension.ToUpper() == ".GIF") || (strExtension.ToUpper() == ".PNG"))
                    {
                        // Resize Image Before Uploading to Photo Folder
                        System.Drawing.Image imageToresize = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
                        int imgHeight = imageToresize.Height;
                        int imgWidth = imageToresize.Width;
                        int maxHeight = 684;
                        int maxWidth = 482;
                        imgHeight = (imgHeight * maxWidth) / imgWidth;
                        imgWidth = maxWidth;
                        if (imgHeight > maxHeight)
                        {
                            imgWidth = (imgWidth * imgHeight) / imgHeight;
                            imgHeight = maxHeight;
                        }

                        using (Bitmap bitmap = new Bitmap(imageToresize, imgWidth, imgHeight))
                        {
                            musicObject._MainImage = "~/ProductImages/Music/MainImage/" + musicObject._Id + strExtension;
                            bitmap.Save(Server.MapPath(musicObject._MainImage), System.Drawing.Imaging.ImageFormat.Jpeg);
                        }

                        imageToresize = System.Drawing.Image.FromStream(FileUpload1.PostedFile.InputStream);
                        imgHeight = imageToresize.Height;
                        imgWidth = imageToresize.Width;
                        maxHeight = 143;
                        maxWidth = 115;
                        imgHeight = (imgHeight * maxWidth) / imgWidth;
                        imgWidth = maxWidth;
                        if (imgHeight > maxHeight)
                        {
                            imgWidth = (imgWidth * imgHeight) / imgHeight;
                            imgHeight = maxHeight;
                        }

                        using (Bitmap bitmap = new Bitmap(imageToresize, imgWidth, imgHeight))
                        {
                            musicObject._ThumbnailImage = "~/ProductImages/Music/Thumbnail/" + musicObject._Id + strExtension;
                            bitmap.Save(Server.MapPath(musicObject._ThumbnailImage), System.Drawing.Imaging.ImageFormat.Jpeg);
                        }
                    }
                }

            }
        }

        /* Method To Get Lastest added music/product list */
        /* Date: 8/8/2017 */
        private void getAddedList()
        {
            table = AdminClass.getRecords("Music");
            gv_music_list.DataSource = table;
            gv_music_list.DataBind();
        }
    }
}