﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class MusicCatalog : System.Web.UI.Page
    {
        private static DataSet table;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["type"] == null)
                {
                    lbl_product_type_name.Text = "Music";
                    getMusicCatalog(gv_products_catlog.PageIndex, gv_products_catlog.PageSize, lbl_product_type_name.Text);
                }
                else
                {
                    lbl_product_type_name.Text = Session["type"].ToString();
                    ddl_product_type.SelectedValue = lbl_product_type_name.Text;
                    getMusicCatalog(gv_products_catlog.PageIndex, gv_products_catlog.PageSize, lbl_product_type_name.Text);
                }
            }
        }

        protected void gv_products_catlog_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "UpdateRecord")
            {
                if (lbl_product_type_name.Text.Equals("Music"))
                {
                    int rowIndex = int.Parse(e.CommandArgument.ToString());
                    Response.Redirect("AddMusic.aspx?Id=" + (gv_products_catlog.Rows[rowIndex].FindControl("lbl_id") as Label).Text);
                }
                else if (lbl_product_type_name.Text.Equals("Movie"))
                {
                    int rowIndex = int.Parse(e.CommandArgument.ToString());
                    Response.Redirect("AddMovies.aspx?Id=" + (gv_products_catlog.Rows[rowIndex].FindControl("lbl_id") as Label).Text);
                }
                else if (lbl_product_type_name.Text.Equals("Book"))
                {
                    int rowIndex = int.Parse(e.CommandArgument.ToString());
                    Response.Redirect("AddBooks.aspx?Id=" + (gv_products_catlog.Rows[rowIndex].FindControl("lbl_id") as Label).Text);
                }
                else
                {
                    int rowIndex = int.Parse(e.CommandArgument.ToString());
                    Response.Redirect("AddProduct.aspx?Id=" + (gv_products_catlog.Rows[rowIndex].FindControl("lbl_id") as Label).Text);
                }
            }
        }

        /* Method to get Different product list */
        /*******************************************************************************************/
        protected void ddl_product_type_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl_product_type.SelectedValue.Equals("Music"))
            {
                lbl_product_type_name.Text = "Music";
                Session["type"] = "Music";
            }
            else if (ddl_product_type.SelectedValue.Equals("Movie"))
            {
                lbl_product_type_name.Text = "Movie";
                Session["type"] = "Movie";
            }
            else if (ddl_product_type.SelectedValue.Equals("Book"))
            {
                lbl_product_type_name.Text = "Book";
                Session["type"] = "Book";
            }
            else
            {
                lbl_product_type_name.Text = "Product";
                Session["type"] = "Product";
            }
            if (Session["sortType"] != null)
                clearFiltertypeSessions();
            getMusicCatalog(0, 50, ddl_product_type.SelectedValue);
        }

        /* Method to clear session variadle for other product type filters */
        /*******************************************************************************/
        private void clearFiltertypeSessions()
    {
            Session["from"] = Session["to"] =Session["filterType"]= Session["sortType"] = null;
            Session.Remove("from");
            Session.Remove("to");
            Session.Remove("filterType");
            Session.Remove("sortType");
    }
        /* Method to bind data to Gridview with Manual Paging */
        /*******************************************************************************************/
        private void getMusicCatalog(int pageIndex, int pageSize, string type)
        {
            table = AdminClass.getProductCatalog(pageIndex, pageSize, type);
            setDataToGridview(pageIndex, pageSize, table);
        }

        /* Method to bind data to Gridview with Manual Paging */
        /*******************************************************************************************/
        //private void getMusicCatalogByRangeFilter(int fromValue, int toValue, int pageIndex, int pageSize, string procedure)
        //{
        //    table = AdminClass.getProductCatalog_by_id_range_filter
        //        (
        //            pageIndex,
        //            pageSize,
        //            lbl_product_type_name.Text,
        //            fromValue,
        //            toValue,
        //            procedure
        //        );
        //    setDataToGridview(pageIndex, pageSize, table);
        //}

        /* Method to bind data to Gridview with Manual Paging */
        /*******************************************************************************************/
        //private void getMusicCatalogBySingleFilter(string value, int pageIndex, int pageSize)
        //{
        //    table = AdminClass.getProductCatalog_by_SingleFilter
        //        (
        //            pageIndex,
        //            pageSize,
        //            lbl_product_type_name.Text,
        //            value
        //        );
        //    setDataToGridview(pageIndex, pageSize, table);
        //}

        private void setDataToGridview(int pageIndex, int pageSize, DataSet table)
        {
            if (table.Tables.Count > 1)
            {
                int totalPages = (int)(table.Tables[1].Rows[0][0]) / pageSize;
                if (((int)(table.Tables[1].Rows[0][0]) % pageSize) != 0)
                {
                    totalPages += 1;
                }

                List<ListItem> pages = new List<ListItem>();
                if (totalPages > 1)
                {
                    for (int i = 1; i <= totalPages; i++)
                    {
                        pages.Add(new ListItem(i.ToString(), i.ToString(), i != (pageIndex + 1)));
                    }
                }
            
                gv_products_catlog.DataSource = table.Tables[0];
                gv_products_catlog.DataBind();
               // repeaterPaging.DataSource = pages;
                //repeaterPaging.DataBind();

                if (table.Tables[0].Rows.Count < pageSize)
                {
                    btn_paging_next.Enabled = false;
                }
                else
                {
                    btn_paging_next.Enabled = true;
                }
            }
        }

        /* Method to bind data to Gridview and Page number to button with Manual Paging */
        /*******************************************************************************************/
        protected void linkButton_Click(object sender, EventArgs e)
        {
            int pageIndex = int.Parse((sender as LinkButton).CommandArgument);
            pageIndex -= 1;
            prevNextButtonClick(pageIndex);
        }

        /* Method to bind data to Gridview with PREVIOUS button click */
        /*******************************************************************************************/
        protected void btn_paging_prev_Click(object sender, EventArgs e)
        {
            int pageIndex = Convert.ToInt32(ViewState["pageNo"]) - 1;
            prevNextButtonClick(pageIndex);
        }

        /* Method to bind data to Gridview with NEXT button click */
        /*******************************************************************************************/
        protected void btn_paging_next_Click(object sender, EventArgs e)
        {
            int pageIndex = Convert.ToInt32(ViewState["pageNo"]) + 1;
            prevNextButtonClick(pageIndex);
        }

        /* Method to get filtered data by ID range filter */
        /*******************************************************************************************/
        protected void rangeBox_TextChanged(object sender, EventArgs e)
        {
            Session["from"] = Convert.ToInt32((gv_products_catlog.HeaderRow.FindControl("txt_id_from") as TextBox).Text);
            Session["to"] = Convert.ToInt32((gv_products_catlog.HeaderRow.FindControl("txt_id_to") as TextBox).Text);
            Session["sortType"] = "Id";
            table = AdminClass.getProductCatalog_by_id_range_filter
                (
                    0,
                    50,
                    lbl_product_type_name.Text,
                    Convert.ToInt32((gv_products_catlog.HeaderRow.FindControl("txt_id_from") as TextBox).Text),
                    Convert.ToInt32((gv_products_catlog.HeaderRow.FindControl("txt_id_to") as TextBox).Text),
                    "spAdminSortProductCatalogByIdRange"
                );
            setDataToGridview(0, 50, table);
        }

        /* Method to get filtered data by STOCK range filter */
        /*******************************************************************************************/
        protected void stockBox_TextChanged(object sender, EventArgs e)
        {
            if ((gv_products_catlog.HeaderRow.FindControl("txt_stock_from") as TextBox).Text.Equals("") ||
                (gv_products_catlog.HeaderRow.FindControl("txt_stock_to") as TextBox).Text.Equals(""))
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-times \"></i> Please enter <b > Values for both the boxes </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
            }
            else
            {
                Session["from"] = Convert.ToInt32((gv_products_catlog.HeaderRow.FindControl("txt_stock_from") as TextBox).Text);
                Session["to"] = Convert.ToInt32((gv_products_catlog.HeaderRow.FindControl("txt_stock_from") as TextBox).Text);
                Session["sortType"] = "stock";
                table = AdminClass.getProductCatalog_by_id_range_filter
                    (
                        0,
                        50,
                        lbl_product_type_name.Text,
                        Convert.ToInt32((gv_products_catlog.HeaderRow.FindControl("txt_stock_from") as TextBox).Text),
                        Convert.ToInt32((gv_products_catlog.HeaderRow.FindControl("txt_stock_to") as TextBox).Text),
                        "spAdminSortProductCatalogByStockRange"
                    );
                setDataToGridview(0, 50, table);
            }
        }

        /* Method to get filtered data by MRP range filter */
        /*******************************************************************************************/
        protected void mrp_TextChanged(object sender, EventArgs e)
        {
            Session["from"] = Convert.ToInt32((gv_products_catlog.HeaderRow.FindControl("txt_mrp_from") as TextBox).Text);
            Session["to"] = Convert.ToInt32((gv_products_catlog.HeaderRow.FindControl("txt_mrp_to") as TextBox).Text);
            Session["sortType"] = "mrp";
            table = AdminClass.getProductCatalog_by_id_range_filter
                (
                    0,
                    50,
                    lbl_product_type_name.Text,
                    Convert.ToInt32((gv_products_catlog.HeaderRow.FindControl("txt_mrp_from") as TextBox).Text),
                    Convert.ToInt32((gv_products_catlog.HeaderRow.FindControl("txt_mrp_to") as TextBox).Text),
                    "spAdminSortProductCatalogByMRPRange"
                );
            setDataToGridview(0, 50, table);
        }

        /* Method to get filtered data by TITLE filter */
        /*******************************************************************************************/
        protected void title_TextChanged(object sender, EventArgs e)
        {
            Session["filterValue"] = (gv_products_catlog.HeaderRow.FindControl("txt_title") as TextBox).Text;
            Session["sortType"] = "title";
            table = AdminClass.getProductCatalog_by_SingleFilter
                (
                    0,
                    50,
                    lbl_product_type_name.Text,
                    (gv_products_catlog.HeaderRow.FindControl("txt_title") as TextBox).Text,
                    "spAdminSortProductCatalogByTitle"
                );
            setDataToGridview(0, 50, table);
        }

        /* Method to get filtered data by SKU filter */
        /*******************************************************************************************/
        protected void sku_TextChanged(object sender, EventArgs e)
        {
            Session["filterValue"] = (gv_products_catlog.HeaderRow.FindControl("txt_sku") as TextBox).Text;
            Session["sortType"] = "sku";
            table = AdminClass.getProductCatalog_by_SingleFilter
                (
                    0,
                    50,
                    lbl_product_type_name.Text,
                    (gv_products_catlog.HeaderRow.FindControl("txt_sku") as TextBox).Text,
                    "spAdminSortProductCatalogBySKU"
                );
            setDataToGridview(0, 50, table);
        }

        /* Method to get filtered data by *APPROVE STATUS YES *  filter */
        /*******************************************************************************************/
        protected void rb_yes_checked(object sender, EventArgs e)
        {
            Session["filterValue"] = "Y";
            Session["sortType"] = "appY";
            table = AdminClass.getProductCatalog_by_SingleFilter
                (
                    0,
                    50,
                    lbl_product_type_name.Text,
                    "Y",
                    "spAdminSortProductCatalogByApproveStatus"
                );
            setDataToGridview(0, 50, table);
        }

        /* Method to get filtered data by * APPROVE STATUS NO * filter */
        /*******************************************************************************************/
        protected void rb_no_checked(object sender, EventArgs e)
        {
            Session["filterValue"] = "N";
            Session["sortType"] = "appN";
            table = AdminClass.getProductCatalog_by_SingleFilter
                (
                    0,
                    50,
                    lbl_product_type_name.Text,
                    "N",
                    "spAdminSortProductCatalogByApproveStatus"
                );
            setDataToGridview(0, 50, table);
        }

        private void prevNextButtonClick(int pageIndex)
        {
            ViewState["pageNo"] = pageIndex.ToString();
            gv_products_catlog.PageIndex = pageIndex;
            if (gv_products_catlog.PageIndex == 0)
            {
                btn_paging_prev.Enabled = false;
            }
            else
            {
                btn_paging_prev.Enabled = true;
            }

            //setDataToGridview(pageIndex, gv_products_catlog.PageSize, table);
            if (Session["sortType"] != null)
            {
                if (Session["sortType"].Equals("Id"))
                {
                    table = AdminClass.getProductCatalog_by_id_range_filter
                            (
                                pageIndex,
                                50,
                                lbl_product_type_name.Text,
                                Convert.ToInt32(Session["from"]),
                                Convert.ToInt32(Session["to"]),
                                "spAdminSortProductCatalogByIdRange"
                            );
                }
                else if (Session["sortType"].Equals("stock"))
                {
                    table = AdminClass.getProductCatalog_by_id_range_filter
                                               (
                                                   pageIndex,
                                                   50,
                                                   lbl_product_type_name.Text,
                                                   Convert.ToInt32(Session["from"]),
                                                   Convert.ToInt32(Session["to"]),
                                                   "spAdminSortProductCatalogByStockRange"
                                               );
                }
                else if (Session["sortType"].Equals("mrp"))
                {
                    table = AdminClass.getProductCatalog_by_id_range_filter
                            (
                                pageIndex,
                                50,
                                lbl_product_type_name.Text,
                                Convert.ToInt32(Session["from"]),
                                Convert.ToInt32(Session["to"]),
                                "spAdminSortProductCatalogByMRPRange"
                            );
                }
                else if (Session["sortType"].Equals("title"))
                {
                    table = AdminClass.getProductCatalog_by_SingleFilter
                        (
                            0,
                            50,
                            lbl_product_type_name.Text,
                            Session["filterValue"].ToString(),
                            "spAdminSortProductCatalogByTitle"
                        );
                }
                else if (Session["sortType"].Equals("sku"))
                {
                    table = AdminClass.getProductCatalog_by_SingleFilter
                        (
                            0,
                            50,
                            lbl_product_type_name.Text,
                            Session["filterValue"].ToString(),
                            "spAdminSortProductCatalogBySKU"
                        );
                }
                else if (Session["sortType"].Equals("appY"))
                {
                    table = AdminClass.getProductCatalog_by_SingleFilter
                        (
                            0,
                            50,
                            lbl_product_type_name.Text,
                            Session["filterValue"].ToString(),
                            "spAdminSortProductCatalogByApproveStatus"
                        );
                }
                else
                {
                    table = AdminClass.getProductCatalog_by_SingleFilter
                        (
                            0,
                            50,
                            lbl_product_type_name.Text,
                            Session["filterValue"].ToString(),
                            "spAdminSortProductCatalogByTitle"
                        );
                }

                //if (Session["filterValue"] != null)
                //{
                //    if (Session["filterValue"].Equals("Y"))
                //    {
                //        (gv_products_catlog.HeaderRow.FindControl("rb_yes") as RadioButton).Checked = true;
                //    }
                //    else
                //    {
                //        (gv_products_catlog.HeaderRow.FindControl("rb_no") as RadioButton).Checked = true;
                //    }
                //}
                setDataToGridview(pageIndex, gv_products_catlog.PageSize, table);
            }
            else
            {
                getMusicCatalog(gv_products_catlog.PageIndex, gv_products_catlog.PageSize, lbl_product_type_name.Text);
            }
        }

        protected void btn_reset_Click(object sender, EventArgs e)
        {            
            clearFiltertypeSessions();
            getMusicCatalog(gv_products_catlog.PageIndex, gv_products_catlog.PageSize, lbl_product_type_name.Text);
        }

        protected void gv_products_catlog_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gv_products_catlog.PageIndex = e.NewPageIndex;
            gv_products_catlog.DataBind();
        }
    }
}