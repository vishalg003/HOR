﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            DataTable dt = AdminClass.getLoginDetails(txt_id.Text, txt_pwd.Text);
            if (dt.Rows.Count != 0)
            {
                if (dt.Rows[0][0].ToString().Equals(txt_id.Text) && dt.Rows[0][1].ToString().Equals(txt_pwd.Text))
                {
                    Session["AdminID"] = dt.Rows[0][0].ToString();
                    Response.Redirect("Dashboard.aspx");
                }
                else
                    ClientMessageBox.Show("Incorrect Id or Password", this);
            }
        }
    }
}