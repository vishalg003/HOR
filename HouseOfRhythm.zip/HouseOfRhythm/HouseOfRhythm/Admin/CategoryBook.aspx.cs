﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;

namespace HouseOfRhythm.Admin
{
    public partial class CategoryBook : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_add_bok_cat_Click(object sender, EventArgs e)
        {
            int i = AdminProductClass.addCategory("spAdminInsertBookCategory", txt_book_category.Text);
            if (i > 0)
            {
                ClientMessageBox.Show("Book Category " + txt_book_category.Text + " added successfully", this);
            }
        }
    }
}