﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm.Admin
{
    public partial class SalesAhipment : System.Web.UI.Page
    {
        static DataSet table;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getMusicCatalog(gv_orderCatalog.PageIndex, gv_orderCatalog.PageSize);
            }
        }

        /* Method to bind data to Gridview with Manual Paging */
        /*******************************************************************************************/
        private void getMusicCatalog(int pageIndex, int pageSize)
        {
            table = AdminClass.getProductCatalog(pageIndex, pageSize, "Invoice");
            setDataToGridview(pageIndex, pageSize, table);
        }

        private void setDataToGridview(int pageIndex, int pageSize, DataSet table)
        {
            if (table.Tables[1].Rows.Count > 0)
            {
                int totalPages = Convert.ToInt32(table.Tables[1].Rows[0][0]) / pageSize;
                if (((int)(table.Tables[1].Rows[0][0]) % pageSize) != 0)
                {
                    totalPages += 1;
                }

                List<ListItem> pages = new List<ListItem>();
                if (totalPages > 1)
                {
                    for (int i = 1; i <= totalPages; i++)
                    {
                        pages.Add(new ListItem(i.ToString(), i.ToString(), i != (pageIndex + 1)));
                    }
                }
                gv_orderCatalog.DataSource = table.Tables[0];
                gv_orderCatalog.DataBind();
                repeaterPaging.DataSource = pages;
                repeaterPaging.DataBind();

                if (table.Tables[0].Rows.Count < pageSize)
                {
                    btn_paging_next.Enabled = false;
                }
                else
                {
                    btn_paging_next.Enabled = true;
                }
            }
        }

        /* Method to bind data to Gridview and Page number to button with Manual Paging */
        /*******************************************************************************************/
        protected void linkButton_Click(object sender, EventArgs e)
        {
            int pageIndex = int.Parse((sender as LinkButton).CommandArgument);
            pageIndex -= 1;
            prevNextButtonClick(pageIndex);
        }

        /* Method to bind data to Gridview with PREVIOUS button click */
        /*******************************************************************************************/
        protected void btn_paging_prev_Click(object sender, EventArgs e)
        {
            int pageIndex = Convert.ToInt32(ViewState["pageNo"]) - 1;
            prevNextButtonClick(pageIndex);
        }

        /* Method to bind data to Gridview with NEXT button click */
        /*******************************************************************************************/
        protected void btn_paging_next_Click(object sender, EventArgs e)
        {
            int pageIndex = Convert.ToInt32(ViewState["pageNo"]) + 1;
            prevNextButtonClick(pageIndex);
        }

        /* Filteration Method Section Starts */

        /* Method to filter table with Invoice ID Range Filter */
        /*******************************************************************************************/
        protected void invoice_IdRange_TextChanged(object sender, EventArgs e)
        {
            Session["from"] = Convert.ToInt32((gv_orderCatalog.HeaderRow.FindControl("txt_invoice_id_from") as TextBox).Text);
            Session["to"] = Convert.ToInt32((gv_orderCatalog.HeaderRow.FindControl("txt_invoice_id_to") as TextBox).Text);
            Session["sortType"] = "invoiceId";
            table = AdminClass.getProductCatalog_by_id_range_filter
                (
                    0,
                    12,
                    "Invoice",
                    Convert.ToInt32((gv_orderCatalog.HeaderRow.FindControl("txt_invoice_id_from") as TextBox).Text),
                    Convert.ToInt32((gv_orderCatalog.HeaderRow.FindControl("txt_invoice_id_to") as TextBox).Text),
                    "spAdminSortInvoiceCatalogByIdRange"
                );
            setDataToGridview(0, 12, table);
        }

        /* Method to filter table with Order ID Range Filter */
        /*******************************************************************************************/
        protected void IdRange_TextChanged(object sender, EventArgs e)
        {
            Session["from"] = Convert.ToInt32((gv_orderCatalog.HeaderRow.FindControl("txt_id_from") as TextBox).Text);
            Session["to"] = Convert.ToInt32((gv_orderCatalog.HeaderRow.FindControl("txt_id_to") as TextBox).Text);
            Session["sortType"] = "Id";
            table = AdminClass.getProductCatalog_by_id_range_filter
                (
                    0,
                    12,
                    "Order",
                    Convert.ToInt32((gv_orderCatalog.HeaderRow.FindControl("txt_id_from") as TextBox).Text),
                    Convert.ToInt32((gv_orderCatalog.HeaderRow.FindControl("txt_id_to") as TextBox).Text),
                    "spAdminSortInvoiceCatalogByIdRange"
                );
            setDataToGridview(0, 12, table);
        }

        /* Method to filter table with Order Date Range Filter */
        /*******************************************************************************************/
        protected void OrderDate_Range_TextChanged(object sender, EventArgs e)
        {
            if ((gv_orderCatalog.HeaderRow.FindControl("txt_from_date") as TextBox).Text.Equals("") ||
                (gv_orderCatalog.HeaderRow.FindControl("txt_to_date") as TextBox).Text.Equals(""))
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-times \"></i> Please enter <b > Values for both the boxes </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
            }
            else
            {
                Session["from"] = Convert.ToDateTime((gv_orderCatalog.HeaderRow.FindControl("txt_from_date") as TextBox).Text);
                Session["to"] = Convert.ToDateTime((gv_orderCatalog.HeaderRow.FindControl("txt_to_date") as TextBox).Text);
                Session["sortType"] = "date";
                table = AdminClass.getProductCatalog_by_DateRangeFilter
                    (
                        0,
                        12,
                        Convert.ToDateTime((gv_orderCatalog.HeaderRow.FindControl("txt_from_date") as TextBox).Text),
                        Convert.ToDateTime((gv_orderCatalog.HeaderRow.FindControl("txt_to_date") as TextBox).Text),
                        "spAdminSort_InvoiceCatalog_ByOrderDateRange"
                    );
                setDataToGridview(0, 12, table);
            }
        }

        /* Method to filter table with Invoice Date Range Filter */
        /*******************************************************************************************/
        protected void InvoiceDate_Range_TextChanged(object sender, EventArgs e)
        {
            if ((gv_orderCatalog.HeaderRow.FindControl("txt_invoice_from_date") as TextBox).Text.Equals("") ||
                (gv_orderCatalog.HeaderRow.FindControl("txt_invoice_to_date") as TextBox).Text.Equals(""))
            {
                lbl_alert.Text = "<i style=\"margin-right:5px;\" class=\"fa fa-times \"></i> Please enter <b > Values for both the boxes </b>";
                Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "alertMsg()", true);
            }
            else
            {
                Session["from"] = Convert.ToDateTime((gv_orderCatalog.HeaderRow.FindControl("txt_invoice_from_date") as TextBox).Text);
                Session["to"] = Convert.ToDateTime((gv_orderCatalog.HeaderRow.FindControl("txt_invoice_to_date") as TextBox).Text);
                Session["sortType"] = "Invoicedate";
                table = AdminClass.getProductCatalog_by_DateRangeFilter
                    (
                        0,
                        12,
                        Convert.ToDateTime((gv_orderCatalog.HeaderRow.FindControl("txt_invoice_from_date") as TextBox).Text),
                        Convert.ToDateTime((gv_orderCatalog.HeaderRow.FindControl("txt_invoice_to_date") as TextBox).Text),
                        "spAdminSort_InvoiceCatalog_ByDateRange"
                    );
                setDataToGridview(0, 12, table);
            }
        }

        /* Method to filter table with CUSTOMER NAME Filter */
        /*******************************************************************************************/
        protected void customerName_TextChanged(object sender, EventArgs e)
        {
            Session["filterValue"] = (gv_orderCatalog.HeaderRow.FindControl("txt_name") as TextBox).Text;
            Session["sortType"] = "name";
            table = AdminClass.getProductCatalog_by_SingleFilter
                    (
                        0,
                        12,
                        "Invoice",
                        (gv_orderCatalog.HeaderRow.FindControl("txt_name") as TextBox).Text,
                        "spAdminSort_OrderCatalog_ByCustomerName"
                    );
            setDataToGridview(0, 12, table);
        }

        /* Method to filter table with CUSTOMER NAME Filter */
        /*******************************************************************************************/
        protected void ddl_status_TextChanged(object sender, EventArgs e)
        {
            Session["filterValue"] = (gv_orderCatalog.HeaderRow.FindControl("ddl_product_type") as DropDownList).Text;
            Session["sortType"] = "status";
            table = AdminClass.getProductCatalog_by_SingleFilter
                    (
                        0,
                        12,
                        "",
                        (gv_orderCatalog.HeaderRow.FindControl("ddl_product_type") as DropDownList).SelectedValue,
                        "spAdminSort_InvoiceCatalog_ByOrder_Status"
                    );
            setDataToGridview(0, 12, table);
        }

        /* Filteration Method Section Ends */

        private void prevNextButtonClick(int pageIndex)
        {
            ViewState["pageNo"] = pageIndex.ToString();
            gv_orderCatalog.PageIndex = pageIndex;
            if (gv_orderCatalog.PageIndex == 0)
            {
                btn_paging_prev.Enabled = false;
            }
            else
            {
                btn_paging_prev.Enabled = true;
            }

            if (Session["sortType"] != null)
            {
                if (Session["sortType"].Equals("invoiceId"))
                {
                    table = AdminClass.getProductCatalog_by_id_range_filter
                    (
                        pageIndex,
                        12,
                        "Invoice",
                        Convert.ToInt32(Session["from"]),
                        Convert.ToInt32(Session["to"]),
                        "spAdminSortInvoiceCatalogByIdRange"
                    );
                }
                else if (Session["sortType"].Equals("Id"))
                {
                    table = AdminClass.getProductCatalog_by_id_range_filter
                    (
                        pageIndex,
                        12,
                        "Order",
                        Convert.ToInt32(Session["from"]),
                        Convert.ToInt32(Session["to"]),
                        "spAdminSortInvoiceCatalogByIdRange"
                    );
                }
                else if (Session["sortType"].Equals("date"))
                {
                    table = AdminClass.getProductCatalog_by_DateRangeFilter
                    (
                        pageIndex,
                        12,
                        Convert.ToDateTime(Session["from"]),
                        Convert.ToDateTime(Session["to"]),
                        "spAdminSort_InvoiceCatalog_ByOrderDateRange"
                    );
                }
                else if (Session["sortType"].Equals("Invoicedate"))
                {
                    table = AdminClass.getProductCatalog_by_DateRangeFilter
                    (
                        pageIndex,
                        12,
                        Convert.ToDateTime(Session["from"]),
                        Convert.ToDateTime(Session["to"]),
                        "spAdminSort_InvoiceCatalog_ByDateRange"
                    );
                }
                else if (Session["sortType"].Equals("name"))
                {
                    table = AdminClass.getProductCatalog_by_SingleFilter
                    (
                        pageIndex,
                        12,
                        "Invoice",
                        (gv_orderCatalog.HeaderRow.FindControl("txt_name") as TextBox).Text,
                        "spAdminSort_OrderCatalog_ByCustomerName"
                    );
                }
                else
                {
                    table = AdminClass.getProductCatalog_by_SingleFilter
                    (
                        pageIndex,
                        12,
                        "",
                        Session["filterValue"].ToString(),
                        "spAdminSort_InvoiceCatalog_ByOrder_Status"
                    );
                }
                setDataToGridview(pageIndex, gv_orderCatalog.PageSize, table);
            }

            else
            {
                getMusicCatalog(pageIndex, gv_orderCatalog.PageSize);
            }
        }

        /* Method to clear session variadle for other product type filters */
        /*******************************************************************************/
        private void clearFiltertypeSessions()
        {
            Session["from"] = Session["to"] = Session["filterType"] = Session["sortType"] = null;
            Session.Remove("from");
            Session.Remove("to");
            Session.Remove("filterType");
            Session.Remove("sortType");
        }

        protected void btn_reset_Click(object sender, EventArgs e)
        {
            clearFiltertypeSessions();
            getMusicCatalog(gv_orderCatalog.PageIndex, gv_orderCatalog.PageSize);
        }
    }
}