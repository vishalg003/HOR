﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayerHor;
using System.Data;

namespace HouseOfRhythm
{
    public partial class LowStockReport : System.Web.UI.Page
    {
        static DataSet table;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getSalesReport("spAdminGetLowStockReport", gv_low_stock_report.PageIndex, gv_low_stock_report.PageSize);
            }
        }

        private void getSalesReport(string procedure, int pIndex, int pSize)
        {
            table = AdminClass.getReports(procedure, pIndex, pSize);
            gv_low_stock_report.DataSource = table;
            gv_low_stock_report.DataBind();
            txt_page_no.Text = (pIndex + 1).ToString();
            ViewState["pageNo"] = pIndex;
            if (txt_page_no.Text.Equals("1"))
            {
                btn_paging_prev.Enabled = false;
                btn_paging_prev.ForeColor = System.Drawing.Color.Gray;
            }
            else
                btn_paging_prev.Enabled = true;

            if (table.Tables[0].Rows.Count < Convert.ToInt32(ddl_record_count.SelectedValue))
            {
                btn_paging_next.Enabled = false;
                btn_paging_next.ForeColor = System.Drawing.Color.Gray;
            }

            if (table.Tables[1].Rows.Count > 0)
            {
                int totalPages = Convert.ToInt32(table.Tables[1].Rows[0][0]) / pSize;
                if ((Convert.ToInt32(table.Tables[1].Rows[0][0]) % pSize) != 0)
                {
                    totalPages += 1;
                }

                lbl_page_no.Text = "Showing page <b style=\"color:#016bb5; font-size:16px\">" + txt_page_no.Text + "</b> of <b style=\"color:#016bb5; font-size:16px\">" + totalPages + "</b>";
            }            
        }

        protected void ddl_record_count_SelectedIndexChanged(object sender, EventArgs e)
        {
            getSalesReport("spAdminGetLowStockReport", gv_low_stock_report.PageIndex, Convert.ToInt32(ddl_record_count.SelectedValue));
        }

        protected void btn_prev_page_Click(object sender, EventArgs e)
        {
            ViewState["pageNo"] = (Convert.ToInt32(ViewState["pageNo"]) - 1).ToString();
            getSalesReport("spAdminGetLowStockReport", Convert.ToInt32(ViewState["pageNo"]), Convert.ToInt32(ddl_record_count.SelectedValue));

        }

        protected void btn_next_page_Click(object sender, EventArgs e)
        {
            ViewState["pageNo"] = (Convert.ToInt32(ViewState["pageNo"]) + 1).ToString();
            getSalesReport("spAdminGetLowStockReport", Convert.ToInt32(ViewState["pageNo"]), Convert.ToInt32(ddl_record_count.SelectedValue));
        }
        protected void btn_reset_filters_Click(object sender, EventArgs e)
        {
            getSalesReport("spAdminGetLowStockReport", gv_low_stock_report.PageIndex, gv_low_stock_report.PageSize);
            ddl_record_count.SelectedValue = gv_low_stock_report.PageSize.ToString();
        }

        protected void btn_export_Click(object sender, EventArgs e)
        {
            if (ddl_export.SelectedValue.Equals("Excel"))
            {
                // Clear all content output from the buffer stream
                Response.ClearContent();
                // Specify the default file name using "content-disposition" RESPONSE header
                Response.AppendHeader("content-disposition", "attachment; filename=StockReport" + DateTime.Now.ToString("dd/mm/yyyy") + ".xls");
                // Set excel as the HTTP MIME type
                Response.ContentType = "application/excel";
                // Create an instance of stringWriter for writing information to a string
                System.IO.StringWriter stringWriter = new System.IO.StringWriter();
                // Create an instance of HtmlTextWriter class for writing markup 
                // characters and text to an ASP.NET server control output stream
                HtmlTextWriter htw = new HtmlTextWriter(stringWriter);

                // Set white color as the background color for gridview header row
                //gv_low_stock_report.HeaderRow.Style.Add("background-color", "#FFFFFF");

                //// Set background color of each cell of GridView1 header row
                //foreach (TableCell tableCell in gv_low_stock_report.HeaderRow.Cells)
                //{
                //    tableCell.Style["background-color"] = "#A55129";
                //}

                //// Set background color of each cell of each data row of GridView1
                //foreach (GridViewRow gridViewRow in gv_low_stock_report.Rows)
                //{
                //    gridViewRow.BackColor = System.Drawing.Color.White;
                //    foreach (TableCell gridViewRowTableCell in gridViewRow.Cells)
                //    {
                //        gridViewRowTableCell.Style["background-color"] = "#FFF7E7";
                //    }
                //}

                gv_low_stock_report.RenderControl(htw);
                Response.Write(stringWriter.ToString());
                Response.End();
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
        }

        protected void gv_low_stock_report_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gv_low_stock_report.PageIndex = e.NewPageIndex;
            gv_low_stock_report.DataBind();
        }
    }
}