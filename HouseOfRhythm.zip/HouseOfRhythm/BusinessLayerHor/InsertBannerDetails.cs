﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using DataAccessLayer;
using System.Data;

namespace BusinessLayerHor
{
    public class InsertBannerDetails
    {
        public string _Title { get; set; }
        public string _imagePath { get; set; }
        public string _shortDescription { get; set; }
        public string _Page { get; set; }
        public string product_id { get; set; }
        public string product_type { get; set; }

        List<SqlParameter> paramList;
        CommonClass commonClass;
        DataTable dt;

        //Method To Insert Main Banner Details
        /* **********************************************************************************************/

        public DataTable fetchBannerImages()
        {
            commonClass = new CommonClass();
            dt = commonClass.getDetails("spAdminGetMainBannerImages");
            return dt;
        }

        //Method To Insert Main Banner Details
        /* **********************************************************************************************/

        public DataTable getBannerDetails()
        {
            commonClass = new CommonClass();
            dt = commonClass.getDetails("spGetMainBannerDetails");
            return dt;
        }

        //Method To Get Banner Details
        /* **********************************************************************************************/

        public DataTable SearchMainBannerDetails(string title)
        {
            commonClass = new CommonClass();
            dt = commonClass.SearchMainBannerDetails("spAdminSearchBanner", title);
            return dt;
        }
        //Method To Get Banner Details
        /* **********************************************************************************************/

        public DataTable SearchSingleBannerDetails(string title)
        {
            commonClass = new CommonClass();
            dt = commonClass.SearchMainBannerDetails("spAdminSearchSingleBanner", title);
            return dt;
        }

        //Method To Delete Banner Details
        /* **********************************************************************************************/

        public int DeleteMainBannerDetails(InsertBannerDetails insertBannerDetails)
        {
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@title",
                    Value = insertBannerDetails._Title
                });
            }
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminDeleteMainBanner", paramList);
            return i;
        }

        //Method To Delete Banner Details
        /* **********************************************************************************************/

        public int DeleteSingleBannerDetails(InsertBannerDetails insertBannerDetails)
        {
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@title",
                    Value = insertBannerDetails._Title
                });
            }
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminDeleteSingleBanner", paramList);
            return i;
        }

        //Method To Get Single Banner Details
        /* **********************************************************************************************/

        public DataTable getSinlgeBannerDetails(string pagename)
        {
            commonClass = new CommonClass();
            dt = commonClass.getSmallBannerList("spAdminGetSingleBannerDetails", pagename);
            return dt;
        }

        //Method To Insert Main Banner Details
        /* **********************************************************************************************/

        public int addMainBannerDetails(InsertBannerDetails insertBannerDetails)
        {
            paramList = getParamerterList(insertBannerDetails);
            commonClass = new CommonClass();
            int  i = commonClass.InsertData("spAdminAMainBannerDetails",paramList);
            return i;
        }

        public int updateMainBannerDetails(InsertBannerDetails insertBannerDetails)
        {
            paramList = getParamerterList(insertBannerDetails);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminUpdateMainBanner", paramList);
            return i;
        }

        //Method To Insert Main Banner Details
        /* **********************************************************************************************/

        public int addSmallBannerDetails(InsertBannerDetails insertBannerDetails)
        {
            paramList = getParamerterList(insertBannerDetails);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminASmallBannerDetails", paramList);
            return i;
        }

        //Method To Insert Single Banner Details
        /* **********************************************************************************************/

        public int addSingleBannerDetails(InsertBannerDetails insertBannerDetails)
        {
            paramList = fetchParamerterList(insertBannerDetails);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminInsertSingleBannerDetails", paramList);
            return i;
        }

        //Method To Update Single Banner Details
        /* **********************************************************************************************/

        public int updatesingleBannerDetails(InsertBannerDetails insertBannerDetails)
        {
            paramList = fetchParamerterList(insertBannerDetails);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminUpdateSingleBanner", paramList);
            return i;
        }

        //Method To get Parameter List
        /* **********************************************************************************************/

        private List<SqlParameter> getParamerterList(InsertBannerDetails insertBannerDetails)
        {
            try
            {
                List<SqlParameter> paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@title",
                        Value = insertBannerDetails._Title
                    });

                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@banner_image",
                        Value = insertBannerDetails._imagePath
                    });

                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@description",
                        Value = insertBannerDetails._shortDescription
                    });

                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@insertdate",
                        Value = DateTime.Now
                    });
                    paramList.Add(new SqlParameter { 
                        ParameterName="@product_id",
                        Value=insertBannerDetails.product_id
                    });
                    paramList.Add(new SqlParameter { 
                        ParameterName="@product_type",
                        Value=insertBannerDetails.product_type
                    });
                }

                return paramList;
            }
            catch (Exception)
            {
                
                throw;
            }
           
        }

        //Method To get Parameter List For Single Banner
        /* **********************************************************************************************/

        private List<SqlParameter> fetchParamerterList(InsertBannerDetails insertBannerDetails)
        {
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@title",
                    Value = insertBannerDetails._Title
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@banner_image",
                    Value = insertBannerDetails._imagePath
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@content",
                    Value = insertBannerDetails._shortDescription
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@create_date",
                    Value = DateTime.Now
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@page_name",
                    Value = insertBannerDetails._Page
                });
            }

            return paramList;
        }
    }
}
