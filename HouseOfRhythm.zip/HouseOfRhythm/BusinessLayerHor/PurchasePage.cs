﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DataAccessLayer;

namespace BusinessLayerHor
{
    public class PurchasePage
    {
        List<SqlParameter> paramList;
        DataTable table;
        CommonClass commonClass;
        public string _PurchseId { get; set; }
        public string _Dealer { get; set; }
        public string _invoiceID { get; set; }
        public string _Title { get; set; }
        public decimal _unitPrice { get; set; }
        public decimal _Subtotal { get; set; }
        public int _gstTax { get; set; }
        public string _HsnNo { get; set; }
        public decimal _discountAmount { get; set; }
        public decimal _discountPercent { get; set; }
        public decimal _TaxAmount { get; set; }
        public decimal _purchseAmount { get; set; }
        public int _Stock { get; set; }
        public string _orderedDate { get; set; }
        public string _arrivalDate { get; set; }
        public decimal _customerPrice { get; set; }
        public int _totalStock { get; set; }

        public int insertPurchase(PurchasePage purchasePage)
        {
            paramList = getParamList(purchasePage, "Insert");
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminInsertPurchaseDetails", paramList);
            return i;
        }

        public int updatePurchase(PurchasePage purchasePage)
        {
            paramList = getParamList(purchasePage, "Update");
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminUpdatePurchaseDetails", paramList);
            return i;
        }

        public DataTable getPurchaseDetailsById(string id)
        {
            commonClass = new CommonClass();
            paramList = new List<SqlParameter>();
            paramList.Add(new SqlParameter { 
                ParameterName = "@id",
                Value = id
            });
            table = commonClass.sortDetails("spAdminGetPurchaseDetailsByID", paramList);
            return table;
        }

        private List<SqlParameter> getParamList(PurchasePage purchasePage,  string action)
        {
            paramList = new List<SqlParameter>();
            paramList.Add(new SqlParameter
            {
                ParameterName = "@purchase_id",
                Value = purchasePage._PurchseId
            });
            paramList.Add(new SqlParameter
            {
                ParameterName = "@dealer_name",
                Value = purchasePage._Dealer
            });
            paramList.Add(new SqlParameter
            {
                ParameterName = "@invoice_id",
                Value = purchasePage._invoiceID 
            });

            paramList.Add(new SqlParameter
            {
                ParameterName = "@title",
                Value = purchasePage._Title
            });

            paramList.Add(new SqlParameter
            {
                ParameterName = "@unit_price",
                Value = purchasePage._unitPrice
            });
            paramList.Add(new SqlParameter
            {
                ParameterName = "@subtotal",
                Value = purchasePage._Subtotal
            });
            paramList.Add(new SqlParameter
            {
                ParameterName = "@gst_tax",
                Value = purchasePage._gstTax
            });

            paramList.Add(new SqlParameter
            {
                ParameterName = "@hsn_no",
                Value = purchasePage._HsnNo
            });

            paramList.Add(new SqlParameter
            {
                ParameterName = "@tax_amount",
                Value = purchasePage._TaxAmount
            });

            paramList.Add(new SqlParameter
            {
                ParameterName = "@purchase_amount",
                Value = purchasePage._purchseAmount
            });
            paramList.Add(new SqlParameter
            {
                ParameterName = "@stock",
                Value = purchasePage._Stock
            });
            paramList.Add(new SqlParameter
            {
                ParameterName = "@ordered_date",
                Value = purchasePage._orderedDate  
            });
            paramList.Add(new SqlParameter
            {
                ParameterName = "@arrival_date",
                Value = purchasePage._arrivalDate
            });
            paramList.Add(new SqlParameter
            {
                ParameterName = "@customer_mrp",
                Value = purchasePage._customerPrice
            });
            if (action.Equals("Insert"))
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@entry_date",
                    Value = DateTime.Now
                });
            }
            paramList.Add(new SqlParameter
            {
                ParameterName = "@update_date",
                Value = DateTime.Now
            });
            paramList.Add(new SqlParameter
            {
                ParameterName = "@discount_percent",
                Value = purchasePage._discountPercent
            });
            paramList.Add(new SqlParameter
            {
                ParameterName = "@discount_amt",
                Value = purchasePage._discountAmount
            });

            return paramList;
        }
    }
}
