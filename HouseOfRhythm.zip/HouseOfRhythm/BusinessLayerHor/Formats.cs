﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccessLayer;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayerHor
{
    public class Formats
    {
        public static int insertFromat(string type)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> param = new List<SqlParameter>();

            param.Add(new SqlParameter() { 
                ParameterName = "@type",
                Value = type
            });

            int i = commonClass.InsertData("spAdminInsertFormatDetails", param);
            return i;
        }

        public static int updateFromat(string type, int id)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> param = new List<SqlParameter>();

            param.Add(new SqlParameter()
            {
                ParameterName = "@id",
                Value = id
            });
            param.Add(new SqlParameter()
            {
                ParameterName = "@type",
                Value = type
            });
            int i = commonClass.InsertData("spAdminUpdateFormatDetails", param);
            return i;
        }

        public static DataTable getFromat()
        {
            CommonClass commonClass = new CommonClass();
            DataTable dt = commonClass.getDetails("spAdminGetFormatList");
            return dt;
        }

        public static DataTable getFromatById(int id)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter()
            {
                ParameterName = "@id",
                Value = id
            });
            DataTable dt = commonClass.sortDetails("spAdminGetFormatListById", param);
            return dt;
        }
    }
}
