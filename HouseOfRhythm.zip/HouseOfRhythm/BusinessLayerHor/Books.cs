﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using DataAccessLayer;
using BusinessObject;
using System.Data;

namespace BusinessLayerHor
{
   public class Books
    {

        CommonClass commonClass;
        List<SqlParameter> paramList;
        public int insertUpdateBook(BookObject bookobject)
        {
            paramList = addParameters(bookobject);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminInsertBookDetails", paramList);
            return i;
        }
        public int updateBookDetails(BookObject bookobject)
        {
            paramList = updateParameters(bookobject);
            commonClass = new CommonClass();
            int i = commonClass.UpdateData("spAdminUpdateBookDetails", paramList);
            return i;
        }

        public DataTable getBookDetails(string id)
        {
            commonClass = new CommonClass();
            DataTable dt;
            dt = commonClass.getRecordsBySearchValue("spAdminGetBookDetail", id);
            return dt;
        }
       

        private List<SqlParameter> addParameters(BookObject bookobject)
        {
            paramList = new List<SqlParameter>();
            try
            {
                
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@book_id",
                        Value = bookobject._book_id
                    });

                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@title",
                        Value = bookobject._book_title
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName ="@author_name",
                        Value = bookobject._author_name
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@publisher_name",
                        Value = bookobject._publisher_name
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@isbn_no",
                        Value = bookobject._isbn_no
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@pages",
                        Value = bookobject._no_of_pages
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@size",
                        Value = bookobject._size
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@publish_date",
                        Value = bookobject._publish_date
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@mrp",
                        Value = bookobject._mrp
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@main_image",
                        Value = bookobject._main_image
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@thumbnail_image",
                        Value = bookobject._thumbnail_image
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@sku",
                        Value = bookobject._sku
                    });
                   
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@description",
                        Value = bookobject._description
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@discount",
                        Value = bookobject._discount
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@category",
                        Value = bookobject._cartegory
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@stock",
                        Value = bookobject._Stock
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@type",
                        Value = bookobject._type
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@new_arrival",
                        Value = bookobject._new_arrival
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@featured_product",
                        Value = bookobject._featured_product
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@best_seller",
                        Value = bookobject._best_seller
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@sale",
                        Value = bookobject._Sale
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@approved",
                        Value = bookobject._approved
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@create_date",
                        Value = DateTime.Now
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@modified_date",
                        Value = bookobject._modifyDate
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@from_date",
                        Value = bookobject._fromDate
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@to_date",
                        Value = bookobject._toDate
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@pre_order",
                        Value = bookobject._PreOrder
                    });
                    //if ("asdads" == "asdsada")
                    //{
                    //    paramList.Add(new SqlParameter
                    //    {
                    //        ParameterName = "@to_date",
                    //        Value = bookobject._toDate
                    //    });
                    //}
            }
            catch (Exception)
            {

                throw;
            }
            return paramList;
        }

        private List<SqlParameter> updateParameters(BookObject bookobject)
        {
            try
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@book_id",
                        Value = bookobject._book_id
                    });

                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@title",
                        Value = bookobject._book_title
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@author_name",
                        Value = bookobject._author_name
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@publisher_name",
                        Value = bookobject._publisher_name
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@isbn_no",
                        Value = bookobject._isbn_no
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@pages",
                        Value = bookobject._no_of_pages
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@size",
                        Value = bookobject._size
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@publish_date",
                        Value = bookobject._publish_date
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@mrp",
                        Value = bookobject._mrp
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@main_image",
                        Value = bookobject._main_image
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@thumbnail_image",
                        Value = bookobject._thumbnail_image
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@sku",
                        Value = bookobject._sku
                    });

                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@description",
                        Value = bookobject._description
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@discount",
                        Value = bookobject._discount
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@category",
                        Value = bookobject._cartegory
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@stock",
                        Value = bookobject._Stock
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@type",
                        Value = bookobject._type
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@new_arrival",
                        Value = bookobject._new_arrival
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@featured_product",
                        Value = bookobject._featured_product
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@best_seller",
                        Value = bookobject._best_seller
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@sale",
                        Value = bookobject._Sale
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@approved",
                        Value = bookobject._approved
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@modified_date",
                        Value = bookobject._modifyDate
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@from_date",
                        Value = bookobject._fromDate
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@to_date",
                        Value = bookobject._toDate
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@pre_order",
                        Value = bookobject._PreOrder
                    });
                }

                return paramList;
            }
            catch (Exception)
            {
                
                throw;
            }
        }
    }
}
