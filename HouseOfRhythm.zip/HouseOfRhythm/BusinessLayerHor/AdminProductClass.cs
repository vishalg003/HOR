﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccessLayer;
using BusinessObject;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayerHor
{
    public class AdminProductClass
    {
        /* Mehtod To Get Music/Movie/Book/Product Detail By Id*/
        /* ******************************************************** */
        public static DataTable getProductById(string Id, string prodType)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter() {
                    ParameterName = "@id",
                    Value = Id
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@type",
                    Value = prodType
                });
            }

            DataTable table = commonClass.sortDetails("spAdminGetProductDetailsById", paramList);
            return table;
        }

        /* Mehtod To Get Reports For Admin Dashboard */
        /* ******************************************************** */
        public static DataSet getDataRecord(string procedure)
        {
            CommonClass commonClass = new CommonClass();
            DataSet table = commonClass.fetchMultipleData(procedure);
            return table;
        }

        /* Mehtod To Get Music Category for Insert Update*/
        /* ******************************************************** */
        public static DataTable getMusicCategory(string procedure, string searchTerm, string origin, string media)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@searchTerm",
                    Value = searchTerm
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@origin",
                    Value = origin
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@media",
                    Value = media
                });

                DataTable table = commonClass.sortDetails(procedure, paramList);
                return table;
            }
        }

        /* Mehtod To Get Movie/Book/Product Category for Insert Update*/
        /* ******************************************************** */
        public static DataTable getProductCategory(string procedure, string searchTerm)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@searchTerm",
                    Value = searchTerm
                });

                DataTable table = commonClass.sortDetails(procedure, paramList);
                return table;
            }
        }


        /* Mehtod To Get Order Details By ID */
        /* ******************************************************** */
        public static DataSet getOrderDetails(string id)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@searchTerm",
                    Value = id
                });

                DataSet ds = commonClass.getDetailsBySearchValue("spAdminGetCustomerAndOrderDetails", paramList);
                return ds;
            }
        }

        /* Mehtod To Get Customer Address Details for Orders Details Page */
        /* ******************************************************** */
        public static DataTable getCustomerAddress(string id, string email)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@id",
                    Value = id
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@email",
                    Value = email
                });

                DataTable dt = commonClass.sortDetails("spAdminGetCustomerAddressDetails", paramList);
                return dt;
            }
        }

        /* Mehtod To Add Music Category */
        /* ******************************************************** */
        public static int addMusicCategory(string media, string origin, string category)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@media",
                    Value = media
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@origin",
                    Value = origin
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@category",
                    Value = category
                });

                int i = commonClass.InsertData("spAdminInsertMusicCategory", paramList);
                return i;
            }
        }

        /* Mehtod To Add Music List By Range Slider */
        /* ******************************************************** */
        public static DataTable productByRangeSlider(int val1, int val2, int pIndex, int pSize, string type)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@PageIndex",
                    Value = pIndex
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@PageSize",
                    Value = pSize
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@type",
                    Value = type
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@val1",
                    Value = val1
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@val2",
                    Value = val2
                });

                DataTable dt = commonClass.sortDetails("spAdminGetProductByRangeSlider", paramList);
                return dt;
            }
        }

        /* Mehtod To Add Movie/Book/Products Category */
        /* ******************************************************** */
        public static int addCategory(string procedure, string category)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@category",
                    Value = category
                });

                int i = commonClass.InsertData(procedure, paramList);
                return i;
            }
        }

        /* Mehtod To Change Order Status While Processing */
        /* ******************************************************** */
        public static int changeOrderStatus(string Id, string value, string notify, string comment)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@order_id",
                    Value = Id
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@status",
                    Value = value
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@notify",
                    Value = notify
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@comment_date",
                    Value = DateTime.Now
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@comment",
                    Value = comment
                });

                int i = commonClass.InsertData("spAdminChangeStatus_ForOrder", paramList);
                return i;
            }
        }

        /* Mehtod To Change Order Status While Processing and insert Invoice, Shipment, Credit Memo Details */
        /* ******************************************************** */
        public static int insertProcessingDetails(string Id, string value, string value2, string notify, string comment, string id, string procedure)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@order_id",
                    Value = Id
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@value",
                    Value = value
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@status",
                    Value = value2
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@notify",
                    Value = notify
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@comment_date",
                    Value = DateTime.Now
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@comment",
                    Value = comment
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@invoiceid",
                    Value = id
                });

                int i = commonClass.InsertData(procedure, paramList);
                return i;
            }
        }

        /* Mehtod To Update Customer Address Info for Customer Details Page */
        /* ******************************************************** */
        public static int updateCustomerAddress(string email, string type, string adress, string country, string state, string city, string locality, string pincode)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@type",
                    Value = type
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@address",
                    Value = adress
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@country",
                    Value = country
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@state",
                    Value = state
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@city",
                    Value = city
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@locality",
                    Value = locality
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@pincode",
                    Value = pincode
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@id",
                    Value = email
                });

                int i = commonClass.InsertData("spAdminUpdateCustomerAddress_FromCustomerDetailsPage", paramList);
                return i;
            }
        }

        /* Mehtod To Update Customer Address Info for Order Details Page */
        /* ******************************************************** */
        public static int updateCustomerAddressForOrder(string id, string type, string adress, string country, string state, string city, string locality, string pincode, string mobile_no)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@type",
                    Value = type
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@address",
                    Value = adress
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@country",
                    Value = country
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@state",
                    Value = state
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@city",
                    Value = city
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@locality",
                    Value = locality
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@pincode",
                    Value = pincode
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@id",
                    Value = id
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@mobile_no",
                    Value = mobile_no
                });


                int i = commonClass.InsertData("spAdminUpdateCustomerAddress_FromOrderDetailsPage", paramList);
                return i;
            }
        }

        /* Mehtod To Update Customer Info */
        /* ******************************************************** */
        public static int updateCustomerInfo(string fname, string lname, string email, string mob1, string mob2)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@fname",
                    Value = fname
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@lname",
                    Value = lname
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@email",
                    Value = email
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@mob1",
                    Value = mob1
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@mob2",
                    Value = mob2
                });
                int i = commonClass.InsertData("spAdminUpdateCustomerInformtion", paramList);
                return i;
            }
        }
    }
}
