﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DataAccessLayer;
using BusinessObject;

namespace BusinessLayerHor
{
    public class CartClass
    {
        CommonClass commonClass;
        List<SqlParameter> paramList;
        DataTable dt;
        DataSet ds;

        public string _cart_id { get; set; }
        public string order_id { get; set; }
        public string _product_id { get; set; }
        public string _quantity { get; set; }
        public decimal _subtotal { get; set; }
        public string _email { get; set; }
        public decimal _delivery_charges { get; set; }
        public decimal _total_amount { get; set; }
        public decimal _cart_subtotal { get; set; }
        public decimal _tax { get; set; }
        public string _product_title { get; set; }
        public string _product_image { get; set; }
        public decimal _product_mrp { get; set; }
        public string _order_date { get; set; }
        public string _order_status { get; set; }
        public string _delivery_date { get; set; }
        public string _shipping_address { get; set; }
        public string _billing_address { get; set; }
        public string _name { get; set; }
        public string _country { get; set; }
        public string _state { get; set; }
        public string _city { get; set; }
        public string _locality { get; set; }
        public string _pincode { get; set; }
        public string _payment_type { get; set; }
        public string _mobile_no { get; set; }
        public int stock { get; set; }
        public decimal _original_price { get; set; }

        public int insertCartDetails(CartClass cart)
        {
            paramList = addcartParameters(cart);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spInsertCartDetails", paramList);
            return i;
        }
        public int insertOrderDetails(CartClass cart)
        {
            paramList = addorderParameters(cart);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spInsertOrderDetails", paramList);
            return i;
        }
        public int insertCartProductDetails(CartClass cart)
        {
            paramList = addParameters(cart);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spInsertCartProductDetails", paramList);
            return i;
        }

        public int insertOrderProductDetails(CartClass cart)
        {
            paramList = addOrderProductParameters(cart);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spInsertOrderProductDetails", paramList);
            return i;
        }

        public int updateStockAfterOrder(CartClass cart)
        {
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@product_id",
                    Value = cart._product_id
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@stock",
                    Value = cart.stock
                });
            }
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spupdateStock", paramList);
            return i;
        }

        public int updateOrderTable(CartClass cart)
        {
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@order_id",
                    Value = cart.order_id
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@total_amount",
                    Value = cart._total_amount
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@subtotal",
                    Value = cart._cart_subtotal
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@delivery_charges",
                    Value = cart._delivery_charges
                });
            }
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spUpdateOrder", paramList);
            return i;
        }
        public int DeleteProductFromCart(CartClass cart)
        {
            paramList = addParameterToDelete(cart);
            commonClass = new CommonClass();
            int i = commonClass.DeleteProductFromCart("spDeleteProductFromCart",paramList);
            return i;
        }
        public DataSet GetCartDetailsForDisplay(string email)
        {
            commonClass = new CommonClass();
            ds = commonClass.getCartDetails("spgetCartDetails", email);
            return ds;
        }

        public DataSet GetOrderDetailsForDisplay(string order_id)
        {
            commonClass = new CommonClass();
            ds = commonClass.getOrderDetails("spgetOrderComplete", order_id);
            return ds;
        }
        public DataSet getOrderDetails(string order_id)
        {
            commonClass = new CommonClass();
            ds = commonClass.getSpecificOrderDetails("spgetspecificOrderDetails", order_id);
            return ds;
        }
        public DataSet getstockDetails(string product_id)
        {
            commonClass = new CommonClass();
                ds = commonClass.getStockDetails("spcheckStock", product_id);
            return ds;
        }
        public DataTable getCartId(string email)
        {
            try
            {
                commonClass = new CommonClass();
                dt = commonClass.getCartID("spGetCartId",email);
                return dt;
            }
            catch (Exception)
            {
                throw;
            }
        }



        public DataTable getOrderDetailsForUpdate(string order_id)
        {
            try
            {
                commonClass = new CommonClass();
                dt = commonClass.getOrderDetailsforUpdate("spgetOrderDetailsForUpdate", order_id);
                return dt;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public DataTable getCartDetailForUpdate(string email)
        {
            try
            {
                commonClass = new CommonClass();
                dt = commonClass.getCartDetailsforUpdate("spGetCartDetailsForUpdate", email);
                return dt;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DataTable getUserDetailsForCheckout(string email)
        {
            try
            {
                commonClass = new CommonClass();
                dt = commonClass.getCartDetailsforUpdate("spgetUserDetailsforCheckout", email);
                return dt;
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        public DataTable CheckProductInCart(string email,string product_id)
        {
            try
            {
                commonClass = new CommonClass();
                dt = commonClass.CheckProductIn_Cart("spCheckProductInCart", email,product_id);
                return dt;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public int updateCartProductDetails(CartClass cart)
        {
            paramList = addcartParameterstoUpdate(cart);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spupdateCartTable", paramList);
            return i;
        }

        public int updateCartProductTable(CartClass cart)
        {
            paramList = addParameterstoUpdate(cart);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spUpdateCartProduct", paramList);
            return i;
        }

        private List<SqlParameter> addParameterToDelete(CartClass cart)
        {
            try
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@product_id",
                        Value = cart._product_id
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@email",
                        Value = cart._email
                    });
                }
                return paramList;
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        public DataTable getCountries()
        {
            try
            {
                commonClass = new CommonClass();
                dt = commonClass.getDetails("spgetCountries");
                return dt;
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        public DataTable getStates(int id)
        {
            try
            {
                commonClass = new CommonClass();
                dt = commonClass.getState("spgetState",id);
                return dt;
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        public DataTable getCities(int id)
        {
            try
            {
                commonClass = new CommonClass();
                dt = commonClass.getState("spgetCities", id);
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private List<SqlParameter> addParameters(CartClass cart)
        {
            try
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@cart_id",
                        Value = cart._cart_id
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@product_id",
                        Value = cart._product_id
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@quantity",
                        Value = cart._quantity
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@subtotal",
                        Value = cart._subtotal
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@email",
                        Value = cart._email
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@product_title",
                        Value = cart._product_title
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@product_image",
                        Value = cart._product_image
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@product_mrp",
                        Value = cart._product_mrp
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@orignal_amount",
                        Value = cart._original_price
                    });
                }
                return paramList;
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        private List<SqlParameter> addOrderProductParameters(CartClass cart)
        {
            try
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@order_id",
                        Value = cart.order_id
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@product_id",
                        Value = cart._product_id
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@quantity",
                        Value = cart._quantity
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@subtotal",
                        Value = cart._subtotal
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@email",
                        Value = cart._email
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@product_title",
                        Value = cart._product_title
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@product_image",
                        Value = cart._product_image
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@product_mrp",
                        Value = cart._product_mrp
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@orignal_price",
                        Value = cart._original_price
                    });
                }
                return paramList;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private List<SqlParameter> addParameterstoUpdate(CartClass cart)
        {
            try
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@cart_id",
                        Value = cart._cart_id
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@product_id",
                        Value = cart._product_id
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@quantity",
                        Value = cart._quantity
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@subtotal",
                        Value = cart._subtotal
                    });
                   
                }
                return paramList;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private List<SqlParameter> addcartParameters(CartClass cart)
        {
            try
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@cart_id",
                        Value = cart._cart_id
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@email",
                        Value = cart._email
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@delivery_charges",
                        Value = cart._delivery_charges
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@total_amount",
                        Value = cart._total_amount
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@subtotal",
                        Value = cart._cart_subtotal
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@country",
                        Value = cart._country
                    });
                }
                return paramList;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private List<SqlParameter> addorderParameters(CartClass cart)
        {
            try
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@order_id",
                        Value = cart.order_id
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@email",
                        Value = cart._email
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@total_amount",
                        Value = cart._total_amount
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@subtotal",
                        Value = cart._cart_subtotal
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@order_date",
                        Value = cart._order_date
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@shipping_address",
                        Value = cart._shipping_address
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@country",
                        Value = cart._country
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@state",
                        Value = cart._state
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@city",
                        Value = cart._city
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@locality",
                        Value = cart._locality
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@pincode",
                        Value = cart._pincode
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@mobile_no",
                        Value = cart._mobile_no
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@name",
                        Value = cart._name
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@payment_type",
                        Value = cart._payment_type
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@order_status",
                        Value = cart._order_status
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@delivery_charges",
                        Value = cart._delivery_charges
                    });
                }
                return paramList;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private List<SqlParameter> addcartParameterstoUpdate(CartClass cart)
        {
            try
            {
                paramList = new List<SqlParameter>();
                {
                   
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@email",
                        Value = cart._email
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@delivery_charges",
                        Value = cart._delivery_charges
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@total_amount",
                        Value = cart._total_amount
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@subtotal",
                        Value = cart._cart_subtotal
                    });
                }
                return paramList;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
