﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DataAccessLayer;
namespace BusinessLayerHor
{
   public class Advertisement
    {
       CommonClass commonClass;
       DataTable dt;
       List<SqlParameter> paramList;
       public string advertisement_id { get; set; }
       public string comapny_name { get; set; }
       public string website_address { get; set; }
       public string ad_image { get; set; }
       public char display { get; set; }

       public int insertAdvertisement()
       {
           try
           {
               paramList = new List<SqlParameter>();
               paramList.Add(new SqlParameter
               {
                   ParameterName = "@advertisement_id",
                   Value = advertisement_id
               });
               paramList.Add(new SqlParameter { 
                    ParameterName="@company_name",
                    Value=comapny_name
               });
               paramList.Add(new SqlParameter
               {
                   ParameterName = "@website_address",
                   Value = website_address
               });
               paramList.Add(new SqlParameter
               {
                   ParameterName = "@ad_image",
                   Value = ad_image
               });
               paramList.Add(new SqlParameter
               {
                   ParameterName = "@display",
                   Value =display
               });

               commonClass = new CommonClass();
               int i = commonClass.InsertData("spAdminInsertAdvertisement", paramList);
               return i;
           }
           catch (Exception)
           {
               
               throw;
           }
       }

       public int updateAdvertise()
       {
           try
           {
               paramList = new List<SqlParameter>();
               paramList.Add(new SqlParameter
               {
                   ParameterName = "@advertisement_id",
                   Value = advertisement_id
               });
               paramList.Add(new SqlParameter
               {
                   ParameterName = "@company_name",
                   Value = comapny_name
               });
               paramList.Add(new SqlParameter
               {
                   ParameterName = "@website_address",
                   Value = website_address
               });
               paramList.Add(new SqlParameter
               {
                   ParameterName = "@ad_image",
                   Value = ad_image
               });
               paramList.Add(new SqlParameter
               {
                   ParameterName = "@display",
                   Value = display
               });
               commonClass = new CommonClass();
               int i = commonClass.InsertData("spupdateAdvertise", paramList);
               return i;
           }
           catch (Exception)
           {
               
               throw;
           }
       }

       public int deleteAdvertise()
       {
           try
           {
               paramList = new List<SqlParameter>();
               paramList.Add(new SqlParameter { 
                    ParameterName="@advertisement_id",
                    Value=advertisement_id
               });

               commonClass = new CommonClass();
               int i = commonClass.InsertData("spAdminDeleteAdvertise", paramList);
               return i;
           }
           catch (Exception)
           {
               
               throw;
           }
       }
       public DataTable getAdvertisement()
       {
           try
           {
               commonClass = new CommonClass();
               dt = commonClass.getDetails("spgetAdvertisement");
               return dt;
           }
           catch (Exception)
           {
               
               throw;
           }
       }

       public DataTable searchAdvertisement(string company_name1)
       {
           try
           {
               
               commonClass = new CommonClass();
               dt = commonClass.getAdvertisement("spSearchAdvertisement", company_name1);
               return dt;
           }
           catch (Exception)
           {

               throw;
           }
       }

    }
}
