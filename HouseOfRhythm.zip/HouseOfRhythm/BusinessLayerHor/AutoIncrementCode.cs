﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using DataAccessLayer;
using System.Text.RegularExpressions;

namespace BusinessLayerHor
{
    public class AutoIncrementCode
    {        
        public static string get_Musiccode(string procedure)
        {
            string code = CommonClass.getCode(procedure);
            if (code == "")
            {
                code = "100000001";
            }
            else
            {
                code = (Convert.ToInt32(code) + 1).ToString(); ; 
            }
            return code;
        }

        public static string get_Moviecode(string procedure)
        {
            string code = CommonClass.getCode(procedure);
            if (code == "")
            {
                code = "200000001";
            }
            else
            {
                code = (Convert.ToInt32(code) + 1).ToString(); ;
            }
            return code;
        }

        public static string get_Bookcode(string procedure)
        {
            string code = CommonClass.getCode(procedure);
            if (code == "")
            {
                code = "300000001";
            }
            else
            {
                code = (Convert.ToInt32(code) + 1).ToString(); ;
            }
            return code;
        }

        public static string get_Productcode(string procedure)
        {
            string code = CommonClass.getCode(procedure);
            if (code == "")
            {
                code = "400000001";
            }
            else
            {
                code = (Convert.ToInt32(code) + 1).ToString(); ;
            }
            return code;
        }

        public static string get_Usercode(string procedure)
        {
            string code = CommonClass.getCode(procedure);
            if (code == "")
            {
                code = "500000001";
            }
            else
            {
                code = (Convert.ToInt32(code) + 1).ToString(); ;
            }
            return code;
        }

        public static string get_CartId(string procedure)
        {
            string code = CommonClass.getCode(procedure);
            if (code == "")
            {
                code = "600000001";
            }
            else
            {
                code = (Convert.ToInt32(code) + 1).ToString(); ;
            }
            return code;
        }

        public static string get_order_Id()
        {
            string code = CommonClass.getCode("spAutoIncrementOrderId");
            if (code == "")
            {
                code = "700000001";
            }
            else
            {
                code = (Convert.ToInt32(code) + 1).ToString(); ;
            }
            return code;
        }

        public static string get_invoice_Id()
        {
            string code = CommonClass.getCode("spAutoIncrementInvoiceId");
            if (code == "")
            {
                code = "800000001";
            }
            else
            {
                code = (Convert.ToInt32(code) + 1).ToString(); ;
            }
            return code;
        }

        public static string get_purchase_Id()
        {
            string code = CommonClass.getCode("spAutoIncrementPurchaseCode");
            if (code == "")
            {
                code = "900000001";
            }
            else
            {
                code = (Convert.ToInt32(code) + 1).ToString(); ;
            }
            return code;
        }
        public static string get_Advertisement_Id()
        {
            string code = CommonClass.getCode("getAdvertisementID");
            if (code == "")
            {
                code = "900000001";
            }
            else
            {
                code = (Convert.ToInt32(code) + 1).ToString(); ;
            }
            return code;
        }
    }
}
