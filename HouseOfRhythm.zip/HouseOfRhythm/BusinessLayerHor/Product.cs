﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using DataAccessLayer;
using BusinessObject;

namespace BusinessLayerHor
{
    public class Product
    {
        CommonClass commonClass;
        List<SqlParameter> paramList;        

        /* Method to add product details */
        /***********************************************************************/
        public int addDetails(ProductObject productObject)
        {
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@product_id",
                    Value = productObject._Id
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@title",
                    Value = productObject._Title
                });
               
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@category",
                    Value = productObject._Category
                });
                
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@barcode",
                    Value = productObject._barcode
                });
                
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@mrp",
                    Value = productObject._Mrp
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@discount",
                    Value = productObject._Discount
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@stock",
                    Value = productObject._stock
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@thumbnail_image",
                    Value = productObject._thumbnailImage
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@main_image",
                    Value = productObject._mainImage
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@short_description",
                    Value = productObject._shortDescp
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@long_description",
                    Value = productObject._longDescp
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@type",
                    Value = "Product"
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@featured_product",
                    Value = productObject._featuredProduct
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@best_seller",
                    Value = productObject._bestSeller
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@new_arrival",
                    Value = productObject._newArrival
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@approved",
                    Value = 'N'
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@sale",
                    Value = 'N'
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@weight",
                    Value = productObject._Weight
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@modified_date",
                    Value = productObject._modifiedDate
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@from_date",
                    Value = productObject._fromDate
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@to_date",
                    Value = productObject._toDate
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@create_date",
                    Value = DateTime.Now
                });
            }
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminInsertProductsDetails", paramList);
            return i;
        }

        /* Method to update product details */
        /***********************************************************************/
        public int updateDetails(ProductObject productObject)
        {
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@product_id",
                    Value = productObject._Id
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@title",
                    Value = productObject._Title
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@category",
                    Value = productObject._Category
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@barcode",
                    Value = productObject._barcode
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@mrp",
                    Value = productObject._Mrp
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@discount",
                    Value = productObject._Discount
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@stock",
                    Value = productObject._stock
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@thumbnail_image",
                    Value = productObject._thumbnailImage
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@main_image",
                    Value = productObject._mainImage
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@short_description",
                    Value = productObject._shortDescp
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@long_description",
                    Value = productObject._longDescp
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@type",
                    Value = "Product"
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@featured_product",
                    Value = productObject._featuredProduct
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@best_seller",
                    Value = productObject._bestSeller
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@new_arrival",
                    Value = productObject._newArrival
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@approved",
                    Value = 'N'
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@sale",
                    Value = 'N'
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@weight",
                    Value = productObject._Weight
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@modified_date",
                    Value = productObject._modifiedDate
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@from_date",
                    Value = productObject._fromDate
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@to_date",
                    Value = productObject._toDate
                });
            }
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminUpdateProductDetails", paramList);
            return i;
        }
    }

}
