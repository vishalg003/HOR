﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccessLayer;
using BusinessObject;
using System.Data.SqlClient;
using System.Data;

namespace BusinessLayerHor
{
    public class Movies
    {
        CommonClass commonClass;
        List<SqlParameter> paramList;

        public int insertUpdateMovies(MoviesObject Movieobject)
        {
            paramList = addParameters(Movieobject);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminInsertMovieDetail", paramList);
            return i;
        }

        public int updateMovies(MoviesObject Movieobject)
        {
            paramList = updateParameters(Movieobject);
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminUpdateMovieDetails", paramList);
            return i;
        }
        public DataTable getMovieDetails(string id)
        {
            commonClass = new CommonClass();
            Movies movie = new Movies();
            DataTable dt;
            dt = commonClass.getRecordsBySearchValue("spgetMovieDetails", id);
            return dt;
        }

       
        private List<SqlParameter> addParameters(MoviesObject Movieobject)
        {
            try
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@movie_id",
                        Value = Movieobject._Id
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@title",
                        Value = Movieobject._Title
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@actor",
                        Value = Movieobject._Actor
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@actress",
                        Value = Movieobject._Actress
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@director",
                        Value = Movieobject._Director
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@producer",
                        Value = Movieobject._Producer
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@composer",
                        Value = Movieobject._Composer
                    });
                    
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@genre",
                        Value = Movieobject._Genre
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@realease_year",
                        Value = Movieobject._realeaseYear
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@subtitle",
                        Value = Movieobject._Subtitle
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@format",
                        Value = Movieobject._Format
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@catlog_no",
                        Value = Movieobject._catalogNo
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@sku",
                        Value = Movieobject._Sku
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@barcode_no",
                        Value = Movieobject._barcodeNo
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@label",
                        Value = Movieobject._Label
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@no_of_disc",
                        Value = Movieobject._no_of_disc
                    });
                     paramList.Add(new SqlParameter
                    {
                        ParameterName = "@stock",
                        SqlDbType = System.Data.SqlDbType.Int,
                        Direction = System.Data.ParameterDirection.Input,
                        Value = Movieobject._Stock
                    });
                     paramList.Add(new SqlParameter
                    {
                        ParameterName = "@main_image",
                        Value = Movieobject._mainImage
                    });
                     paramList.Add(new SqlParameter
                     {
                         ParameterName = "@thumbnail_image",
                         Value = Movieobject._thumbnailImage
                     });
                     paramList.Add(new SqlParameter
                     {
                         ParameterName = "@studios",
                         Value = Movieobject._Studios
                     });
                     paramList.Add(new SqlParameter
                     {
                         ParameterName = "@mrp",
                         Value = Movieobject._Mrp
                     });
                    paramList.Add(new SqlParameter
                     {
                         ParameterName = "@discount",
                         Value = Movieobject._Discount
                     });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@description",
                        Value = Movieobject._Synopsis
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@run_time",
                        Value = Movieobject._Runtime
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@rated",
                        Value = Movieobject._Rated
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@region",
                        Value = Movieobject._Region
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@type",
                        Value = Movieobject._Type
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@new_arrival",
                        Value = Movieobject._newArrival
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@best_seller",
                        Value = Movieobject._bestSeller
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@featured_product",
                        Value = Movieobject._featuredProduct
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@approved",
                        Value = Movieobject._Approved
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@sale",
                        Value = Movieobject._Sale
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@create_date",
                        Value = DateTime.Now
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@modified_date",
                        Value = Movieobject._modifiedDate
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@from_date",
                        Value = Movieobject._fromDate
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@to_date",
                        Value = Movieobject._toDate
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@pre_order",
                        Value = Movieobject._PreOrder
                    });
                    paramList.Add(new SqlParameter { 
                        ParameterName="@language",
                        Value=Movieobject.language
                    });
                }
                return paramList;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private List<SqlParameter> updateParameters(MoviesObject Movieobject)
        {
            try
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@movie_id",
                        Value = Movieobject._Id
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@title",
                        Value = Movieobject._Title
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@actor",
                        Value = Movieobject._Actor
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@actress",
                        Value = Movieobject._Actress
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@director",
                        Value = Movieobject._Director
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@producer",
                        Value = Movieobject._Producer
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@composer",
                        Value = Movieobject._Composer
                    });

                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@genre",
                        Value = Movieobject._Genre
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@realease_year",
                        Value = Movieobject._realeaseYear
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@subtitle",
                        Value = Movieobject._Subtitle
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@format",
                        Value = Movieobject._Format
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@catlog_no",
                        Value = Movieobject._catalogNo
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@sku",
                        Value = Movieobject._Sku
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@barcode_no",
                        Value = Movieobject._barcodeNo
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@label",
                        Value = Movieobject._Label
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@no_of_disc",
                        Value = Movieobject._no_of_disc
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@stock",
                        SqlDbType = System.Data.SqlDbType.Int,
                        Direction = System.Data.ParameterDirection.Input,
                        Value = Movieobject._Stock
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@main_image",
                        Value = Movieobject._mainImage
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@thumbnail_image",
                        Value = Movieobject._thumbnailImage
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@studios",
                        Value = Movieobject._Studios
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@mrp",
                        Value = Movieobject._Mrp
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@discount",
                        Value = Movieobject._Discount
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@description",
                        Value = Movieobject._Synopsis
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@run_time",
                        Value = Movieobject._Runtime
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@rated",
                        Value = Movieobject._Rated
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@region",
                        Value = Movieobject._Region
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@type",
                        Value = Movieobject._Type
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@new_arrival",
                        Value = Movieobject._newArrival
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@best_seller",
                        Value = Movieobject._bestSeller
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@featured_product",
                        Value = Movieobject._featuredProduct
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@approved",
                        Value = Movieobject._Approved
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@sale",
                        Value = Movieobject._Sale
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@modified_date",
                        Value = Movieobject._modifiedDate
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@from_date",
                        Value = Movieobject._fromDate
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@to_date",
                        Value = Movieobject._toDate
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@pre_order",
                        Value = Movieobject._PreOrder
                    });
                }
                return paramList;
            }
            catch (Exception)
            {
                
                throw;
            }
        }
    }

}
