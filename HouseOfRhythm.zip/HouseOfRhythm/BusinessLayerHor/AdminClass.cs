﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DataAccessLayer;
using System.Data.SqlClient;

namespace BusinessLayerHor
{
    public class AdminClass
    {
        /* Method to fetch latest added details for all products */
        /* Date : 8-8-2017 */

        public static DataTable getRecords(string type)
        {
            CommonClass commonClass = new CommonClass();
            DataTable table;
            List<SqlParameter> sqlParam = new List<SqlParameter>();
            {
                sqlParam.Add(new SqlParameter()
                {
                    ParameterName = "@type",
                    Value = type
                });
            }
            table = commonClass.sortDetails("spAdminGetProductList", sqlParam);
            return table;
        }

        /* Mehtod To Get Admin Login Id Password */
        /* ******************************************************** */
        public static DataTable getLoginDetails(string id, string pwd)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@id",
                    Value = id
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@password",
                    Value = pwd
                });
            }
            DataTable dt = commonClass.sortDetails("spGetAdminLoginDetails", paramList);
            return dt;
        }

        /* Mehtod To Get Reports */
        /* ******************************************************** */
        public static DataSet getReports(string procedure, int pageIndex, int pageSize)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            paramList.Add(new SqlParameter()
            {
                ParameterName = "@PageIndex",
                Value = pageIndex
            });
            paramList.Add(new SqlParameter()
            {
                ParameterName = "@PageSize",
                Value = pageSize
            });

            DataSet dt = commonClass.getDetailsBySearchValue(procedure, paramList);
            return dt;
        }

        /* Mehtod To Get Format Details */
        /* ******************************************************** */
        public static DataTable getFormatDetails()
        {
            CommonClass commonClass = new CommonClass();
            DataTable dt = commonClass.getDetails("spAdminGetFormatList"); ;
            return dt;
        }

        /* Mehtod To Get Customer Details By Id */
        /* ******************************************************** */
        public static DataSet getUserDetails(string email)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@id",
                    Value = email
                });
            }
            DataSet dt = commonClass.getDetailsBySearchValue("spAdminGetCustomerDetailsById", paramList);
            return dt;
        }

        /* Mehtod To Get Music Catalog */
        /* ******************************************************** */
        public static DataSet getProductCatalog(int pindex, int psize, string type)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@PageIndex",
                    Value = pindex
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@PageSize",
                    Value = psize
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@type",
                    Value = type
                });

                DataSet ds = commonClass.getDetailsBySearchValue("spAdminGetProducts_Catalog_List2", paramList);
                return ds;
            }
        }

        /* Mehtod To Get Music Catalog by music id range filters */
        /* ******************************************************** */
        public static DataSet getProductCatalog_by_id_range_filter(int pindex, int psize, string type, int from, int to, string procedure)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@PageIndex",
                    Value = pindex
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@PageSize",
                    Value = psize
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@type",
                    Value = type
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@id_from",
                    Value = from
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@id_to",
                    Value = to
                });

                DataSet ds = commonClass.getDetailsBySearchValue(procedure, paramList);
                return ds;
            }
        }


        /* Mehtod To Get Music Catalog by music id range filters */
        /* ******************************************************** */
        public static DataSet getProductCatalog_by_SingleFilter(int pindex, int psize, string type, string filterValue, string procedure)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@PageIndex",
                    Value = pindex
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@PageSize",
                    Value = psize
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@type",
                    Value = type
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@filterValue",
                    Value = filterValue
                });

                DataSet ds = commonClass.getDetailsBySearchValue(procedure, paramList);
                return ds;
            }
        }

        /* Mehtod To Get Order Catalog by Date range filters */
        /* ******************************************************** */
        public static DataSet getProductCatalog_by_DateRangeFilter(int pindex, int psize, DateTime fromValue, DateTime toValue, string procedure)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@PageIndex",
                    Value = pindex
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@PageSize",
                    Value = psize
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@date_from",
                    Value = fromValue
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@date_to",
                    Value = toValue
                });

                DataSet ds = commonClass.getDetailsBySearchValue(procedure, paramList);
                return ds;
            }
        }


        /* Mehtod To Get Reports By Date Filter */
        /* ******************************************************** */
        public static DataTable getReporstByDate (string fromValue, string toValue, string procedure, string type)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@fromDate",
                    Value = fromValue
                });
                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@toDate",
                    Value = toValue
                });

                paramList.Add(new SqlParameter()
                {
                    ParameterName = "@type",
                    Value = type
                });

                DataTable ds = commonClass.sortDetails(procedure, paramList);
                return ds;
            }
        }
        /* Mehtod To set Refund status on credit memo */
        /* ******************************************************** */
        public static int setRefundStatus(string[] values, string comment)
        {
            CommonClass commonClass = new CommonClass();
            List<SqlParameter> paramList = new List<SqlParameter>();

            paramList.Add(new SqlParameter()
            {
                ParameterName = "@order_id",
                Value = values[3]
            });
            paramList.Add(new SqlParameter()
            {
                ParameterName = "@amount",
                Value = values[0]
            });
            paramList.Add(new SqlParameter()
            {
                ParameterName = "@refund_date",
                Value = values[2]
            });
            paramList.Add(new SqlParameter()
            {
                ParameterName = "@payment_type",
                Value = values[1]
            });
            paramList.Add(new SqlParameter()
            {
                ParameterName = "@status",
                Value = values[4]
            });
            paramList.Add(new SqlParameter()
            {
                ParameterName = "@notify",
                Value = values[5]
            });
            paramList.Add(new SqlParameter()
            {
                ParameterName = "@comment_date",
                Value = DateTime.Now
            });
            paramList.Add(new SqlParameter()
            {
                ParameterName = "@comment",
                Value = comment
            });

            int i = commonClass.InsertData("spAdminInsertRefundDetails", paramList);
            return i;
        }



    }
}
