﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DataAccessLayer;

namespace BusinessLayerHor
{
    
    public class CustomerClass
    {
        
        public string _UserId { get; set; }
        public string _FName { get; set; }
        public string _LName { get; set; }
        public string _Email { get; set; }
        public string _Password { get; set; }
        public string _Address { get; set; }
        public string _Mobile { get; set; }
        public string _Alternate { get; set; }
        public string _country { get; set; }
        public string _state { get; set; }
        public string _city { get; set; }
        public string _locality { get; set; }
        public string _pincode { get; set; }

        //Method to get Customer Login Details
        /**********************************************************************************/
        public static DataTable getUserLoginDetails(string email, string pwd)
        {
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@email",
                    Value = email
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@password",
                    Value = pwd
                });
            }

            CommonClass commonClass = new CommonClass();
            DataTable dt = commonClass.sortDetails("spGetUserLoginDetails", paramList);
            return dt;
        }

        public  DataTable getPassword(string email)
        {
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@email",
                    Value = email
                });
            }

            CommonClass commonClass = new CommonClass();
            DataTable dt = commonClass.sortDetails("spGetPasswordToChange", paramList);
            return dt;
        }
        public DataSet getUserDetails(string email)
        {
            CommonClass commonclass = new CommonClass();
            DataSet ds;
            ds = commonclass.getUserDetails("spgetUserDetailsforUpdate", email);
            return ds;

        }
        //Method to add Customer Registration Details
        /**********************************************************************************/
        public static int insertUserDetails(CustomerClass customerClass)
        {
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
               
                paramList.Add(new SqlParameter { 
                    ParameterName = "@user_fname",
                    Value= customerClass._FName 
                });
                
                paramList.Add(new SqlParameter { 
                    ParameterName = "@user_lname",
                    Value= customerClass._LName
                });
                
                paramList.Add(new SqlParameter { 
                    ParameterName = "@email",
                    Value= customerClass._Email
                });

                paramList.Add(new SqlParameter { 
                    ParameterName = "@password",
                    Value= customerClass._Password
                });

                paramList.Add(new SqlParameter { 
                    ParameterName = "@address",
                    Value= customerClass._Address
                });

                paramList.Add(new SqlParameter { 
                    ParameterName = "@mobile_no",
                    Value= customerClass._Mobile
                });

                paramList.Add(new SqlParameter { 
                    ParameterName = "@alternate_no",
                    Value= customerClass._Alternate
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@country",
                    Value = customerClass._country
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@state",
                    Value = customerClass._state
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@city",
                    Value = customerClass._city
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@locality",
                    Value = customerClass._locality
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@pincode",
                    Value = customerClass._pincode
                });
                paramList.Add(new SqlParameter { 
                    ParameterName = "@create_date",
                    Value= DateTime.Now
                });

                paramList.Add(new SqlParameter { 
                    ParameterName = "@last_login",
                    Value= DateTime.Now
                });

                paramList.Add(new SqlParameter { 
                    ParameterName = "@delete_indicator",
                    Value= 'N'
                });

                CommonClass commonClass = new CommonClass();
                int row_affected = commonClass.InsertData("spInsertUserDetails", paramList);
                return row_affected;
            }
        }


        //Method to update Customer Registration Details
        /**********************************************************************************/
        public static int updateUserDetails(CustomerClass customerClass)
        {
            List<SqlParameter> paramList = new List<SqlParameter>();
            {

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@user_fname",
                    Value = customerClass._FName
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@user_lname",
                    Value = customerClass._LName
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@email",
                    Value = customerClass._Email
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@address",
                    Value = customerClass._Address
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@mobile_no",
                    Value = customerClass._Mobile
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@alternate_no",
                    Value = customerClass._Alternate
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@country",
                    Value = customerClass._country
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@state",
                    Value = customerClass._state
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@city",
                    Value = customerClass._city
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@locality",
                    Value = customerClass._locality
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@pincode",
                    Value = customerClass._pincode
                });

                CommonClass commonClass = new CommonClass();
                int row_affected = commonClass.InsertData("spupdateUserDetails", paramList);
                return row_affected;
            }
        }
        //Method to get Customer WishList Details
        /**********************************************************************************/

        private DataTable userWishList(string user_id)
        {
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@userId",
                    Value = user_id
                });

                CommonClass commonClass = new CommonClass();
                DataTable dt = commonClass.sortDetails("", paramList);
                return dt;
            }
        }

        public int ChangePassword(CustomerClass customer)
        {
            try
            {
                List<SqlParameter> paramList = new List<SqlParameter>();
                {

                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@email",
                        Value = customer._Email
                    });

                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@password",
                        Value = customer._Password
                    });
                    CommonClass common = new CommonClass();
                    int row_affected = common.UpdateData("spchangePassword", paramList);
                    return row_affected;
                }
            }
            catch (Exception)
            {
                
                throw;
            }   
        }
    }
}
