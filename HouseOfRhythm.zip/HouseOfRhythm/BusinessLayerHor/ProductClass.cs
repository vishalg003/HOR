﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using DataAccessLayer;
using BusinessObject;

namespace BusinessLayerHor
{
    public class ProductClass
    {
        CommonClass commonClass;
        List<SqlParameter> paramList;
        DataTable dt;
        DataSet ds;

        public string user_id { get; set; }
        public string product_id { get; set; }
        public string title { get; set; }
        public decimal mrp { get; set; }
        public string prod_image { get; set; }


        //Function To Add Music Details
        /*******************************************************************************************************/
        public int insertMusic(MusicObject musicObject)
        {
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@music_id",
                    Value = musicObject._Id
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@title",
                    Value = musicObject._Tiltle
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@artist",
                    Value = musicObject._Artist
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@composer",
                    Value = musicObject._Composer
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@lyricist",
                    Value = musicObject._Lyricist
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@genre",
                    Value = musicObject._Genre
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@no_of_disc",
                    Value = musicObject._NoOfDisc
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@label",
                    Value = musicObject._Label
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@catlog_no",
                    Value = musicObject._CatlogNo
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@barcode",
                    Value = musicObject._BarcodeNo
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@release_date",
                    Value = musicObject._ReleaseDate
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@mrp",
                    Value = musicObject._Mrp
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@discount",
                    Value = musicObject._Discount
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@stock",
                    Value = musicObject._Stock
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@thumbnail_image",
                    Value = musicObject._ThumbnailImage
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@tracks",
                    Value = musicObject._Tracks
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@format",
                    Value = musicObject._Format
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@sku",
                    Value = musicObject._Sku
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@main_image",
                    Value = musicObject._MainImage
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@description",
                    Value = musicObject._Description
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@type",
                    Value = "Music"
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@featured_products",
                    Value = musicObject._featuredProd
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@best_seller",
                    Value = musicObject._bestSeller
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@new_arrival",
                    Value = musicObject._newArrival
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@approve",
                    Value = 'N'
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@sale",
                    Value = 'N'
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@weight",
                    Value = musicObject._Weight
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@modified_date",
                    Value = musicObject._modifiedDate
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@from_date",
                    Value = musicObject._fromDate
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@to_date",
                    Value = musicObject._toDate
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@create_date",
                    Value = DateTime.Now
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@origin",
                    Value = musicObject._Origin
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@media",
                    Value = musicObject._Media
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@pre_order",
                    Value = musicObject._PreOrder
                });
            }
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminInsertMusicDetails", paramList);
            return i;
        }


        //Method to Remove product from Wishlist
        public int deleteProductFromWishlist(ProductClass product)
        {
            try
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@email",
                        Value =product.user_id
                    });
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@product_id",
                        Value = product.product_id
                    });
                }
                commonClass = new CommonClass();
                int i = commonClass.DeleteProductFromCart("spDeleteProductFromWishlist",paramList);
                return i;
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        //Function To Update Music Details
        /*******************************************************************************************************/
        public int updateMusic(MusicObject musicObject)
        {
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@music_id",
                    Value = musicObject._Id
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@title",
                    Value = musicObject._Tiltle
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@artist",
                    Value = musicObject._Artist
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@composer",
                    Value = musicObject._Composer
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@lyricist",
                    Value = musicObject._Lyricist
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@genre",
                    Value = musicObject._Genre
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@no_of_disc",
                    Value = musicObject._NoOfDisc
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@label",
                    Value = musicObject._Label
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@catlog_no",
                    Value = musicObject._CatlogNo
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@barcode",
                    Value = musicObject._BarcodeNo
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@release_date",
                    Value = musicObject._ReleaseDate
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@mrp",
                    Value = musicObject._Mrp
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@discount",
                    Value = musicObject._Discount
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@stock",
                    Value = musicObject._Stock
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@thumbnail_image",
                    Value = musicObject._ThumbnailImage
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@tracks",
                    Value = musicObject._Tracks
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@format",
                    Value = musicObject._Format
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@sku",
                    Value = musicObject._Sku
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@main_image",
                    Value = musicObject._MainImage
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@description",
                    Value = musicObject._Description
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@type",
                    Value = "Music"
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@featured_products",
                    Value = musicObject._featuredProd
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@best_seller",
                    Value = musicObject._bestSeller
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@new_arrival",
                    Value = musicObject._newArrival
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@approve",
                    Value = musicObject._Approve
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@sale",
                    Value = musicObject._Sale
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@weight",
                    Value = musicObject._Weight
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@modified_date",
                    Value = musicObject._modifiedDate
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@from_date",
                    Value = musicObject._fromDate
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@to_date",
                    Value = musicObject._toDate
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@origin",
                    Value = musicObject._Origin
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@media",
                    Value = musicObject._Media
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@pre_order",
                    Value = musicObject._PreOrder
                });
            }
            commonClass = new CommonClass();
            int i = commonClass.InsertData("spAdminUpdateMusicDetails", paramList);
            return i;
        }

        //Function To Add Products to Wishlist
        /*******************************************************************************************************/
        public int addMusicDetailsToWishlist(ProductClass product)
        {
            commonClass = new CommonClass();

            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@email",
                    Value = product.user_id
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@product_id",
                    Value = product.product_id
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@title",
                    Value = product.title
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@mrp",
                    Value = product.mrp
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@prod_image",
                    Value = product.prod_image
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@WishListDate",
                    Value = DateTime.Now
                });
                
            }
            int i = commonClass.InsertData("spAddProductToWishlist", paramList);
            return i;
        }

        //Method To Get Details for Music, Movie
        /*******************************************************************************************************/
        //Method To Get Details for Music, Movie
        /*******************************************************************************************************/
        public DataTable fetchProductDetails(string type)
        {
            if (type == "music")
            {
                commonClass = new CommonClass();
                dt = commonClass.getDetails("spGetAllMusicList");

            }
            else if (type == "movie")
            {
                commonClass = new CommonClass();
                dt = commonClass.getDetails("spGetAllMovieList");
            }
            else if (type == "book")
            {
                commonClass = new CommonClass();
                dt = commonClass.getDetails("spGetAllBookList");
            }

            else if (type == "new release")
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@type",
                        Value = "new_arrival"
                    });
                }
                commonClass = new CommonClass();
                dt = commonClass.sortDetails("spGetNewArrivals", paramList);
            }
            else if (type == "sale")
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@type",
                        Value = "sale"
                    });
                }
                commonClass = new CommonClass();
                dt = commonClass.sortDetails("spGetNewArrivals", paramList);
            }
            else if (type == "best_seller")
            {
                paramList = new List<SqlParameter>();
                {
                    paramList.Add(new SqlParameter
                    {
                        ParameterName = "@type",
                        Value = "best_seller"
                    });
                }
                commonClass = new CommonClass();
                dt = commonClass.sortDetails("spgetNewArrivalBestSeller", paramList);
            }
            else if (type == "featured product")
            {
                commonClass = new CommonClass();
                dt = commonClass.getDetails("spGetFeaturedProduct");
            }
            else if (type == "preorder")
            {
                commonClass = new CommonClass();
                dt = commonClass.getDetails("spgetPreOrderProductForHome");
            }

            return dt;
        }

        //Function To Get Music List By ID
        /*******************************************************************************************************/
        public DataTable fetchMusicDetailsById(string id, string type)
        {
            commonClass = new CommonClass();

            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@id",
                    Value = id
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@type",
                    Value = type
                });
            }
            dt = commonClass.sortDetails("spGetProductListByIdForCartPage", paramList);
            return dt;
        }

        //Method to get New Release ProductList
        /********************************************************************************** */
        public DataSet fetchNewReleaseList(string type, int pageindex, int pagesize)
        {
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@PageIndex",
                    Value = pageindex
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@PageSize",
                    Value = pagesize
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@type",
                    Value = type
                });

            }
            if (type == "new_release")
            {
                commonClass = new CommonClass();
                ds = commonClass.getProductListPaging("spGetNewArrivalsWithPaging", paramList);

            }
            else if (type == "sale")
            {
                commonClass = new CommonClass();
                ds = commonClass.getProductListPaging("spGetNewArrivalsWithPaging", paramList);
            }
            return ds;
        }

        //Method to get ProductList with Paging
        /************************************************************************************** */
        public DataSet fetchProductList(string type,int pageindex,int pagesize)
        {
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@PageIndex",
                    Value = pageindex
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@PageSize",
                    Value = pagesize
                });

            }
            if (type == "music")
            {
                commonClass = new CommonClass();
               ds = commonClass.getProductListPaging("spGetAllMusicListWithPaging", paramList);

            }
            else if (type == "movie")
            {
                commonClass = new CommonClass();
                ds = commonClass.getProductListPaging("spGetAllMovieListWithPaging",paramList);
            }
            else if (type == "book")
            {
                commonClass = new CommonClass();
                ds = commonClass.getProductListPaging("spGetAllBookListWithPaging", paramList);
            }
            else if (type == "product")
            {
                commonClass = new CommonClass();
                ds = commonClass.getProductListPaging("spGetAllProductListWithPaging", paramList);
            }
            else if (type == "preorder")
            {
                commonClass = new CommonClass();
                ds = commonClass.getProductListPaging("spGetPreOrderProducts", paramList);
            }
                //totalrows = (int)ds.Tables[1].Rows[0][0];
                return ds;
        }



        public DataSet fetchProductListWithFilter(string type, int pageindex, int pagesize,string category)
        {
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@PageIndex",
                    Value = pageindex
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@PageSize",
                    Value = pagesize
                });
                paramList.Add(new SqlParameter 
                {
                    ParameterName="@genre",
                    Value=category
                });
               
            }
            if (type == "music")
            {
                commonClass = new CommonClass();
                ds = commonClass.getProductListPaging("spGetAllMusicListWithFilter", paramList);

            }
            else if (type == "movie")
            {
                commonClass = new CommonClass();
                ds = commonClass.getProductListPaging("spGetAllMovieListWithFilter", paramList);
            }
            else if (type == "book")
            {
                commonClass = new CommonClass();
                ds = commonClass.getProductListPaging("spGetAllBookListWithFilter", paramList);
            }
            else if (type == "product")
            {
                commonClass = new CommonClass();
                ds = commonClass.getProductListPaging("spGetAllProductListWithFilter", paramList);
            }
            else if (type == "new_release")
            {
               
                commonClass = new CommonClass();
                ds = commonClass.getProductListPaging("spGetNewArrivalsWithPaging", paramList);
            }
            //totalrows = (int)ds.Tables[1].Rows[0][0];
            return ds;
        }

        //Function To Get All Categories for all Products
        /*******************************************************************************************************/
        public DataSet fetchAllCategoryDetails()
        {
            commonClass = new CommonClass();
            ds = commonClass.getMultiple("spGetProductCategoryForNavigationMenu");
            return ds;
        }

        //Function to get OrderList
        /****************************************************************************************************/
        public DataTable GetOrderList(string userId)
        {
            commonClass = new CommonClass();
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@email",
                    Value = userId
                });
            }
            dt = commonClass.sortDetails("spgetOrderDetails", paramList);
            return dt;
        }

        //Function To Get Movie,Books,Products Details By Category
        /*******************************************************************************************************/
        public DataSet GetMusicDetailsByCategory(string genre, string origin, string media)
        {
            commonClass = new CommonClass();
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@genre",
                    Value = genre
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@origin",
                    Value = origin
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@media",
                    Value = media
                });
            }
            ds = commonClass.getDetailsBySearchValue("spGetMusicCategories", paramList);
            return ds;
        }

        //Function To Get Movie,Books,Products Details By Category
        /*******************************************************************************************************/
        public DataSet GetProductDetailsByCategory(string type, string product)
        {
            commonClass = new CommonClass();
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@genre",
                    Value = type
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@product_type",
                    Value = product
                });
            }
            ds = commonClass.getDetailsBySearchValue("spGetProductListByCategory", paramList);
            return ds;
        }

        //Function To Get Music/Movie Details By Category and Format type
        /*******************************************************************************************************/
        public DataTable GetProductDetailsByCategoryAndFormat(string type, string format, string productType)
        {
            commonClass = new CommonClass();
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@format",
                    Value = format
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@genre",
                    Value = type
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@productType",
                    Value = productType
                });
            }
            dt = commonClass.sortDetails("spGetProductListByCategoryandFormat", paramList);
            return dt;
        }

        //Function To Get User WishList Details
        /*******************************************************************************************************/
        public DataTable GetProductDetailsFromWishlist(string userId)
        {
            commonClass = new CommonClass();
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@email",
                    Value = userId
                });
            }
            dt = commonClass.sortDetails("spgetWishlist", paramList);
            return dt;
        }

        //Function To Sort Music Details
        /*******************************************************************************************************/
        public DataTable sortMusicDetails(string procedure, string sort_value)
        {
            commonClass = new CommonClass();
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@type",
                    Value = sort_value
                });
                
            }
            dt = commonClass.sortDetails(procedure, paramList);
            return dt;
        }
        public DataTable sortProductDetails(string procedure, string sort_value, int pageindex, int pagesize)
        {
            commonClass = new CommonClass();
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@type",
                    Value = sort_value
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@pageindex",
                    Value = pageindex
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@pagesize",
                    Value = pagesize
                });
            }
            dt = commonClass.sortDetails(procedure, paramList);
            return dt;
        }

        public DataTable sortProductDetailsWithFilter(string procedure, string sort_value,string category, int pageindex, int pagesize)
        {
            commonClass = new CommonClass();
            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@type",
                    Value = sort_value
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@category",
                    Value = category
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@pageindex",
                    Value = pageindex
                });
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@pagesize",
                    Value = pagesize
                });
            }
            dt = commonClass.sortDetails(procedure, paramList);
            return dt;
        }
       
        //Method to SearchProducts 
        /*************************************************************************/

        public DataTable SearchProduct(string searchtext)
        {
            commonClass = new CommonClass();

            paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter
                {
                    ParameterName = "@SearchText",
                    Value = searchtext
                });

            }
            dt = commonClass.searchProducts("spSearchProducts", searchtext);
            return dt;
        }
    }
}
