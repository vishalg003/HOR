﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccessLayer;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLayerHor
{
    public class ProductDetails
    {
        CommonClass commonClass;
        DataTable dt;
        public DataTable getProductDetailsByType(string id, string type)
        {
            try
            {
                commonClass = new CommonClass();
                dt = commonClass.getProductDetailsbyProductType("spgetProductDetails", id, type);
                return dt;
            }
            catch (Exception)
            {

                throw;
            }
        }

        //Method to get product related details foe dl_related_products
        /***************************************************************************************/

        public DataTable getRelatedProducts(string singer, string genre, string composer, string type)
        {
            commonClass = new CommonClass();

            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                paramList.Add(new SqlParameter {
                    ParameterName = "@artist",
                    Value = singer
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@genre",
                    Value = genre
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@composer",
                    Value = composer
                });

                paramList.Add(new SqlParameter
                {
                    ParameterName = "@productType",
                    Value = type
                });
            }

            dt = commonClass.sortDetails("spGetProductRelatedProducts", paramList);
            return dt;
        }
    }
}
