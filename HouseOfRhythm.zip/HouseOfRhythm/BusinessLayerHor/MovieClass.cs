﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DataAccessLayer;

namespace BusinessLayerHor
{
    public class MovieClass
    {
        CommonClass commonClass;
        DataTable dt;
        //Function To Get All Music Details
        /*******************************************************************************************************/
        public DataTable fetchAllCategoryDetails()
        {
            commonClass = new CommonClass();
            dt = commonClass.getDetails("spGetCategoryList");
            return dt;
        }
    }
}
